﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_altitude_target_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_pai_day_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_altitude_target_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background_en2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 409,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Pau.1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 409,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 365,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 365,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bottom_number-b.png',
              unit_tc: 'bottom_number-b.png',
              unit_en: 'bottom_number-b.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 0,
              image_array: ["level-right-0.png","level-right-1.png","level-right-2.png","level-right-3.png","level-right-4.png","level-right-5.png","level-right-6.png","level-right-7.png","level-right-8.png","level-right-9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 317,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["level-left-0.png","level-left-1.png","level-left-2.png","level-left-3.png","level-left-4.png","level-left-5.png","level-left-6.png","level-left-7.png","level-left-8.png","level-left-9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 317,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 50,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_number-dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 50,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_number-dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 83,
              w: 174,
              h: 30,
              text_size: 15,
              char_space: 0,
              color: 0xFFD3D3D3,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 100,
              image_array: ["weather-0.png","weather-1.png","weather-2.png","weather-3.png","weather-4.png","weather-5.png","weather-6.png","weather-7.png","weather-8.png","weather-9.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-minus.png',
              invalid_image: 'upper_number-null2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-minus.png',
              invalid_image: 'upper_number-null2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 102,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'date-degree.png',
              unit_tc: 'date-degree.png',
              unit_en: 'date-degree.png',
              imperial_unit_sc: 'date-degree.png',
              imperial_unit_tc: 'date-degree.png',
              imperial_unit_en: 'date-degree.png',
              negative_image: 'date-minus.png',
              invalid_image: 'date-null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 138,
              day_startY: 99,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'date-slash.png',
              day_unit_tc: 'date-slash.png',
              day_unit_en: 'date-slash.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: 101,
              week_en: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              week_tc: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              week_sc: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 191,
              month_startY: 99,
              month_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 186,
              hour_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time-dot.png',
              hour_unit_tc: 'time-dot.png',
              hour_unit_en: 'time-dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'time-dot.png',
              minute_unit_tc: 'time-dot.png',
              minute_unit_en: 'time-dot.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 80,
              second_startY: 200,
              second_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 447,
              y: 214,
              src: 'icon-bluetooth-NG-6_transparent.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 215,
              src: 'icon-alarm-1-s-2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background_en2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 409,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Pau.1.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 409,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 365,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 365,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'bottom_number-b.png',
              unit_tc: 'bottom_number-b.png',
              unit_en: 'bottom_number-b.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 0,
              image_array: ["level-right-0.png","level-right-1.png","level-right-2.png","level-right-3.png","level-right-4.png","level-right-5.png","level-right-6.png","level-right-7.png","level-right-8.png","level-right-9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 317,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["level-left-0.png","level-left-1.png","level-left-2.png","level-left-3.png","level-left-4.png","level-left-5.png","level-left-6.png","level-left-7.png","level-left-8.png","level-left-9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 317,
              font_array: ["bottom_number-0.png","bottom_number-1.png","bottom_number-2.png","bottom_number-3.png","bottom_number-4.png","bottom_number-5.png","bottom_number-6.png","bottom_number-7.png","bottom_number-8.png","bottom_number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 50,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_number-dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 262,
              y: 50,
              font_array: ["sun_number-0.png","sun_number-1.png","sun_number-2.png","sun_number-3.png","sun_number-4.png","sun_number-5.png","sun_number-6.png","sun_number-7.png","sun_number-8.png","sun_number-9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_number-dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 254,
              y: 83,
              w: 174,
              h: 30,
              text_size: 15,
              char_space: 0,
              color: 0xFFD3D3D3,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 100,
              image_array: ["weather-0.png","weather-1.png","weather-2.png","weather-3.png","weather-4.png","weather-5.png","weather-6.png","weather-7.png","weather-8.png","weather-9.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-minus.png',
              invalid_image: 'upper_number-null2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 139,
              font_array: ["upper_number-0.png","upper_number-1.png","upper_number-2.png","upper_number-3.png","upper_number-4.png","upper_number-5.png","upper_number-6.png","upper_number-7.png","upper_number-8.png","upper_number-9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'upper_number-degree.png',
              unit_tc: 'upper_number-degree.png',
              unit_en: 'upper_number-degree.png',
              imperial_unit_sc: 'upper_number-degree.png',
              imperial_unit_tc: 'upper_number-degree.png',
              imperial_unit_en: 'upper_number-degree.png',
              negative_image: 'upper_number-minus.png',
              invalid_image: 'upper_number-null2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 102,
              font_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'date-degree.png',
              unit_tc: 'date-degree.png',
              unit_en: 'date-degree.png',
              imperial_unit_sc: 'date-degree.png',
              imperial_unit_tc: 'date-degree.png',
              imperial_unit_en: 'date-degree.png',
              negative_image: 'date-minus.png',
              invalid_image: 'date-null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 138,
              day_startY: 99,
              day_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'date-slash.png',
              day_unit_tc: 'date-slash.png',
              day_unit_en: 'date-slash.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 53,
              y: 101,
              week_en: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              week_tc: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              week_sc: ["week-1.png","week-2.png","week-3.png","week-4.png","week-5.png","week-6.png","week-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 191,
              month_startY: 99,
              month_sc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_tc_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_en_array: ["date-0.png","date-1.png","date-2.png","date-3.png","date-4.png","date-5.png","date-6.png","date-7.png","date-8.png","date-9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 186,
              hour_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time-dot.png',
              hour_unit_tc: 'time-dot.png',
              hour_unit_en: 'time-dot.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'time-dot.png',
              minute_unit_tc: 'time-dot.png',
              minute_unit_en: 'time-dot.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 80,
              second_startY: 200,
              second_array: ["time-0.png","time-1.png","time-2.png","time-3.png","time-4.png","time-5.png","time-6.png","time-7.png","time-8.png","time-9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 447,
              y: 214,
              src: 'icon-bluetooth-NG-6_transparent.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 15,
              y: 215,
              src: 'icon-alarm-1-s-2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 46,
              y: 303,
              w: 189,
              h: 56,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 360,
              w: 160,
              h: 39,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 141,
              y: 20,
              w: 199,
              h: 65,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 87,
              w: 162,
              h: 82,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 188,
              w: 112,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 188,
              w: 112,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 186,
              w: 112,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 302,
              w: 189,
              h: 57,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 405,
              w: 125,
              h: 51,
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 87,
              w: 168,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'toumei_transparent.png',
              normal_src: 'toumei_transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 77,
              y: 365,
              w: 158,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'toumei_transparent.png',
              normal_src: 'toumei_transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

              console.log('Weather city name');
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}