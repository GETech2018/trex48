﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let element_menu = 0;
        let element_hands = 0;


		function click_MENU() {
        
            if (element_menu == 0){
                hmUI.showToast({text: 'Menu Enable'});
                element_menu = 1;
           }
           else {
                hmUI.showToast({text: 'Menu Disable'});
               element_menu = 0;
           }
          normal_image_img.setProperty(hmUI.prop.VISIBLE, element_menu==1);
           
		};


		function click_HANDS() {
        
            if (element_hands == 0){
                hmUI.showToast({text: 'Hands Disable'});
                element_hands = 1;
           }
           else {
                hmUI.showToast({text: 'Hands Enable'});
               element_hands = 0;
           }
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, element_hands==0);
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, element_hands==0);
          normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, element_hands==0);
		};

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_year_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_year_icon_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['bck-00.png', 'bck-01.png', 'bck-02.png', 'bck-03.png', 'bck-04.png'];
        let backgroundToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bck-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 195,
              src: 'ico-blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 451,
              src: 'ico-sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 265,
              y: 91,
              image_array: ["set_19_meteo_1.png","set_19_meteo_2.png","set_19_meteo_3.png","set_19_meteo_4.png","set_19_meteo_5.png","set_19_meteo_6.png","set_19_meteo_7.png","set_19_meteo_8.png","set_19_meteo_9.png","set_19_meteo_10.png","set_19_meteo_11.png","set_19_meteo_12.png","set_19_meteo_13.png","set_19_meteo_14.png","set_19_meteo_15.png","set_19_meteo_16.png","set_19_meteo_17.png","set_19_meteo_18.png","set_19_meteo_19.png","set_19_meteo_20.png","set_19_meteo_21.png","set_19_meteo_22.png","set_19_meteo_23.png","set_19_meteo_24.png","set_19_meteo_25.png","set_19_meteo_26.png","set_19_meteo_27.png","set_19_meteo_28.png","set_19_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 96,
              font_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'middigit-gradi.png',
              unit_tc: 'middigit-gradi.png',
              unit_en: 'middigit-gradi.png',
              negative_image: 'middigit-meno.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 348,
              src: 'middigit-meno.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 262,
              year_startY: 348,
              year_sc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              year_tc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              year_en_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 348,
              month_sc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              month_tc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              month_en_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 348,
              day_sc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              day_tc_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              day_en_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 348,
              src: 'middigit-meno.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 402,
              font_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 402,
              font_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 96,
              font_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'middigit-duepunti.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 43,
              font_array: ["middigit-00.png","middigit-01.png","middigit-02.png","middigit-03.png","middigit-04.png","middigit-05.png","middigit-06.png","middigit-07.png","middigit-08.png","middigit-09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 152,
              hour_array: ["bigdigit-00.png","bigdigit-01.png","bigdigit-02.png","bigdigit-03.png","bigdigit-04.png","bigdigit-05.png","bigdigit-06.png","bigdigit-07.png","bigdigit-08.png","bigdigit-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 152,
              minute_array: ["bigdigit-00.png","bigdigit-01.png","bigdigit-02.png","bigdigit-03.png","bigdigit-04.png","bigdigit-05.png","bigdigit-06.png","bigdigit-07.png","bigdigit-08.png","bigdigit-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image-selezione.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AODbck-00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 195,
              src: 'ico-blue.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 207,
              y: 451,
              src: 'AODico-sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 348,
              src: 'AODmiddigit-meno.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 262,
              year_startY: 348,
              year_sc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              year_tc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              year_en_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 348,
              month_sc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              month_tc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              month_en_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 116,
              day_startY: 348,
              day_sc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              day_tc_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              day_en_array: ["AODmiddigit-00.png","AODmiddigit-01.png","AODmiddigit-02.png","AODmiddigit-03.png","AODmiddigit-04.png","AODmiddigit-05.png","AODmiddigit-06.png","AODmiddigit-07.png","AODmiddigit-08.png","AODmiddigit-09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 348,
              src: 'AODmiddigit-meno.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 152,
              hour_array: ["AODbigdigit-00.png","AODbigdigit-01.png","AODbigdigit-02.png","AODbigdigit-03.png","AODbigdigit-04.png","AODbigdigit-05.png","AODbigdigit-06.png","AODbigdigit-07.png","AODbigdigit-08.png","AODbigdigit-09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 152,
              minute_array: ["AODbigdigit-00.png","AODbigdigit-01.png","AODbigdigit-02.png","AODbigdigit-03.png","AODbigdigit-04.png","AODbigdigit-05.png","AODbigdigit-06.png","AODbigdigit-07.png","AODbigdigit-08.png","AODbigdigit-09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 200,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                click_MENU();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 125,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 125,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 182,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 121,
              y: 182,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 121,
              y: 259,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 319,
              y: 260,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 262,
              y: 317,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 317,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 386,
              y: 344,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 337,
              y: 39,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 104,
              y: 39,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 56,
              y: 344,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 200,
              // y: 0,
              // w: 80,
              // h: 80,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0_empty.png',
              // normal_src: '0_empty.png',
              // bg_list: bck-00|bck-01|bck-02|bck-03|bck-04,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 0,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            console.log('user_script_end.js');
            // start user_script_end.js


 normal_image_img.setProperty(hmUI.prop.VISIBLE, element_menu==1);
            // end user_script_end.js

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}