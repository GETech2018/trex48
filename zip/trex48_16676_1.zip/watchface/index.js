﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        let element_menu = 0;
 

		function click_MENU() {
        
            if (element_menu == 0){
                hmUI.showToast({text: 'Menu Enable'});
                element_menu = 1;
           }
           else {
                hmUI.showToast({text: 'Menu Disable'});
               element_menu = 0;
           }
          normal_image_img.setProperty(hmUI.prop.VISIBLE, element_menu==1);
           
		};


        // end user_functions.js

        let normal_background_bg = ''
        let normal_moon_image_progress_img_level = ''
        let normal_moon_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_day_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''
        let idle_background_bg = ''
        let idle_moon_image_progress_img_level = ''
        let idle_moon_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_day_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 72-Condensed.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 415,
              h: 54,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/72-Condensed.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 71,
              image_array: ["mp_01.png","mp_02.png","mp_03.png","mp_04.png","mp_05.png","mp_06.png","mp_07.png","mp_08.png","mp_09.png","mp_10.png","mp_11.png","mp_12.png","mp_13.png","mp_14.png","mp_15.png","mp_16.png","mp_17.png","mp_18.png","mp_19.png","mp_20.png","mp_21.png","mp_22.png","mp_23.png","mp_24.png","mp_25.png","mp_26.png","mp_27.png","mp_28.png","mp_29.png","mp_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image1-ombra.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'ind-batteria-ombra.png',
              center_x: 240,
              center_y: 240,
              x: 100,
              y: 240,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 150,
              src: 'ico-bluet.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ind-ombra.png',
              center_x: 330,
              center_y: 270,
              posX: 20,
              posY: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ind-ombra.png',
              center_x: 150,
              center_y: 270,
              posX: 20,
              posY: 75,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 214,
              y: 428,
              w: 60,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/72-Condensed.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-ombra.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 100,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-ombra.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 100,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec-ombra.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 100,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image-selezione.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 71,
              image_array: ["mp_01.png","mp_02.png","mp_03.png","mp_04.png","mp_05.png","mp_06.png","mp_07.png","mp_08.png","mp_09.png","mp_10.png","mp_11.png","mp_12.png","mp_13.png","mp_14.png","mp_15.png","mp_16.png","mp_17.png","mp_18.png","mp_19.png","mp_20.png","mp_21.png","mp_22.png","mp_23.png","mp_24.png","mp_25.png","mp_26.png","mp_27.png","mp_28.png","mp_29.png","mp_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'image1-ombra.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 171,
              y: 150,
              src: 'ico-bluet.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ind-ombra.png',
              center_x: 330,
              center_y: 270,
              posX: 20,
              posY: 75,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'ind-ombra.png',
              center_x: 150,
              center_y: 270,
              posX: 20,
              posY: 75,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 214,
              y: 428,
              w: 60,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/72-Condensed.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ore-ombra.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 100,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min-ombra.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 100,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sec-ombra.png',
              center_x: 240,
              center_y: 240,
              x: 100,
              y: 240,
              start_angle: 0,
              end_angle: 300,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 220,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_MENU();
        
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 120,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 120,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 121,
              y: 180,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 180,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 260,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 260,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'PhoneHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 181,
              y: 317,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 259,
              y: 317,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                if(element_menu==1) hmApp.startApp({url: 'VoiceMemoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js


 normal_image_img.setProperty(hmUI.prop.VISIBLE, element_menu==1);
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}