﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_floor_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_body_temp_text_text_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_bodyTemp_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 258,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 415,
              y: 258,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 37,
              month_sc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_tc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_en_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 37,
              day_sc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_tc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_en_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"]
			if(lang=='ru-RU'){
				dned=["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 207,
              y: 83,
              week_en: dned,
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 325,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 296,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 405,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 405,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 405,
              w: 102,
              h: 25,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 312,
              font_array: ["hrvnum_0.png","hrvnum_1.png","hrvnum_2.png","hrvnum_3.png","hrvnum_4.png","hrvnum_5.png","hrvnum_6.png","hrvnum_7.png","hrvnum_8.png","hrvnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonehrv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 312,
              font_array: ["hrvnum_0.png","hrvnum_1.png","hrvnum_2.png","hrvnum_3.png","hrvnum_4.png","hrvnum_5.png","hrvnum_6.png","hrvnum_7.png","hrvnum_8.png","hrvnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonehrv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 95,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 95,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonebpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 148,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 181,
              minute_startY: 148,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'colon.png',
              minute_unit_tc: 'colon.png',
              minute_unit_en: 'colon.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 148,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 40,
              month_sc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_tc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_en_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 40,
              day_sc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_tc_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_en_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl.png',
              day_unit_tc: 'sl.png',
              day_unit_en: 'sl.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 300,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 226,
              y: 250,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 250,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 274,
              y: 250,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 420,
              font_array: ["bpmnum_0.png","bpmnum_1.png","bpmnum_2.png","bpmnum_3.png","bpmnum_4.png","bpmnum_5.png","bpmnum_6.png","bpmnum_7.png","bpmnum_8.png","bpmnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 303,
              font_array: ["hrvnum_0.png","hrvnum_1.png","hrvnum_2.png","hrvnum_3.png","hrvnum_4.png","hrvnum_5.png","hrvnum_6.png","hrvnum_7.png","hrvnum_8.png","hrvnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonebpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 303,
              font_array: ["hrvnum_0.png","hrvnum_1.png","hrvnum_2.png","hrvnum_3.png","hrvnum_4.png","hrvnum_5.png","hrvnum_6.png","hrvnum_7.png","hrvnum_8.png","hrvnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonebpm.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 112,
              hour_startY: 121,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 120,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 250,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 365,
              w: 75,
              h: 100,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 50,
              w: 100,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 50,
              w: 100,
              h: 80,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bodyTemp_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 365,
              w: 75,
              h: 100,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 365,
              w: 75,
              h: 100,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 145,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 145,
              w: 100,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 145,
              w: 100,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 335,
              y: 255,
              w: 75,
              h: 85,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 70,
              y: 255,
              w: 75,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 73,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}