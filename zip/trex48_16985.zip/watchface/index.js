﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sleep_score_font = ''
        let normal_wakeup_count_font = ''
        let normal_wakeup_time_font = ''
        let normal_sleep_end_font = ''
        let normal_sleep_start_font = ''
        let array_sleep_chart = []
        let normal_sleep_chart_group = ''
        let normal_sleep_chart_hr = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 20,
              month_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 20,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'sl1.png',
              day_unit_tc: 'sl1.png',
              day_unit_en: 'sl1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 87,
              y: 60,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 98,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 98,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 98,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 203,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 255,
              font_array: ["A100_129.png","A100_130.png","A100_131.png","A100_132.png","A100_133.png","A100_134.png","A100_135.png","A100_136.png","A100_137.png","A100_138.png"],
              padding: false,
              h_space: 0,
              negative_image: 'min.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 376,
              y: 203,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 294,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 141,
              font_array: ["A100_114.png","A100_115.png","A100_116.png","A100_117.png","A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 250,
              y: 145,
              w: 150,
              h: 35,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_count_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 145,
              w: 150,
              h: 35,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wakeup_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 95,
              y: 145,
              w: 150,
              h: 35,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_end_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 210,
              y: 300,
              w: 150,
              h: 45,
              text_size: 22,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            normal_sleep_start_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 69,
              y: 300,
              w: 150,
              h: 45,
              text_size: 22,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sleep_chart = hmUI.createWidget(hmUI.widget.SLEEP_CHART, {
              // x: 25,
              // y: 201,
              // w: 270,
              // h: 80,
              // radius: 5,
              // deep_stage_color: 0xFF743ED4,
              // light_stage_color: 0xFF6284EF,
              // rem_stage_color: 0xFF46C536,
              // wake_stage_color: 0xFFAE433B,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sleep_chart_group = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 25,
              y: 201,
              w: 270,
              h: 80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_sleep_chart_hr = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
              x: 25,
              y: 201,
              w: 270,
              h: 80,
              line_width: 1,
              line_color: 0xFFC42742,
              // type: hmUI.data_type.SLEEP_HR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 355,
              hour_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: 'A100_076.png',
              hour_unit_tc: 'A100_076.png',
              hour_unit_en: 'A100_076.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 193,
              minute_startY: 355,
              minute_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'A100_076.png',
              minute_unit_tc: 'A100_076.png',
              minute_unit_en: 'A100_076.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 310,
              second_startY: 355,
              second_array: ["A100_066.png","A100_067.png","A100_068.png","A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 365,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 365,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 365,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 274,
              year_startY: 70,
              year_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              year_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              year_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 222,
              month_startY: 70,
              month_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              month_zero: 1,
              month_space: 3,
              month_unit_sc: 'sl1.png',
              month_unit_tc: 'sl1.png',
              month_unit_en: 'sl1.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 168,
              day_startY: 70,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 1,
              day_space: 3,
              day_unit_sc: 'sl1.png',
              day_unit_tc: 'sl1.png',
              day_unit_en: 'sl1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 120,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 122,
              hour_startY: 213,
              hour_array: ["A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png"],
              hour_zero: 1,
              hour_space: 10,
              hour_angle: 0,
              hour_unit_sc: 'A100_059.png',
              hour_unit_tc: 'A100_059.png',
              hour_unit_en: 'A100_059.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 213,
              minute_array: ["A100_049.png","A100_050.png","A100_051.png","A100_052.png","A100_053.png","A100_054.png","A100_055.png","A100_056.png","A100_057.png","A100_058.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 85,
              w: 100,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 80,
              w: 100,
              h: 55,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 140,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 295,
              w: 100,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 196,
              w: 100,
              h: 85,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 355,
              w: 100,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 355,
              w: 100,
              h: 60,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 355,
              w: 100,
              h: 60,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 195,
              w: 100,
              h: 100,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep wakeup count');
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              if (normal_wakeup_count_font) normal_wakeup_count_font.setProperty(hmUI.prop.TEXT, String(wakeupCount));

              console.log('sleep wakeup time');
              let wakeupTimeHour = Math.floor(wakeupTime / 60);
              let wakeupTimeMin = sleepTime % 60;

              if (normal_wakeup_time_font) normal_wakeup_time_font.setProperty(hmUI.prop.TEXT, wakeupTime.toString());

              console.log('sleep end time');
              let sleepEndTime = sleepInfo.endTime;
              if (sleepEndTime >= 24*60) sleepEndTime -= 24*60;
              let sleepEndHour = Math.floor(sleepEndTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepEndHour >= 12) sleepEndHour -= 12;
                if (sleepEndHour == 0) sleepEndHour = 12;
              };
              let sleepEndMin = sleepEndTime % 60;

              let normal_sleepEndHourStr = sleepEndHour.toString();
              let normal_SleepEndMinStr = sleepEndMin.toString().padStart(2, '0');
              let normal_SleepEndStr = normal_sleepEndHourStr + ':' + normal_SleepEndMinStr;
              if (!timeSensor.is24Hour) {
                if (Math.floor(sleepEndTime / 60) > 11) normal_SleepEndStr = 'pm ' + normal_SleepEndStr
                else normal_SleepEndStr = 'am ' + normal_SleepEndStr
              };
              if (normal_sleep_end_font) normal_sleep_end_font.setProperty(hmUI.prop.TEXT, normal_SleepEndStr);

              console.log('sleep start time');
              let sleepStartTime = sleepInfo.startTime;
              if (sleepStartTime >= 24*60) sleepStartTime -= 24*60;
              let sleepStartHour = Math.floor(sleepStartTime / 60);
              if (!timeSensor.is24Hour) {
                if (sleepStartHour >= 12) sleepStartHour -= 12;
                if (sleepStartHour == 0) sleepStartHour = 12;
              };
              let sleepStartMin = sleepStartTime % 60;

              let normal_SleepStartHourStr = sleepStartHour.toString();
              let normal_SleepStartMinStr = sleepStartMin.toString().padStart(2, '0');
              let normal_SleepStartStr = normal_SleepStartHourStr + ':' + normal_SleepStartMinStr;
              if (!timeSensor.is24Hour) {
                if (Math.floor(sleepStartTime / 60) > 11) normal_SleepStartStr = 'pm ' + normal_SleepStartStr
                else normal_SleepStartStr = 'am ' + normal_SleepStartStr
              };
              if (normal_sleep_start_font) normal_sleep_start_font.setProperty(hmUI.prop.TEXT, normal_SleepStartStr);

              console.log('sleep chart');
              let normal_sleepColors = [0xFF743ED4, 0xFF6284EF, 0xFF46C536, 0xFFAE433B];
              let normal_sleppChartWidth = 270;
              let normal_sleppChartHeight = 80;
              let normal_sleepScaleX = normal_sleppChartWidth / sleepSensor.getTotalTime();
              let normal_sleepScaleY = normal_sleppChartHeight / 4;
              let sleepChartStartTime = 0;
              if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen on');
                for (let i = 0; i < array_sleep_chart.length; i++) {
                  if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                }
                array_sleep_chart = [];
              } // end if

              if (sleepStageArray != undefined && sleepStageArray.length > 0) sleepChartStartTime = sleepStageArray[0].start;
              // console.log('draw normal_sleep_chart');
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                for (let i = 0; i < sleepStageArray.length; i++) { //ONLY_NORMAL
                  let data = sleepStageArray[i];
                  let normal_color = normal_sleepColors[0];
                  let normal_posY = 3 * normal_sleepScaleY;

                  switch (data.model) {
                    case modelData.WAKE_STAGE:
                      normal_color = normal_sleepColors[3];
                      normal_posY = 0;
                      break;
                    case modelData.REM_STAGE:
                      normal_color = normal_sleepColors[2];
                      normal_posY = normal_sleepScaleY; 
                      break;
                    case modelData.LIGHT_STAGE:
                      normal_color = normal_sleepColors[1];
                      normal_posY = 2 * normal_sleepScaleY; 
                      break;
                  };
                  let normal_x = (data.start - sleepChartStartTime) * normal_sleepScaleX;
                  let normal_w = (data.stop + 1 - data.start) * normal_sleepScaleX;
                  const fill_rect = normal_sleep_chart_group.createWidget(hmUI.widget.FILL_RECT, {
                    x: normal_x,
                    y: normal_posY,
                    w: normal_w,
                    h: normal_sleepScaleY,
                    radius: 5,
                    color: normal_color,
                  });
                  array_sleep_chart.push(fill_rect);
                }; // for
              }; // end screenType

              console.log('sleep HR chart');
              let sleepHrData = sleepSensor.getSleepHrData();
              const sleepHrData_replaced = sleepHrData.map(v => v === 255 ? 0 : v);
              let lineHrDatas = [];
              let maxHr = Math.max(...sleepHrData_replaced);
              for (let i = 0; i < sleepHrData_replaced.length; i++) {
                let y = 80 - (sleepHrData_replaced[i] * (80 / maxHr));
                lineHrDatas.push({x: i * (270 / sleepHrData_replaced.length), y: y});
              };
              if (screenType == hmSetting.screen_type.WATCHFACE) {
                normal_sleep_chart_hr.clear();
                normal_sleep_chart_hr.addLine({
                  data: lineHrDatas,
                  count: lineHrDatas.length
                });
              };
            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                sleep_update();
              }),
              pause_call: (function () {
                console.log('pause_call()');

                if (array_sleep_chart.length > 0) {
                console.log('deleteWidget screen off');
                  for (let i = 0; i < array_sleep_chart.length; i++) {
                    if (array_sleep_chart[i]) hmUI.deleteWidget(array_sleep_chart[i]);
                  }
                  array_sleep_chart = [];
                } // end if

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}