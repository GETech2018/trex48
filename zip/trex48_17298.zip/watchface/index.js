﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_floor_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_vo2max_text_text_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 440,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 440,
              day_sc_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_tc_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_en_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 55,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 398,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 112,
              src: 'run.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 327,
              y: 399,
              font_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 156,
              image_array: ["loadlvl_1.png","loadlvl_2.png","loadlvl_3.png","loadlvl_4.png","loadlvl_5.png","loadlvl_6.png","loadlvl_7.png","loadlvl_8.png","loadlvl_9.png"],
              image_length: 9,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 85,
              font_array: ["bio_0.png","bio_1.png","bio_2.png","bio_3.png","bio_4.png","bio_5.png","bio_6.png","bio_7.png","bio_8.png","bio_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'bionull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 167,
              y: 45,
              image_array: ["hrlvl_1.png","hrlvl_2.png","hrlvl_3.png"],
              image_length: 3,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 41,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 115,
              font_array: ["min_maxtemp_0.png","min_maxtemp_1.png","min_maxtemp_2.png","min_maxtemp_3.png","min_maxtemp_4.png","min_maxtemp_5.png","min_maxtemp_6.png","min_maxtemp_7.png","min_maxtemp_8.png","min_maxtemp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min_maxtemp_du.png',
              unit_tc: 'min_maxtemp_du.png',
              unit_en: 'min_maxtemp_du.png',
              negative_image: 'min_maxtemp_fu.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 385,
              y: 115,
              font_array: ["min_maxtemp_0.png","min_maxtemp_1.png","min_maxtemp_2.png","min_maxtemp_3.png","min_maxtemp_4.png","min_maxtemp_5.png","min_maxtemp_6.png","min_maxtemp_7.png","min_maxtemp_8.png","min_maxtemp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min_maxtemp_du.png',
              unit_tc: 'min_maxtemp_du.png',
              unit_en: 'min_maxtemp_du.png',
              negative_image: 'min_maxtemp_fu.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 75,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fudata.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 303,
              image_array: ["battlvl_1.png","battlvl_2.png","battlvl_3.png","battlvl_4.png","battlvl_5.png","battlvl_6.png","battlvl_7.png","battlvl_8.png","battlvl_9.png","battlvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 333,
              font_array: ["stepvo2max_0.png","stepvo2max_1.png","stepvo2max_2.png","stepvo2max_3.png","stepvo2max_4.png","stepvo2max_5.png","stepvo2max_6.png","stepvo2max_7.png","stepvo2max_8.png","stepvo2max_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 333,
              font_array: ["stepvo2max_0.png","stepvo2max_1.png","stepvo2max_2.png","stepvo2max_3.png","stepvo2max_4.png","stepvo2max_5.png","stepvo2max_6.png","stepvo2max_7.png","stepvo2max_8.png","stepvo2max_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 137,
              center_y: 262,
              x: 19,
              y: 82,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 230,
              font_array: ["bio_0.png","bio_1.png","bio_2.png","bio_3.png","bio_4.png","bio_5.png","bio_6.png","bio_7.png","bio_8.png","bio_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'bionull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 305,
              am_y: 150,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 305,
              pm_y: 150,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 233,
              hour_startY: 195,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 357,
              minute_startY: 195,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 150,
              second_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'backgroundaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 143,
              font_array: ["maxminod_0.png","maxminod_1.png","maxminod_2.png","maxminod_3.png","maxminod_4.png","maxminod_5.png","maxminod_6.png","maxminod_7.png","maxminod_8.png","maxminod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 440,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 250,
              day_startY: 440,
              day_sc_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_tc_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_en_array: ["date_sec_cal_0.png","date_sec_cal_1.png","date_sec_cal_2.png","date_sec_cal_3.png","date_sec_cal_4.png","date_sec_cal_5.png","date_sec_cal_6.png","date_sec_cal_7.png","date_sec_cal_8.png","date_sec_cal_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 55,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 398,
              font_array: ["dataaod_0.png","dataaod_1.png","dataaod_2.png","dataaod_3.png","dataaod_4.png","dataaod_5.png","dataaod_6.png","dataaod_7.png","dataaod_8.png","dataaod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aoddatkm.png',
              unit_tc: 'aoddatkm.png',
              unit_en: 'aoddatkm.png',
              dot_image: 'aoddatadot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 399,
              font_array: ["dataaod_0.png","dataaod_1.png","dataaod_2.png","dataaod_3.png","dataaod_4.png","dataaod_5.png","dataaod_6.png","dataaod_7.png","dataaod_8.png","dataaod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 19,
              y: 156,
              image_array: ["loadlvlaod_1.png","loadlvlaod_2.png","loadlvlaod_3.png","loadlvlaod_4.png","loadlvlaod_5.png","loadlvlaod_6.png","loadlvlaod_7.png","loadlvlaod_8.png","loadlvlaod_9.png"],
              image_length: 9,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 85,
              font_array: ["bio_0.png","bio_1.png","bio_2.png","bio_3.png","bio_4.png","bio_5.png","bio_6.png","bio_7.png","bio_8.png","bio_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'bionull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 41,
              image_array: ["aodw_0.png","aodw_1.png","aodw_2.png","aodw_3.png","aodw_4.png","aodw_5.png","aodw_6.png","aodw_7.png","aodw_8.png","aodw_9.png","aodw_10.png","aodw_11.png","aodw_12.png","aodw_13.png","aodw_14.png","aodw_15.png","aodw_16.png","aodw_17.png","aodw_18.png","aodw_19.png","aodw_20.png","aodw_21.png","aodw_22.png","aodw_23.png","aodw_24.png","aodw_25.png","aodw_26.png","aodw_27.png","aodw_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 115,
              font_array: ["maxminod_0.png","maxminod_1.png","maxminod_2.png","maxminod_3.png","maxminod_4.png","maxminod_5.png","maxminod_6.png","maxminod_7.png","maxminod_8.png","maxminod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'maxminoddu.png',
              unit_tc: 'maxminoddu.png',
              unit_en: 'maxminoddu.png',
              negative_image: 'maxminodfu.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 385,
              y: 115,
              font_array: ["maxminod_0.png","maxminod_1.png","maxminod_2.png","maxminod_3.png","maxminod_4.png","maxminod_5.png","maxminod_6.png","maxminod_7.png","maxminod_8.png","maxminod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'maxminoddu.png',
              unit_tc: 'maxminoddu.png',
              unit_en: 'maxminoddu.png',
              negative_image: 'maxminodfu.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 75,
              font_array: ["dataaod_0.png","dataaod_1.png","dataaod_2.png","dataaod_3.png","dataaod_4.png","dataaod_5.png","dataaod_6.png","dataaod_7.png","dataaod_8.png","dataaod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aoddatadu.png',
              unit_tc: 'aoddatadu.png',
              unit_en: 'aoddatadu.png',
              negative_image: 'aoddatafu.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 303,
              image_array: ["battlvlaod_1.png","battlvlaod_2.png","battlvlaod_3.png","battlvlaod_4.png","battlvlaod_5.png","battlvlaod_6.png","battlvlaod_7.png","battlvlaod_8.png","battlvlaod_9.png","battlvlaod_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 335,
              font_array: ["bioaod_0.png","bioaod_1.png","bioaod_2.png","bioaod_3.png","bioaod_4.png","bioaod_5.png","bioaod_6.png","bioaod_7.png","bioaod_8.png","bioaod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 333,
              font_array: ["bioaod_0.png","bioaod_1.png","bioaod_2.png","bioaod_3.png","bioaod_4.png","bioaod_5.png","bioaod_6.png","bioaod_7.png","bioaod_8.png","bioaod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 230,
              font_array: ["bio_0.png","bio_1.png","bio_2.png","bio_3.png","bio_4.png","bio_5.png","bio_6.png","bio_7.png","bio_8.png","bio_9.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'bionull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 303,
              am_y: 150,
              am_sc_path: 'timeaodam.png',
              am_en_path: 'timeaodam.png',
              pm_x: 303,
              pm_y: 150,
              pm_sc_path: 'timeaodpm.png',
              pm_en_path: 'timeaodpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 233,
              hour_startY: 195,
              hour_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 357,
              minute_startY: 195,
              minute_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 400,
              second_startY: 150,
              second_array: ["dataaod_0.png","dataaod_1.png","dataaod_2.png","dataaod_3.png","dataaod_4.png","dataaod_5.png","dataaod_6.png","dataaod_7.png","dataaod_8.png","dataaod_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 330,
              w: 110,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 390,
              w: 100,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 80,
              w: 100,
              h: 80,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 285,
              w: 115,
              h: 40,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 65,
              w: 100,
              h: 75,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 360,
              y: 200,
              w: 100,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 375,
              y: 143,
              w: 100,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 200,
              w: 100,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 330,
              w: 100,
              h: 55,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 105,
              w: 85,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 420,
              w: 120,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 215,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}