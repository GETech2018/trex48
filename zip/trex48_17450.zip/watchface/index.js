﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_bio_charge_text_text_img = ''
        let idle_bio_charge_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 150,
              font_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'battper.png',
              unit_tc: 'battper.png',
              unit_en: 'battper.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 150,
              src: 'batIcon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 100,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 320,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 225,
              day_startY: 365,
              day_sc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_tc_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_en_array: ["batt_0.png","batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 200,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 338,
              center_y: 240,
              x: 9,
              y: 59,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 200,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 141,
              center_y: 240,
              x: 9,
              y: 59,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'backgroundaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 150,
              font_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aodbattper.png',
              unit_tc: 'aodbattper.png',
              unit_en: 'aodbattper.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 150,
              src: 'aodbatIcon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 100,
              week_en: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_tc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_sc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 185,
              month_startY: 320,
              month_sc_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_tc_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_en_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 225,
              day_startY: 365,
              day_sc_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              day_tc_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              day_en_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 200,
              font_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'aodpointer.png',
              center_x: 338,
              center_y: 240,
              x: 9,
              y: 59,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 200,
              font_array: ["aodbatt_0.png","aodbatt_1.png","aodbatt_2.png","aodbatt_3.png","aodbatt_4.png","aodbatt_5.png","aodbatt_6.png","aodbatt_7.png","aodbatt_8.png","aodbatt_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'aodpointer.png',
              center_x: 141,
              center_y: 240,
              x: 9,
              y: 59,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodhour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 25,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodmin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 25,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 185,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 85,
              w: 90,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 195,
              w: 90,
              h: 90,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 290,
              y: 185,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 310,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}