﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 111,
              y: 96,
              src: 'icon-BellSimpleSlash.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 96,
              src: 'icon-BluetoothSlash.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 81,
              y: 96,
              src: 'icon-Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 91,
              font_array: ["digit-temp=0.png","digit-temp=1.png","digit-temp=2.png","digit-temp=3.png","digit-temp=4.png","digit-temp=5.png","digit-temp=6.png","digit-temp=7.png","digit-temp=8.png","digit-temp=9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'label-temp-celc.png',
              unit_tc: 'label-temp-celc.png',
              unit_en: 'label-temp-celc.png',
              imperial_unit_sc: 'label-temp-far.png',
              imperial_unit_tc: 'label-temp-far.png',
              imperial_unit_en: 'label-temp-far.png',
              negative_image: 'digit-temp=minus.png',
              invalid_image: 'digit-temp=null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 312,
                y: 91,
                font_array: ["digit-temp=0.png","digit-temp=1.png","digit-temp=2.png","digit-temp=3.png","digit-temp=4.png","digit-temp=5.png","digit-temp=6.png","digit-temp=7.png","digit-temp=8.png","digit-temp=9.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'label-temp-far.png',
                unit_tc: 'label-temp-far.png',
                unit_en: 'label-temp-far.png',
                imperial_unit_sc: 'label-temp-celc.png',
                imperial_unit_tc: 'label-temp-celc.png',
                imperial_unit_en: 'label-temp-celc.png',
                negative_image: 'digit-temp=minus.png',
                invalid_image: 'digit-temp=null.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 257,
              day_startY: 86,
              day_sc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_tc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_en_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 86,
              src: 'digit-dat=separator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 86,
              week_en: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_tc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_sc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setAlpha(150);

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 360,
              src: 'bat-0.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img.setAlpha(100);

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 233,
              y: 360,
              image_array: ["bat-1.png","bat-2.png","bat-3.png","bat-4.png","bat-5.png","bat-6.png","bat-7.png","bat-8.png","bat-9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 355,
              src: 'label-pai.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img.setAlpha(150);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 355,
              font_array: ["digit-pai=0.png","digit-pai=1.png","digit-pai=2.png","digit-pai=3.png","digit-pai=4.png","digit-pai=5.png","digit-pai=6.png","digit-pai=7.png","digit-pai=8.png","digit-pai=9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 355,
              src: 'pai-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 356,
              src: 'label-cal.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img.setAlpha(150);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 355,
              font_array: ["digit-cal=0.png","digit-cal=1.png","digit-cal=2.png","digit-cal=3.png","digit-cal=4.png","digit-cal=5.png","digit-cal=6.png","digit-cal=7.png","digit-cal=8.png","digit-cal=9.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 104,
              y: 356,
              src: 'cal-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 39,
              src: 'label-bio.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img.setAlpha(150);

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 90,
              radius: 236,
              line_width: 8,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFFF8A29,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 39,
              font_array: ["digit-bio=0.png","digit-bio=1.png","digit-bio=2.png","digit-bio=3.png","digit-bio=4.png","digit-bio=5.png","digit-bio=6.png","digit-bio=7.png","digit-bio=8.png","digit-bio=9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 41,
              src: 'bio-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 402,
              src: 'label-stp.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setAlpha(150);

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 270,
              // radius: 240,
              // line_width: 8,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 200,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 180,
              end_angle: 270,
              radius: 236,
              line_width: 8,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(200);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 402,
              font_array: ["digit-stp=0.png","digit-stp=1.png","digit-stp=2.png","digit-stp=3.png","digit-stp=4.png","digit-stp=5.png","digit-stp=6.png","digit-stp=7.png","digit-stp=8.png","digit-stp=9.png"],
              padding: true,
              h_space: 6,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 404,
              src: 'stp-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'label.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 47,
              am_y: 224,
              am_sc_path: 'format-am.png',
              am_en_path: 'format-am.png',
              pm_x: 47,
              pm_y: 224,
              pm_sc_path: 'format-pm.png',
              pm_en_path: 'format-pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 156,
              hour_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              hour_zero: 1,
              hour_space: 19,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 156,
              minute_array: ["digit-minute=0.png","digit-minute=1.png","digit-minute=2.png","digit-minute=3.png","digit-minute=4.png","digit-minute=5.png","digit-minute=6.png","digit-minute=7.png","digit-minute=8.png","digit-minute=9.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 393,
              second_startY: 213,
              second_array: ["digit-sec=0.png","digit-sec=1.png","digit-sec=2.png","digit-sec=3.png","digit-sec=4.png","digit-sec=5.png","digit-sec=6.png","digit-sec=7.png","digit-sec=8.png","digit-sec=9.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 393,
              y: 213,
              src: 'sec-back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 257,
              day_startY: 86,
              day_sc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_tc_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_en_array: ["digit-dat=0.png","digit-dat=1.png","digit-dat=2.png","digit-dat=3.png","digit-dat=4.png","digit-dat=5.png","digit-dat=6.png","digit-dat=7.png","digit-dat=8.png","digit-dat=9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              // alpha: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day.setAlpha(200);

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 86,
              src: 'digit-dat=separator.png',
              // alpha: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img.setAlpha(200);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 86,
              week_en: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_tc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              week_sc: ["digit-day=1.png","digit-day=2.png","digit-day=3.png","digit-day=4.png","digit-day=5.png","digit-day=6.png","digit-day=7.png"],
              // alpha: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(200);

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 47,
              am_y: 224,
              am_sc_path: 'format-am.png',
              am_en_path: 'format-am.png',
              pm_x: 47,
              pm_y: 224,
              pm_sc_path: 'format-pm.png',
              pm_en_path: 'format-pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 156,
              hour_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              hour_zero: 1,
              hour_space: 19,
              hour_angle: 0,
              alpha: 200,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 156,
              minute_array: ["digit-main=0.png","digit-main=1.png","digit-main=2.png","digit-main=3.png","digit-main=4.png","digit-main=5.png","digit-main=6.png","digit-main=7.png","digit-main=8.png","digit-main=9.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 200,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'up-img-scale.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 403,
              w: 150,
              h: 35,
              src: 'emp.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 352,
              w: 100,
              h: 40,
              src: 'emp.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 352,
              w: 66,
              h: 40,
              src: 'emp.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 319,
              y: 92,
              w: 80,
              h: 40,
              src: 'emp.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 352,
              w: 110,
              h: 40,
              src: 'emp.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 85,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 36,
              w: 122,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 251,
              y: 158,
              w: 126,
              h: 170,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 101,
              y: 156,
              w: 126,
              h: 170,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 394,
              y: 213,
              w: 50,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'emp.png',
              normal_src: 'emp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 180,
                      end_angle: 270,
                      radius: 236,
                      line_width: 8,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}