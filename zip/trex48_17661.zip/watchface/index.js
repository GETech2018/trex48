﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_body_temp_text_text_img = ''
        let normal_body_temp_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_hrv_text_text_img = ''
        let normal_hrv_image_progress_img_level = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_sleep_score_font = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_day_text_font = ''
        let normal_month_text_font = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sa', 'Do'];
        let idle_year_text_font = ''
        let idle_month_text_font = ''
        let idle_day_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_bodyTemp_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 160,
              w: 132,
              h: 31,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 143,
              src: '44.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 160,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 47,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 319,
              y: 57,
              image_array: ["157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png"],
              image_length: 10,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 121,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 123,
              image_array: ["242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png","250.png","251.png"],
              image_length: 10,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 90,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 356,
              y: 96,
              image_array: ["222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png","230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png","238.png","239.png","240.png","241.png"],
              image_length: 20,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 317,
              y: 153,
              w: 150,
              h: 45,
              text_size: 35,
              char_space: 0,
              color: 0xFFC5FECD,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 335,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 262,
              minute_startY: 335,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 381,
              second_startY: 335,
              second_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 377,
              am_y: 378,
              am_sc_path: '23.png',
              am_en_path: '23.png',
              pm_x: 377,
              pm_y: 378,
              pm_sc_path: '24.png',
              pm_en_path: '24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 329,
              w: 48,
              h: 50,
              text_size: 40,
              char_space: 0,
              color: 0xFF80FFFF,
              line_space: 1,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 61,
              y: 368,
              w: 48,
              h: 48,
              text_size: 40,
              char_space: 0,
              color: 0xFF80FFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 236,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: -2,
              unit_sc: '209.png',
              unit_tc: '209.png',
              unit_en: '209.png',
              imperial_unit_sc: '210.png',
              imperial_unit_tc: '210.png',
              imperial_unit_en: '210.png',
              dot_image: '44.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 236,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: 0,
              invalid_image: '45.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 204,
              image_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png"],
              image_length: 12,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 96,
              y: 57,
              image_array: ["59.png","60.png","61.png","62.png","63.png","64.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 47,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              invalid_image: '69.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 295,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: -1,
              unit_sc: '72.png',
              unit_tc: '72.png',
              unit_en: '72.png',
              invalid_image: '71.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 295,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: -1,
              invalid_image: '74.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 294,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: -1,
              invalid_image: '86.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 159,
              y: 294,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: -1,
              invalid_image: '98.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["252.png","253.png","254.png","255.png","256.png","257.png","258.png","259.png","260.png","261.png","262.png","263.png","264.png","265.png","266.png","267.png","268.png","269.png","270.png","271.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 405,
              y: 280,
              w: 51,
              h: 51,
              text_size: 41,
              char_space: 0,
              color: 0xFFACD7EE,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 236,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              invalid_image: '167.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 236,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 295,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: 0,
              unit_sc: '208.png',
              unit_tc: '208.png',
              unit_en: '208.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 24,
              y: 277,
              image_array: ["172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png","193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 396,
              y: 235,
              font_array: ["25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png"],
              padding: false,
              h_space: 0,
              invalid_image: '201.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 127,
              y: 430,
              src: '203.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 427,
              src: '204.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '205.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 241,
              y: 80,
              image_array: ["171.png","172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png","193.png","194.png","195.png","196.png","197.png","198.png","199.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 224,
              y: 102,
              w: 66,
              h: 50,
              text_size: 40,
              char_space: 0,
              color: 0xFFFFFF80,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 39,
              y: 214,
              w: 84,
              h: 60,
              text_size: 45,
              char_space: 0,
              color: 0xFFFFFF80,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Lu, Ma, Mi, Ju, Vi, Sa, Do,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 286,
              y: 274,
              w: 102,
              h: 55,
              text_size: 45,
              char_space: 0,
              color: 0xFFFFFF80,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 209,
              y: 274,
              w: 55,
              h: 55,
              text_size: 45,
              char_space: 0,
              color: 0xFFFFFF80,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 125,
              y: 274,
              w: 54,
              h: 54,
              text_size: 45,
              char_space: 0,
              color: 0xFFFFFF80,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 191,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 282,
              minute_startY: 191,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 399,
              am_y: 247,
              am_sc_path: '206.png',
              am_en_path: '206.png',
              pm_x: 399,
              pm_y: 247,
              pm_sc_path: '207.png',
              pm_en_path: '207.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_bodyTemp_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 171,
              y: 157,
              w: 145,
              h: 37,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 156,
              w: 163,
              h: 40,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: -1,
              w: 183,
              h: 86,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 316,
              y: 156,
              w: 153,
              h: 38,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 0,
              w: 178,
              h: 84,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 271,
              w: 84,
              h: 55,
              src: '99.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 194,
              w: 167,
              h: 76,
              src: '168.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 271,
              w: 147,
              h: 56,
              src: '171.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 21,
              y: 329,
              w: 215,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 13,
              press_src: 'transpa.png',
              normal_src: 'transpa.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 388,
              y: 271,
              w: 86,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 13,
              press_src: 'transpa.png',
              normal_src: 'transpa.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 255,
              y: 329,
              w: 201,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 13,
              press_src: 'transpa.png',
              normal_src: 'transpa.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_dndScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 88,
              y: 425,
              w: 310,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 13,
              press_src: 'transpa.png',
              normal_src: 'transpa.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let normal_monthStr = timeSensor.month.toString();
                normal_monthStr = normal_monthStr.padStart(2, '0');
                normal_month_text_font.setProperty(hmUI.prop.TEXT, normal_monthStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('year font');
              if (updateHour) {
                let idle_yearStr = timeSensor.year.toString();
                idle_year_text_font.setProperty(hmUI.prop.TEXT, idle_yearStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_monthStr = timeSensor.month.toString();
                idle_monthStr = idle_monthStr.padStart(2, '0');
                idle_month_text_font.setProperty(hmUI.prop.TEXT, idle_monthStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                sleep_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}