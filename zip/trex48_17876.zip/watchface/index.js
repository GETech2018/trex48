﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_training_load_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_stress_text_text_img = ''
        let idle_stress_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_bio_charge_icon_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_vo2max_text_text_img = ''
        let idle_hrv_text_text_img = ''
        let idle_training_load_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_outdoorRunning_jumpable_img_click = ''
        let normal_trainingLoad_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 52,
              font_array: ["fontbig_0.png","fontbig_1.png","fontbig_2.png","fontbig_3.png","fontbig_4.png","fontbig_5.png","fontbig_6.png","fontbig_7.png","fontbig_8.png","fontbig_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'h_unit.png',
              unit_tc: 'h_unit.png',
              unit_en: 'h_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 52,
              src: 'icon_recover.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 118,
              y: 160,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 160,
              day_sc_array: ["fontsmall_0.png","fontsmall_1.png","fontsmall_2.png","fontsmall_3.png","fontsmall_4.png","fontsmall_5.png","fontsmall_6.png","fontsmall_7.png","fontsmall_8.png","fontsmall_9.png"],
              day_tc_array: ["fontsmall_0.png","fontsmall_1.png","fontsmall_2.png","fontsmall_3.png","fontsmall_4.png","fontsmall_5.png","fontsmall_6.png","fontsmall_7.png","fontsmall_8.png","fontsmall_9.png"],
              day_en_array: ["fontsmall_0.png","fontsmall_1.png","fontsmall_2.png","fontsmall_3.png","fontsmall_4.png","fontsmall_5.png","fontsmall_6.png","fontsmall_7.png","fontsmall_8.png","fontsmall_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 201,
              src: 'icon_run.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 67,
              font_array: ["fontmid_0.png","fontmid_1.png","fontmid_2.png","fontmid_3.png","fontmid_4.png","fontmid_5.png","fontmid_6.png","fontmid_7.png","fontmid_8.png","fontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'fontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 149,
              font_array: ["fontmid_0.png","fontmid_1.png","fontmid_2.png","fontmid_3.png","fontmid_4.png","fontmid_5.png","fontmid_6.png","fontmid_7.png","fontmid_8.png","fontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'fontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 242,
              font_array: ["fontmid_0.png","fontmid_1.png","fontmid_2.png","fontmid_3.png","fontmid_4.png","fontmid_5.png","fontmid_6.png","fontmid_7.png","fontmid_8.png","fontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'fontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 324,
              font_array: ["fontmid_0.png","fontmid_1.png","fontmid_2.png","fontmid_3.png","fontmid_4.png","fontmid_5.png","fontmid_6.png","fontmid_7.png","fontmid_8.png","fontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'fontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 397,
              font_array: ["fontmid_0.png","fontmid_1.png","fontmid_2.png","fontmid_3.png","fontmid_4.png","fontmid_5.png","fontmid_6.png","fontmid_7.png","fontmid_8.png","fontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'fontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 397,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 227,
              hour_startY: 103,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 227,
              minute_startY: 247,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 422,
              second_startY: 221,
              second_array: ["sec_0.png","sec_1.png","sec_2.png","sec_3.png","sec_4.png","sec_5.png","sec_6.png","sec_7.png","sec_8.png","sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bgaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 52,
              font_array: ["aodfontbig_0.png","aodfontbig_1.png","aodfontbig_2.png","aodfontbig_3.png","aodfontbig_4.png","aodfontbig_5.png","aodfontbig_6.png","aodfontbig_7.png","aodfontbig_8.png","aodfontbig_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'h_unitaod.png',
              unit_tc: 'h_unitaod.png',
              unit_en: 'h_unitaod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 52,
              src: 'icon_recoveraod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 118,
              y: 160,
              week_en: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_tc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_sc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 160,
              day_sc_array: ["aodfontsmall_0.png","aodfontsmall_1.png","aodfontsmall_2.png","aodfontsmall_3.png","aodfontsmall_4.png","aodfontsmall_5.png","aodfontsmall_6.png","aodfontsmall_7.png","aodfontsmall_8.png","aodfontsmall_9.png"],
              day_tc_array: ["aodfontsmall_0.png","aodfontsmall_1.png","aodfontsmall_2.png","aodfontsmall_3.png","aodfontsmall_4.png","aodfontsmall_5.png","aodfontsmall_6.png","aodfontsmall_7.png","aodfontsmall_8.png","aodfontsmall_9.png"],
              day_en_array: ["aodfontsmall_0.png","aodfontsmall_1.png","aodfontsmall_2.png","aodfontsmall_3.png","aodfontsmall_4.png","aodfontsmall_5.png","aodfontsmall_6.png","aodfontsmall_7.png","aodfontsmall_8.png","aodfontsmall_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 201,
              src: 'icon_runaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 67,
              font_array: ["aodfontmid_0.png","aodfontmid_1.png","aodfontmid_2.png","aodfontmid_3.png","aodfontmid_4.png","aodfontmid_5.png","aodfontmid_6.png","aodfontmid_7.png","aodfontmid_8.png","aodfontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodfontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 149,
              font_array: ["aodfontmid_0.png","aodfontmid_1.png","aodfontmid_2.png","aodfontmid_3.png","aodfontmid_4.png","aodfontmid_5.png","aodfontmid_6.png","aodfontmid_7.png","aodfontmid_8.png","aodfontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodfontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 242,
              font_array: ["aodfontmid_0.png","aodfontmid_1.png","aodfontmid_2.png","aodfontmid_3.png","aodfontmid_4.png","aodfontmid_5.png","aodfontmid_6.png","aodfontmid_7.png","aodfontmid_8.png","aodfontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodfontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 324,
              font_array: ["aodfontmid_0.png","aodfontmid_1.png","aodfontmid_2.png","aodfontmid_3.png","aodfontmid_4.png","aodfontmid_5.png","aodfontmid_6.png","aodfontmid_7.png","aodfontmid_8.png","aodfontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodfontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 397,
              font_array: ["aodfontmid_0.png","aodfontmid_1.png","aodfontmid_2.png","aodfontmid_3.png","aodfontmid_4.png","aodfontmid_5.png","aodfontmid_6.png","aodfontmid_7.png","aodfontmid_8.png","aodfontmid_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodfontmidnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 397,
              src: 'icon_heartaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 227,
              hour_startY: 103,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 227,
              minute_startY: 247,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 108,
              src: 'gradient.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 386,
              w: 103,
              h: 82,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 258,
              w: 103,
              h: 103,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 412,
              y: 180,
              w: 103,
              h: 103,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 113,
              w: 103,
              h: 103,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_outdoorRunning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 216,
              w: 82,
              h: 93,
              type: hmUI.data_type.OUTDOOR_RUNNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_trainingLoad_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 330,
              w: 103,
              h: 77,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 149,
              w: 103,
              h: 77,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 52,
              y: 62,
              w: 103,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 237,
              w: 103,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 129,
              y: 144,
              w: 103,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}