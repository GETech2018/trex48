﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 16;
        let normal_sunrise_TextCircle_img_height = 25;
        let normal_sunrise_TextCircle_dot_width = 4;
        let normal_sunrise_TextCircle_error_img_width = 25;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 16;
        let normal_sunset_TextCircle_img_height = 25;
        let normal_sunset_TextCircle_dot_width = 4;
        let normal_sunset_TextCircle_error_img_width = 25;
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_sleep_score_font = ''
        let normal_training_load_text_text_img = ''
        let normal_training_load_image_progress_img_level = ''
        let normal_vo2max_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_sunrise_TextCircle = new Array(5);
        let idle_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunrise_TextCircle_img_width = 16;
        let idle_sunrise_TextCircle_img_height = 25;
        let idle_sunrise_TextCircle_dot_width = 4;
        let idle_sunrise_TextCircle_error_img_width = 25;
        let idle_sunset_TextCircle = new Array(5);
        let idle_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let idle_sunset_TextCircle_img_width = 16;
        let idle_sunset_TextCircle_img_height = 25;
        let idle_sunset_TextCircle_dot_width = 4;
        let idle_sunset_TextCircle_error_img_width = 25;
        let idle_stand_current_text_img = ''
        let idle_stand_image_progress_img_level = ''
        let idle_uvi_text_text_img = ''
        let idle_uvi_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_sleep_score_font = ''
        let idle_training_load_text_text_img = ''
        let idle_training_load_image_progress_img_level = ''
        let idle_vo2max_text_text_img = ''
        let idle_hrv_text_text_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_trainingLoad_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_recoveryTime_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let sleepSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 247,
              // circle_center_Y: 247,
              // font_array: ["fontsun_0.png","fontsun_1.png","fontsun_2.png","fontsun_3.png","fontsun_4.png","fontsun_5.png","fontsun_6.png","fontsun_7.png","fontsun_8.png","fontsun_9.png"],
              // radius: 213,
              // angle: -24,
              // char_space_angle: 0,
              // dot_image: 'maohao.png',
              // error_image: 'fontsunnull.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'fontsun_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'fontsun_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'fontsun_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'fontsun_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'fontsun_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'fontsun_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'fontsun_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'fontsun_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'fontsun_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'fontsun_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 247,
                center_y: 247,
                pos_x: 247 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 247 - 238,
                src: 'fontsun_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 247,
              // circle_center_Y: 247,
              // font_array: ["fontsun_0.png","fontsun_1.png","fontsun_2.png","fontsun_3.png","fontsun_4.png","fontsun_5.png","fontsun_6.png","fontsun_7.png","fontsun_8.png","fontsun_9.png"],
              // radius: 207,
              // angle: 20,
              // char_space_angle: 0,
              // dot_image: 'maohao.png',
              // error_image: 'fontsunnull.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'fontsun_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'fontsun_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'fontsun_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'fontsun_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'fontsun_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'fontsun_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'fontsun_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'fontsun_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'fontsun_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'fontsun_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 247,
                center_y: 247,
                pos_x: 247 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 247 - 232,
                src: 'fontsun_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 108,
              font_array: ["largefont_0.png","largefont_1.png","largefont_2.png","largefont_3.png","largefont_4.png","largefont_5.png","largefont_6.png","largefont_7.png","largefont_8.png","largefont_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 46,
              image_array: ["recoverylvl_1.png","recoverylvl_2.png","recoverylvl_3.png","recoverylvl_4.png","recoverylvl_5.png","recoverylvl_6.png","recoverylvl_7.png","recoverylvl_8.png","recoverylvl_9.png","recoverylvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 304,
              font_array: ["middlefont_0.png","middlefont_1.png","middlefont_2.png","middlefont_3.png","middlefont_4.png","middlefont_5.png","middlefont_6.png","middlefont_7.png","middlefont_8.png","middlefont_9.png"],
              padding: false,
              h_space: 0,
              angle: 67,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 167,
              image_array: ["uvilvl_1.png","uvilvl_2.png","uvilvl_3.png","uvilvl_4.png","uvilvl_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 158,
              font_array: ["middlefont_0.png","middlefont_1.png","middlefont_2.png","middlefont_3.png","middlefont_4.png","middlefont_5.png","middlefont_6.png","middlefont_7.png","middlefont_8.png","middlefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'middlefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 290,
              y: 147,
              w: 155,
              h: 36,
              text_size: 29,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 406,
              y: 340,
              font_array: ["middlefont_0.png","middlefont_1.png","middlefont_2.png","middlefont_3.png","middlefont_4.png","middlefont_5.png","middlefont_6.png","middlefont_7.png","middlefont_8.png","middlefont_9.png"],
              padding: false,
              h_space: 0,
              angle: -61,
              invalid_image: 'middlefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 422,
              y: 167,
              image_array: ["epoclvl_1.png","epoclvl_2.png","epoclvl_3.png"],
              image_length: 3,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 263,
              font_array: ["largefont_0.png","largefont_1.png","largefont_2.png","largefont_3.png","largefont_4.png","largefont_5.png","largefont_6.png","largefont_7.png","largefont_8.png","largefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'largefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 263,
              font_array: ["largefont_0.png","largefont_1.png","largefont_2.png","largefont_3.png","largefont_4.png","largefont_5.png","largefont_6.png","largefont_7.png","largefont_8.png","largefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'largefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 263,
              font_array: ["largefont_0.png","largefont_1.png","largefont_2.png","largefont_3.png","largefont_4.png","largefont_5.png","largefont_6.png","largefont_7.png","largefont_8.png","largefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'largefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 422,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 422,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 273,
              day_startY: 424,
              day_sc_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_tc_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_en_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 182,
              am_y: 194,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 182,
              pm_y: 194,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 331,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 331,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 247,
              // circle_center_Y: 247,
              // font_array: ["aodfontsun_0.png","aodfontsun_1.png","aodfontsun_2.png","aodfontsun_3.png","aodfontsun_4.png","aodfontsun_5.png","aodfontsun_6.png","aodfontsun_7.png","aodfontsun_8.png","aodfontsun_9.png"],
              // radius: 213,
              // angle: -24,
              // char_space_angle: 0,
              // dot_image: 'aodmaohao.png',
              // error_image: 'aodfontsunnull.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunrise_TextCircle_ASCIIARRAY[0] = 'aodfontsun_0.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[1] = 'aodfontsun_1.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[2] = 'aodfontsun_2.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[3] = 'aodfontsun_3.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[4] = 'aodfontsun_4.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[5] = 'aodfontsun_5.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[6] = 'aodfontsun_6.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[7] = 'aodfontsun_7.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[8] = 'aodfontsun_8.png';  // set of images with numbers
            idle_sunrise_TextCircle_ASCIIARRAY[9] = 'aodfontsun_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 247,
                center_y: 247,
                pos_x: 247 - idle_sunrise_TextCircle_img_width / 2,
                pos_y: 247 - 238,
                src: 'aodfontsun_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 247,
              // circle_center_Y: 247,
              // font_array: ["aodfontsun_0.png","aodfontsun_1.png","aodfontsun_2.png","aodfontsun_3.png","aodfontsun_4.png","aodfontsun_5.png","aodfontsun_6.png","aodfontsun_7.png","aodfontsun_8.png","aodfontsun_9.png"],
              // radius: 207,
              // angle: 20,
              // char_space_angle: 0,
              // dot_image: 'aodmaohao.png',
              // error_image: 'aodfontsunnull.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_sunset_TextCircle_ASCIIARRAY[0] = 'aodfontsun_0.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[1] = 'aodfontsun_1.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[2] = 'aodfontsun_2.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[3] = 'aodfontsun_3.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[4] = 'aodfontsun_4.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[5] = 'aodfontsun_5.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[6] = 'aodfontsun_6.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[7] = 'aodfontsun_7.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[8] = 'aodfontsun_8.png';  // set of images with numbers
            idle_sunset_TextCircle_ASCIIARRAY[9] = 'aodfontsun_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 247,
                center_y: 247,
                pos_x: 247 - idle_sunset_TextCircle_img_width / 2,
                pos_y: 247 - 232,
                src: 'aodfontsun_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 108,
              font_array: ["aodlargefont_0.png","aodlargefont_1.png","aodlargefont_2.png","aodlargefont_3.png","aodlargefont_4.png","aodlargefont_5.png","aodlargefont_6.png","aodlargefont_7.png","aodlargefont_8.png","aodlargefont_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 46,
              image_array: ["aodrecoverylvl_1.png","aodrecoverylvl_2.png","aodrecoverylvl_3.png","aodrecoverylvl_4.png","aodrecoverylvl_5.png","aodrecoverylvl_6.png","aodrecoverylvl_7.png","aodrecoverylvl_8.png","aodrecoverylvl_9.png","aodrecoverylvl_10.png"],
              image_length: 10,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 304,
              font_array: ["aodmiddlefont_0.png","aodmiddlefont_1.png","aodmiddlefont_2.png","aodmiddlefont_3.png","aodmiddlefont_4.png","aodmiddlefont_5.png","aodmiddlefont_6.png","aodmiddlefont_7.png","aodmiddlefont_8.png","aodmiddlefont_9.png"],
              padding: false,
              h_space: 0,
              angle: 67,
              invalid_image: 'aodmiddlefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 167,
              image_array: ["aoduvilvl_1.png","aoduvilvl_2.png","aoduvilvl_3.png","aoduvilvl_4.png","aoduvilvl_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 158,
              font_array: ["aodmiddlefont_0.png","aodmiddlefont_1.png","aodmiddlefont_2.png","aodmiddlefont_3.png","aodmiddlefont_4.png","aodmiddlefont_5.png","aodmiddlefont_6.png","aodmiddlefont_7.png","aodmiddlefont_8.png","aodmiddlefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodmiddlefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_score_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 290,
              y: 147,
              w: 155,
              h: 36,
              text_size: 29,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 406,
              y: 340,
              font_array: ["aodmiddlefont_0.png","aodmiddlefont_1.png","aodmiddlefont_2.png","aodmiddlefont_3.png","aodmiddlefont_4.png","aodmiddlefont_5.png","aodmiddlefont_6.png","aodmiddlefont_7.png","aodmiddlefont_8.png","aodmiddlefont_9.png"],
              padding: false,
              h_space: 0,
              angle: -61,
              invalid_image: 'aodmiddlefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_training_load_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 422,
              y: 167,
              image_array: ["epoclevelcaod_1.png","epoclevelcaod_2.png","epoclevelcaod_3.png"],
              image_length: 3,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 87,
              y: 263,
              font_array: ["aodlargefont_0.png","aodlargefont_1.png","aodlargefont_2.png","aodlargefont_3.png","aodlargefont_4.png","aodlargefont_5.png","aodlargefont_6.png","aodlargefont_7.png","aodlargefont_8.png","aodlargefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodlargefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 333,
              y: 263,
              font_array: ["aodlargefont_0.png","aodlargefont_1.png","aodlargefont_2.png","aodlargefont_3.png","aodlargefont_4.png","aodlargefont_5.png","aodlargefont_6.png","aodlargefont_7.png","aodlargefont_8.png","aodlargefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodlargefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 263,
              font_array: ["aodlargefont_0.png","aodlargefont_1.png","aodlargefont_2.png","aodlargefont_3.png","aodlargefont_4.png","aodlargefont_5.png","aodlargefont_6.png","aodlargefont_7.png","aodlargefont_8.png","aodlargefont_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodlargefontnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 422,
              month_sc_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_tc_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_en_array: ["aodmonth_1.png","aodmonth_2.png","aodmonth_3.png","aodmonth_4.png","aodmonth_5.png","aodmonth_6.png","aodmonth_7.png","aodmonth_8.png","aodmonth_9.png","aodmonth_10.png","aodmonth_11.png","aodmonth_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 422,
              week_en: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_tc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_sc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 273,
              day_startY: 424,
              day_sc_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_tc_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_en_array: ["aodsmallfont_0.png","aodsmallfont_1.png","aodsmallfont_2.png","aodsmallfont_3.png","aodsmallfont_4.png","aodsmallfont_5.png","aodsmallfont_6.png","aodsmallfont_7.png","aodsmallfont_8.png","aodsmallfont_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 182,
              am_y: 194,
              am_sc_path: 'amaod.png',
              am_en_path: 'amaod.png',
              pm_x: 182,
              pm_y: 194,
              pm_sc_path: 'pmaod.png',
              pm_en_path: 'pmaod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 331,
              hour_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 254,
              minute_startY: 331,
              minute_array: ["aodtime_0.png","aodtime_1.png","aodtime_2.png","aodtime_3.png","aodtime_4.png","aodtime_5.png","aodtime_6.png","aodtime_7.png","aodtime_8.png","aodtime_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 118,
              w: 77,
              h: 77,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 313,
              w: 77,
              h: 103,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 330,
              w: 103,
              h: 77,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 273,
              y: 330,
              w: 103,
              h: 77,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 118,
              w: 77,
              h: 77,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_trainingLoad_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 386,
              y: 313,
              w: 103,
              h: 103,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 232,
              w: 103,
              h: 77,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_recoveryTime_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 82,
              w: 103,
              h: 103,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 232,
              w: 103,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 417,
              w: 103,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 314,
              y: 232,
              w: 103,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -24;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 213));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 213));
                  // alignment = CENTER_H
                  let normal_sunrise_TextCircle_angleOffset = normal_sunrise_TextCircle_img_angle * (normal_sunrise_circle_string.length - 1);
                  char_Angle -= normal_sunrise_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'maohao.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.POS_X, 247 - normal_sunrise_TextCircle_error_img_width / 2);
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.SRC, 'fontsunnull.png');
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 20;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 207));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 207));
                  // alignment = CENTER_H
                  let normal_sunset_TextCircle_angleOffset = normal_sunset_TextCircle_img_angle * (normal_sunset_circle_string.length - 1);
                  char_Angle -= normal_sunset_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'maohao.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.POS_X, 247 - normal_sunset_TextCircle_error_img_width / 2);
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.SRC, 'fontsunnull.png');
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle sunrise_tideData');
              let idle_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                idle_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -24;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && idle_sunrise_circle_string.length > 0 && idle_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_sunrise_TextCircle_img_angle = 0;
                  let idle_sunrise_TextCircle_dot_img_angle = 0;
                  idle_sunrise_TextCircle_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_img_width/2, 213));
                  idle_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunrise_TextCircle_dot_width/2, 213));
                  // alignment = CENTER_H
                  let idle_sunrise_TextCircle_angleOffset = idle_sunrise_TextCircle_img_angle * (idle_sunrise_circle_string.length - 1);
                  char_Angle -= idle_sunrise_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - idle_sunrise_TextCircle_img_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - idle_sunrise_TextCircle_dot_width / 2);
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'aodmaohao.png');
                      idle_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunrise_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunrise_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_sunrise_TextCircle[0].setProperty(hmUI.prop.POS_X, 247 - idle_sunrise_TextCircle_error_img_width / 2);
                  idle_sunrise_TextCircle[0].setProperty(hmUI.prop.SRC, 'aodfontsunnull.png');
                  idle_sunrise_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle sunset_tideData');
              let idle_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                idle_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 20;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && idle_sunset_circle_string.length > 0 && idle_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_sunset_TextCircle_img_angle = 0;
                  let idle_sunset_TextCircle_dot_img_angle = 0;
                  idle_sunset_TextCircle_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_img_width/2, 207));
                  idle_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(idle_sunset_TextCircle_dot_width/2, 207));
                  // alignment = CENTER_H
                  let idle_sunset_TextCircle_angleOffset = idle_sunset_TextCircle_img_angle * (idle_sunset_circle_string.length - 1);
                  char_Angle -= idle_sunset_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - idle_sunset_TextCircle_img_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, idle_sunset_TextCircle_ASCIIARRAY[charCode]);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += idle_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 247 - idle_sunset_TextCircle_dot_width / 2);
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'aodmaohao.png');
                      idle_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_sunset_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_sunset_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_sunset_TextCircle[0].setProperty(hmUI.prop.POS_X, 247 - idle_sunset_TextCircle_error_img_width / 2);
                  idle_sunset_TextCircle[0].setProperty(hmUI.prop.SRC, 'aodfontsunnull.png');
                  idle_sunset_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              console.log('sleep_update()');
              let sleepInfo = sleepSensor.getBasicInfo();

              console.log('sleep score');
              let sleepScore = sleepInfo.score;
              if (normal_sleep_score_font) normal_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

              console.log('sleep score');
              if (idle_sleep_score_font) idle_sleep_score_font.setProperty(hmUI.prop.TEXT, String(sleepScore));

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                sleep_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}