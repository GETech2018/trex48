﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_uvi_icon_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_pressure_text_text_img = ''
        let normal_wind_speed_text_img = ''
        let normal_spo2_pointer_progress_img_pointer = ''
        let normal_humidity_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_readiness_icon_img = ''
        let normal_vo2max_icon_img = ''
        let normal_vo2max_pointer_progress_img_pointer = ''
        let normal_vo2max_text_text_img = ''
        let normal_training_load_pointer_progress_img_pointer = ''
        let normal_training_load_text_text_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_recovery_time_text_img = ''
		let normal_recovery_time_pointer_progress_img_pointer = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_text_text_img = ''
        let normal_hrv_icon_img = ''
        let normal_hrv_pointer_progress_img_pointer = ''
        let normal_hrv_text_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_spo2_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_stress_pointer_progress_img_pointer = ''
        let normal_stress_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_fat_burning_image_progress_img_level = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_floor_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_digital_clock_img_time = ''
		let normal_digital_clock_img_time_1 = ''
		let normal_digital_clock_img_time_2 = ''
		let normal_digital_clock_img_time_3 = ''
		let normal_digital_clock_img_time_4 = ''
        let normal_timeZone_gmt_text = ''
        let worldClockIndex = 0
        let normal_time_gmt_text = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_outdoorRunning_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let normal_outdoorCycling_jumpable_img_click = ''
        let normal_freeTraining_jumpable_img_click = ''
        let normal_poolSwimming_jumpable_img_click = ''
        let normal_openWaterSwimming_jumpable_img_click = ''
        let normal_trainingLoad_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_recoveryTime_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let GMT_Button_NextSity = ''
        let GMT_Button_PreviewSity = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
		let Button_4 = ''
        let timeSensor = '';
        let worldClock = '';
        worldClockIndex = hmFS.SysProGetInt('worldClockIndex') ?? 0;;
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_stress_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 700; 
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona1_num) {
			   case 0:
					url = 'StressHomeScreen';
				break;
			   case 1:
					url = 'BioChargeHomeScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }
		
		let cc = 0
		
		let element_index = 0; 
        let element_count = 6;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_floor_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_hrv_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_hrv_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_spo2_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 0);

              normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_fat_burning_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  
			  normal_vo2max_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_vo2max_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_vo2max_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_recovery_time_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
		      normal_recovery_time_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_trainingLoad_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_vo2max_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_recoveryTime_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_outdoorCycling_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_poolSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_openWaterSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_pressure_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 5);
        };
		
		let block = 0
        function block_on() {
        block = 1
        normal_moon_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_on.png'
        );
        Button_1.setProperty(hmUI.prop.VISIBLE, false);
        Button_2.setProperty(hmUI.prop.VISIBLE, false);
        Button_3.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_outdoorCycling_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_poolSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_openWaterSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_trainingLoad_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_vo2max_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_recoveryTime_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		GMT_Button_NextSity.setProperty(hmUI.prop.VISIBLE, false);
		GMT_Button_PreviewSity.setProperty(hmUI.prop.VISIBLE, false);
        btn_zona1.setProperty(hmUI.prop.VISIBLE, false);
        }

        function block_off() {
        block = 0
        normal_moon_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_off.png');
        Button_1.setProperty(hmUI.prop.VISIBLE, true);
        Button_2.setProperty(hmUI.prop.VISIBLE, true);
        Button_3.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_outdoorCycling_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_poolSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_openWaterSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_trainingLoad_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_vo2max_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_recoveryTime_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
		GMT_Button_NextSity.setProperty(hmUI.prop.VISIBLE, true);
		GMT_Button_PreviewSity.setProperty(hmUI.prop.VISIBLE, true);
        }


        function widget_start() {
	
        normal_moon_icon_img.setProperty(hmUI.prop.SRC, 'ic_block_off.png');
	
        Button_1.setProperty(hmUI.prop.VISIBLE, true);
        Button_2.setProperty(hmUI.prop.VISIBLE, true);
        Button_3.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_outdoorCycling_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_poolSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_openWaterSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_trainingLoad_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_vo2max_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_recoveryTime_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
		GMT_Button_NextSity.setProperty(hmUI.prop.VISIBLE, true);
		GMT_Button_PreviewSity.setProperty(hmUI.prop.VISIBLE, true);
        Button_4.setProperty(hmUI.prop.VISIBLE, false);
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Bebas11_22.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bebas11_22.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			// FontName: Bebas11_22.ttf; FontSize: 35; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 42,
              h: 42,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bebas11_22.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 415,
              y: 223,
              src: 'ic_block_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 32,
              y: 226,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'sunback.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sunmoon_sun.png',
              center_x: 175,
              center_y: 294,
              x: 48,
              y: 91,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 79,
              y: 198,
              src: 'suntop.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 300,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dsots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 118,
              y: 227,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 280,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              negative_image: 'minus1.png',
              dot_image: 'sl2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 218,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 342,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BARO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 342,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 342,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 247,
              month_startY: 11,
              month_sc_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              month_tc_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              month_en_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 11,
              day_sc_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              day_tc_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              day_en_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'sl1.png',
              day_unit_tc: 'sl1.png',
              day_unit_en: 'sl1.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 136,
              y: 50,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'train.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'training.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 127,
              center_y: 249,
              x: 8,
              y: 43,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 230,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 127,
              center_y: 336,
              x: 8,
              y: 43,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 324,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 219,
              center_y: 336,
              x: 8,
              y: 43,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 324,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_recovery_time_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 219,
              center_y: 249,
              x: 8,
              y: 43,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_recovery_time_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 230,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 92,
              src: 'bio.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 127,
              center_y: 136,
              x: 8,
              y: 47,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 115,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 92,
              src: 'hrv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 343,
              center_y: 136,
              x: 8,
              y: 47,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 115,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 92,
              src: 'spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 115,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_spo2_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 236,
              center_y: 136,
              x: 8,
              y: 47,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 82,
              y: 92,
              src: 'stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 127,
              center_y: 136,
              x: 8,
              y: 47,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 115,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 325,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 297,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png","batt_11.png","batt_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'A100_233.png',
              center_x: 345,
              center_y: 239,
              x: 7,
              y: 46,
              start_angle: -130,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 219,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'activity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 236,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 87,
              y: 210,
              image_array: ["fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png","fat_10.png"],
              image_length: 10,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 128,
              y: 319,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 319,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'sl.png',
              unit_tc: 'sl.png',
              unit_en: 'sl.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 87,
              y: 292,
              image_array: ["stand_1.png","stand_2.png","stand_3.png","stand_4.png","stand_5.png","stand_6.png","stand_7.png","stand_8.png","stand_9.png","stand_10.png"],
              image_length: 10,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 236,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 210,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png","cal_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 319,
              font_array: ["A100_306.png","A100_307.png","A100_308.png","A100_309.png","A100_310.png","A100_311.png","A100_312.png","A100_313.png","A100_314.png","A100_315.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 292,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 197,
              src: 'analog.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 174,
              hour_centerY: 291,
              hour_posX: 12,
              hour_posY: 83,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 174,
              minute_centerY: 291,
              minute_posX: 12,
              minute_posY: 83,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 109,
              hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_012.png',
              hour_unit_tc: 'A100_012.png',
              hour_unit_en: 'A100_012.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 303,
              minute_startY: 109,
              minute_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_1 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 109,
              hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_012.png',
              hour_unit_tc: 'A100_012.png',
              hour_unit_en: 'A100_012.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 303,
              minute_startY: 109,
              minute_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 109,
              hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_012.png',
              hour_unit_tc: 'A100_012.png',
              hour_unit_en: 'A100_012.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 303,
              minute_startY: 109,
              minute_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 109,
              hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_012.png',
              hour_unit_tc: 'A100_012.png',
              hour_unit_en: 'A100_012.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 303,
              minute_startY: 109,
              minute_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_digital_clock_img_time_4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 109,
              hour_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'A100_012.png',
              hour_unit_tc: 'A100_012.png',
              hour_unit_en: 'A100_012.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 303,
              minute_startY: 109,
              minute_array: ["A100_002.png","A100_003.png","A100_004.png","A100_005.png","A100_006.png","A100_007.png","A100_008.png","A100_009.png","A100_010.png","A100_011.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_timeZone_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 201,
              y: 419,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 1,
              font: 'fonts/Bebas11_22.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeZoneGMT
            function updateTimeZoneGMT() {
              console.log('updateTimeZoneGMT()');
              let normal_timeZoneStr = '±-:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let date = new Date();
                let timeZoneCurrent = -date.getTimezoneOffset();
                let timeZone = parseInt(worldData.timeZoneHour)*60 + parseInt(worldData.timeZoneMinute);
                let timeZoneCalc = timeZoneCurrent + timeZone;
                let timeZoneHour = Math.trunc(timeZoneCalc / 60);
                let timeZoneHourStr = timeZoneHour.toString();
                let timeZoneMinute = timeZoneCalc % 60;
                let timeZoneMinuteStr = timeZoneMinute.toString().padStart(2, '0');
                if (timeZoneHour > 0) timeZoneHourStr = '+' + timeZoneHourStr;
                else if (timeZoneHour == 0) {
                  if (timeZoneMinute > 0)  timeZoneHourStr = '+' + timeZoneHourStr;
                  else if (timeZoneMinute == 0)  timeZoneHourStr = '±' + timeZoneHourStr;
                  else timeZoneHourStr = '-' + timeZoneHour;
                };
                normal_timeZoneStr = timeZoneHourStr + ':' + timeZoneMinuteStr;
              } // count
              if (normal_timeZone_gmt_text) normal_timeZone_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeZoneStr);
            };
            updateTimeZoneGMT();
            //#endregion
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_time_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 135,
              y: 414,
              w: 150,
              h: 33,
              text_size: 35,
              char_space: 0,
              font: 'fonts/Bebas11_22.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeGMT
            function updateTimeGMT() {
              console.log('updateTimeGMT()');
              let normal_timeStr = '--:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let hour = worldData.hour;
                let minute = worldData.minute;
                if (!timeSensor.is24Hour) hour = hour % 12 || 12;
                let normal_hourStr = hour.toString().padStart(2, '0');
                let normal_minuteStr = minute.toString().padStart(2, '0');
                normal_timeStr = normal_hourStr + ':' + normal_minuteStr;
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_timeStr = 'pm ' + normal_timeStr;
                  else normal_timeStr = 'am ' + normal_timeStr;
                };
              } // count
              if (normal_time_gmt_text) normal_time_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeStr);
            };
            //#endregion

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 240,
              center_y: 407,
              x: 9,
              y: 56,
              start_angle: -138,
              end_angle: 134,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 389,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'point.png',
              center_x: 240,
              center_y: 77,
              x: 9,
              y: 56,
              start_angle: -138,
              end_angle: 133,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 58,
              font_array: ["strs_0.png","strs_1.png","strs_2.png","strs_3.png","strs_4.png","strs_5.png","strs_6.png","strs_7.png","strs_8.png","strs_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodhour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 12,
              hour_posY: 83,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodminute.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 12,
              minute_posY: 83,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 6,
              hour_startY: 209,
              hour_array: ["A100_268.png","A100_269.png","A100_270.png","A100_271.png","A100_272.png","A100_273.png","A100_274.png","A100_275.png","A100_276.png","A100_277.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 340,
              minute_startY: 209,
              minute_array: ["A100_268.png","A100_269.png","A100_270.png","A100_271.png","A100_272.png","A100_273.png","A100_274.png","A100_275.png","A100_276.png","A100_277.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 295,
              w: 75,
              h: 75,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 210,
              w: 75,
              h: 75,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 198,
              w: 85,
              h: 85,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 295,
              w: 75,
              h: 75,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 300,
              w: 85,
              h: 85,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 245,
              w: 100,
              h: 100,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 205,
              w: 120,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 292,
              w: 75,
              h: 75,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 95,
              w: 85,
              h: 85,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 138,
              y: 312,
              w: 71,
              h: 70,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 95,
              text: '',
              w: 85,
              h: 85,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona1.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona1.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 245,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 188,
              w: 75,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                block_on();
              }, // end func
              longpress_func: (button_widget) => {
                block_off();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            normal_outdoorRunning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 77,
              y: 217,
              w: 65,
              h: 65,
              type: hmUI.data_type.OUTDOOR_RUNNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 217,
              w: 58,
              h: 65,
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_outdoorCycling_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 301,
              w: 58,
              h: 65,
              type: hmUI.data_type.OUTDOOR_CYCLING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_freeTraining_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 217,
              w: 65,
              h: 65,
              type: hmUI.data_type.FREE_TRAINING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_poolSwimming_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 301,
              w: 65,
              h: 65,
              type: hmUI.data_type.POOL_SWIMMING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_openWaterSwimming_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 74,
              y: 301,
              w: 65,
              h: 65,
              type: hmUI.data_type.OPEN_WATER_SWIMMING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_trainingLoad_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 292,
              w: 75,
              h: 75,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 210,
              w: 75,
              h: 75,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_recoveryTime_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 210,
              w: 75,
              h: 75,
              type: hmUI.data_type.RECOVERY_TIME,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 210,
              w: 75,
              h: 75,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            GMT_Button_NextSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 245,
              y: 395,
              w: 60,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                toggleWorldClock(1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            GMT_Button_PreviewSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 395,
              w: 60,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                toggleWorldClock(-1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region toggleWorldClock
            function toggleWorldClock(step = 1) {
              const count = worldClock.getWorldClockCount();
              if (count) {
                worldClockIndex += step;
                worldClockIndex = worldClockIndex < 0 ? count + worldClockIndex : worldClockIndex % count;
                updateWorldTime(true);
                hmFS.SysProSetInt('worldClockIndex', worldClockIndex);
              }
            };
            //#endregion

            //#region updateWorldTime
            function updateWorldTime(updateSity = false) {
              updateTimeGMT();
              updateTimeZoneGMT();
            };
            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 315,
              y: 395,
              w: 75,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 95,
              w: 85,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 87,
              y: 395,
              w: 75,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			if (cc ==0 ){
			  
			  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fat_burning_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_stand_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_fatBurning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

              normal_vo2max_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_digital_clock_img_time_1.setProperty(hmUI.prop.VISIBLE, false);
			  normal_vo2max_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_vo2max_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
              normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
              normal_recovery_time_text_img.setProperty(hmUI.prop.VISIBLE, false);
		      normal_recovery_time_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_trainingLoad_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_vo2max_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_recoveryTime_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_digital_clock_img_time_2.setProperty(hmUI.prop.VISIBLE, false);
			  normal_outdoorRunning_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_walking_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_outdoorCycling_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_freeTraining_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_poolSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_openWaterSwimming_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_digital_clock_img_time_3.setProperty(hmUI.prop.VISIBLE, false);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_max_min_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_pressure_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_wind_speed_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  normal_altimeter_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_digital_clock_img_time_4.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Number
              let pressureValue = baroSensor.pressure;
              let normal_pressure_text = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_text_img.setProperty(hmUI.prop.TEXT, normal_pressure_text);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                updateWorldTime(true);
                setTimeout(() => {
                  if (worldClock) {
                    worldClock.uninit();
                    worldClock.init();
                  };
                }, 500);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                worldClock.uninit();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}