﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_wind_speed_text_img = ''
        let normal_wind_speed_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_linear_scale = ''
        let normal_pai_linear_scale_pointer_img = ''
        let normal_pai_day_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_wind_speed_text_img = ''
        let idle_wind_speed_separator_img = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_text_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_pai_linear_scale = ''
        let idle_pai_linear_scale_pointer_img = ''
        let idle_pai_day_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_hrv_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 139,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 179,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 27,
              y: 217,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 22,
              y: 270,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 36,
              day_startY: 306,
              day_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 65,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 433,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_bfh.png',
              unit_tc: 'unit_bfh.png',
              unit_en: 'unit_bfh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 432,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 376,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 374,
              src: 'icon_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 376,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_bfh.png',
              unit_tc: 'unit_bfh.png',
              unit_en: 'unit_bfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 374,
              src: 'icon_humidity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 374,
              image_array: ["weather-00.png","weather-01.png","weather-02.png","weather-03.png","weather-04.png","weather-05.png","weather-06.png","weather-07.png","weather-08.png","weather-09.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 376,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'unit_du.png',
              unit_tc: 'unit_du.png',
              unit_en: 'unit_du.png',
              negative_image: 'huminumfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_pai_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 171,
              // start_y: 186,
              // color: 0xFF2B95FF,
              // pointer: 'vo2max_pointer.png',
              // lenght: -18,
              // line_width: 7,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 158,
              font_array: ["bionum_0.png","bionum_1.png","bionum_2.png","bionum_3.png","bionum_4.png","bionum_5.png","bionum_6.png","bionum_7.png","bionum_8.png","bionum_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 66,
              font_array: ["distnum_0.png","distnum_1.png","distnum_2.png","distnum_3.png","distnum_4.png","distnum_5.png","distnum_6.png","distnum_7.png","distnum_8.png","distnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km_unit.png',
              unit_tc: 'km_unit.png',
              unit_en: 'km_unit.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 102,
              font_array: ["distnum_0.png","distnum_1.png","distnum_2.png","distnum_3.png","distnum_4.png","distnum_5.png","distnum_6.png","distnum_7.png","distnum_8.png","distnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 158,
              font_array: ["bionum_0.png","bionum_1.png","bionum_2.png","bionum_3.png","bionum_4.png","bionum_5.png","bionum_6.png","bionum_7.png","bionum_8.png","bionum_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'bionumnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 158,
              font_array: ["bionum_0.png","bionum_1.png","bionum_2.png","bionum_3.png","bionum_4.png","bionum_5.png","bionum_6.png","bionum_7.png","bionum_8.png","bionum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'bionumnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 262,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 262,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 403,
              second_startY: 306,
              second_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 404,
              month_startY: 268,
              month_sc_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              month_tc_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              month_en_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 403,
              year_startY: 306,
              year_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 139,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 26,
              y: 179,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 27,
              y: 217,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 22,
              y: 270,
              week_en: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_tc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              week_sc: ["aodweek_1.png","aodweek_2.png","aodweek_3.png","aodweek_4.png","aodweek_5.png","aodweek_6.png","aodweek_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 36,
              day_startY: 306,
              day_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 65,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 433,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aodhuminumbfh.png',
              unit_tc: 'aodhuminumbfh.png',
              unit_en: 'aodhuminumbfh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 432,
              src: 'aod_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 376,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_speed_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 194,
              y: 374,
              src: 'aod_wind.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 376,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aodhuminumbfh.png',
              unit_tc: 'aodhuminumbfh.png',
              unit_en: 'aodhuminumbfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 374,
              src: 'aod_humidity.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 86,
              y: 374,
              image_array: ["weather01_00.png","weather01_01.png","weather01_02.png","weather01_03.png","weather01_04.png","weather01_05.png","weather01_06.png","weather01_07.png","weather01_08.png","weather01_09.png","weather01_10.png","weather01_11.png","weather01_12.png","weather01_13.png","weather01_14.png","weather01_15.png","weather01_16.png","weather01_17.png","weather01_18.png","weather01_19.png","weather01_20.png","weather01_21.png","weather01_22.png","weather01_23.png","weather01_24.png","weather01_25.png","weather01_26.png","weather01_27.png","weather01_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 376,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'aodhuminumdu.png',
              unit_tc: 'aodhuminumdu.png',
              unit_en: 'aodhuminumdu.png',
              negative_image: 'aodhuminumfh.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_pai_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_pai_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 171,
              // start_y: 186,
              // color: 0xFF2B95FF,
              // pointer: 'vo2max_pointer.png',
              // lenght: -18,
              // line_width: 7,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 158,
              font_array: ["aodbionum_0.png","aodbionum_1.png","aodbionum_2.png","aodbionum_3.png","aodbionum_4.png","aodbionum_5.png","aodbionum_6.png","aodbionum_7.png","aodbionum_8.png","aodbionum_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 66,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aodhuminumkm.png',
              unit_tc: 'aodhuminumkm.png',
              unit_en: 'aodhuminumkm.png',
              dot_image: 'aodhuminumdot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 102,
              font_array: ["aodhuminum_0.png","aodhuminum_1.png","aodhuminum_2.png","aodhuminum_3.png","aodhuminum_4.png","aodhuminum_5.png","aodhuminum_6.png","aodhuminum_7.png","aodhuminum_8.png","aodhuminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 158,
              font_array: ["aodbionum_0.png","aodbionum_1.png","aodbionum_2.png","aodbionum_3.png","aodbionum_4.png","aodbionum_5.png","aodbionum_6.png","aodbionum_7.png","aodbionum_8.png","aodbionum_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'aodbionumnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 158,
              font_array: ["aodbionum_0.png","aodbionum_1.png","aodbionum_2.png","aodbionum_3.png","aodbionum_4.png","aodbionum_5.png","aodbionum_6.png","aodbionum_7.png","aodbionum_8.png","aodbionum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'aodbionumnull.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 103,
              hour_startY: 262,
              hour_array: ["aodhour_0.png","aodhour_1.png","aodhour_2.png","aodhour_3.png","aodhour_4.png","aodhour_5.png","aodhour_6.png","aodhour_7.png","aodhour_8.png","aodhour_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 251,
              minute_startY: 262,
              minute_array: ["aodmin_0.png","aodmin_1.png","aodmin_2.png","aodmin_3.png","aodmin_4.png","aodmin_5.png","aodmin_6.png","aodmin_7.png","aodmin_8.png","aodmin_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 55,
              w: 100,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 105,
              w: 100,
              h: 45,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 50,
              w: 100,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 160,
              w: 100,
              h: 80,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 423,
              w: 100,
              h: 55,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 360,
              w: 100,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 265,
              w: 105,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 265,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 265,
              w: 100,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 160,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 5,
              y: 264,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 160,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_ls_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_linear_scale
                  // initial parameters
                  let start_x_normal_pai = 171;
                  let start_y_normal_pai = 186;
                  let lenght_ls_normal_pai = -18;
                  let line_width_ls_normal_pai = 7;
                  let color_ls_normal_pai = 0xFF2B95FF;
                  
                  // calculated parameters
                  let start_x_normal_pai_draw = start_x_normal_pai;
                  let start_y_normal_pai_draw = start_y_normal_pai;
                  lenght_ls_normal_pai = lenght_ls_normal_pai * progress_ls_normal_pai;
                  let lenght_ls_normal_pai_draw = line_width_ls_normal_pai;
                  let line_width_ls_normal_pai_draw = lenght_ls_normal_pai;
                  if (lenght_ls_normal_pai < 0){
                    line_width_ls_normal_pai_draw = -lenght_ls_normal_pai;
                    start_y_normal_pai_draw = start_y_normal_pai_draw - line_width_ls_normal_pai_draw;
                  };
                  
                  normal_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw,
                    y: start_y_normal_pai_draw,
                    w: lenght_ls_normal_pai_draw,
                    h: line_width_ls_normal_pai_draw,
                    radius: 3,
                    color: color_ls_normal_pai,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_pai = 7;
                  let pointer_offset_y_ls_normal_pai = 7;
                  normal_pai_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_pai_draw + line_width_ls_normal_pai / 2 - pointer_offset_x_ls_normal_pai,
                    y: start_y_normal_pai + lenght_ls_normal_pai - pointer_offset_y_ls_normal_pai,
                    src: 'vo2max_pointer.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales PAI');
                let progress_ls_idle_pai = progressPAI;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_pai_linear_scale
                  // initial parameters
                  let start_x_idle_pai = 171;
                  let start_y_idle_pai = 186;
                  let lenght_ls_idle_pai = -18;
                  let line_width_ls_idle_pai = 7;
                  let color_ls_idle_pai = 0xFF2B95FF;
                  
                  // calculated parameters
                  let start_x_idle_pai_draw = start_x_idle_pai;
                  let start_y_idle_pai_draw = start_y_idle_pai;
                  lenght_ls_idle_pai = lenght_ls_idle_pai * progress_ls_idle_pai;
                  let lenght_ls_idle_pai_draw = line_width_ls_idle_pai;
                  let line_width_ls_idle_pai_draw = lenght_ls_idle_pai;
                  if (lenght_ls_idle_pai < 0){
                    line_width_ls_idle_pai_draw = -lenght_ls_idle_pai;
                    start_y_idle_pai_draw = start_y_idle_pai_draw - line_width_ls_idle_pai_draw;
                  };
                  
                  idle_pai_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_pai_draw,
                    y: start_y_idle_pai_draw,
                    w: lenght_ls_idle_pai_draw,
                    h: line_width_ls_idle_pai_draw,
                    radius: 3,
                    color: color_ls_idle_pai,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_pai = 7;
                  let pointer_offset_y_ls_idle_pai = 7;
                  idle_pai_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_pai_draw + line_width_ls_idle_pai / 2 - pointer_offset_x_ls_idle_pai,
                    y: start_y_idle_pai + lenght_ls_idle_pai - pointer_offset_y_ls_idle_pai,
                    src: 'vo2max_pointer.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}