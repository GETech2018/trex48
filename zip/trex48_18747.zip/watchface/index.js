﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_group_ForecastWeather = ''
        let normal_forecast_date_week_img = new Array(7);
        let normal_forecast_date_week_img_array = ['day_1.png', 'day_2.png', 'day_3.png', 'day_4.png', 'day_5.png', 'day_6.png', 'day_7.png'];
        let normal_forecast_image_progress_img_level = new Array(7);
        let normal_forecast_image_array = ['weather-00.png', 'weather-01.png', 'weather-02.png', 'weather-03.png', 'weather-04.png', 'weather-05.png', 'weather-06.png', 'weather-07.png', 'weather-08.png', 'weather-09.png', 'weather-10.png', 'weather-11.png', 'weather-12.png', 'weather-13.png', 'weather-14.png', 'weather-15.png', 'weather-16.png', 'weather-17.png', 'weather-18.png', 'weather-19.png', 'weather-20.png', 'weather-21.png', 'weather-22.png', 'weather-23.png', 'weather-24.png', 'weather-25.png', 'weather-26.png', 'weather-27.png', 'weather-28.png'];
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_pressure_text_text_img = ''
        let normal_pressure_text_separator_img = ''
        let normal_wind_speed_text_img = ''
        let normal_wind_speed_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_group_ForecastWeather = ''
        let idle_forecast_date_week_img = new Array(7);
        let idle_forecast_date_week_img_array = ['day_1.png', 'day_2.png', 'day_3.png', 'day_4.png', 'day_5.png', 'day_6.png', 'day_7.png'];
        let idle_forecast_image_progress_img_level = new Array(7);
        let idle_forecast_image_array = ['weather-00.png', 'weather-01.png', 'weather-02.png', 'weather-03.png', 'weather-04.png', 'weather-05.png', 'weather-06.png', 'weather-07.png', 'weather-08.png', 'weather-09.png', 'weather-10.png', 'weather-11.png', 'weather-12.png', 'weather-13.png', 'weather-14.png', 'weather-15.png', 'weather-16.png', 'weather-17.png', 'weather-18.png', 'weather-19.png', 'weather-20.png', 'weather-21.png', 'weather-22.png', 'weather-23.png', 'weather-24.png', 'weather-25.png', 'weather-26.png', 'weather-27.png', 'weather-28.png'];
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_pressure_text_text_img = ''
        let idle_pressure_text_separator_img = ''
        let idle_wind_speed_text_img = ''
        let idle_wind_speed_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_max_min_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_bio_charge_text_text_img = ''
        let idle_bio_charge_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 447,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 4,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();            
            // normal_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 70,
              // y: 165,
              // ColumnWidth: 51,
              // DaysCount: 7,
            // });
            
            normal_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 70,
              y: 165,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_forecast_date_week_img = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -16,
              // image_array: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_date_week_img[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*51,
                  y: -16,
                  src: normal_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_forecast_image_progress_img_level = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: 0,
              // image_array: ["weather-00.png","weather-01.png","weather-02.png","weather-03.png","weather-04.png","weather-05.png","weather-06.png","weather-07.png","weather-08.png","weather-09.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              for (let i = 0; i < 7; i++) {
                normal_forecast_image_progress_img_level[i] = normal_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*51,
                  y: 0,
                  src: normal_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
              };
            };
            //#endregion

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 300,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'aodhuminumdot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 300,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BARO,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_pressure_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 358,
              src: 'baroicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 357,
              src: 'icon_wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 85,
              y: 357,
              image_array: ["weather-00.png","weather-01.png","weather-02.png","weather-03.png","weather-04.png","weather-05.png","weather-06.png","weather-07.png","weather-08.png","weather-09.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 36,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_du.png',
              unit_tc: 'unit_du.png',
              unit_en: 'unit_du.png',
              negative_image: 'huminumfh.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_du.png',
              unit_tc: 'unit_du.png',
              unit_en: 'unit_du.png',
              negative_image: 'huminumfh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 415,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 415,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 20,
              y: 200,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 34,
              day_startY: 244,
              day_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 97,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 95,
              src: 'bioicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 95,
              src: 'bpmicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 200,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 200,
              minute_array: ["min_0.png","min_1.png","min_2.png","min_3.png","min_4.png","min_5.png","min_6.png","min_7.png","min_8.png","min_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 402,
              second_startY: 244,
              second_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 402,
              year_startY: 244,
              year_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 401,
              month_startY: 203,
              month_sc_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              month_tc_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              month_en_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 447,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 4,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // idle_Weather_FewDays = hmUI.createWidget(hmUI.widget.FewDays, {
              // x: 70,
              // y: 165,
              // ColumnWidth: 51,
              // DaysCount: 7,
            // });
            
            idle_group_ForecastWeather = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 70,
              y: 165,
              h: 0,
              w: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_forecast_date_week_img = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: -16,
              // image_array: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              // image_length: 7,
              // type: hmUI.data_type.forecast_date_week_img,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 7; i++) {
                idle_forecast_date_week_img[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*51,
                  y: -16,
                  src: idle_forecast_date_week_img_array[0],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            // idle_forecast_image_progress_img_level = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG_LEVEL_Options, {
              // x: 0,
              // y: 0,
              // image_array: ["weather-00.png","weather-01.png","weather-02.png","weather-03.png","weather-04.png","weather-05.png","weather-06.png","weather-07.png","weather-08.png","weather-09.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              // image_length: 29,
              // type: hmUI.data_type.forecast_image,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            //#region screenType
            if (screenType == hmSetting.screen_type.AOD) {
              for (let i = 0; i < 7; i++) {
                idle_forecast_image_progress_img_level[i] = idle_group_ForecastWeather.createWidget(hmUI.widget.IMG, {
                  x: 0 + i*51,
                  y: 0,
                  src: idle_forecast_image_array[25],
                  show_level: hmUI.show_level.ONLY_AOD,
                });
              };
            };
            //#endregion

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 300,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 3,
              dot_image: 'aodhuminumdot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 300,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pressure_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BARO,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pressure_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 358,
              src: 'baroicon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_speed_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 340,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_speed_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 357,
              src: 'icon_wind.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 85,
              y: 357,
              image_array: ["weather-00.png","weather-01.png","weather-02.png","weather-03.png","weather-04.png","weather-05.png","weather-06.png","weather-07.png","weather-08.png","weather-09.png","weather-10.png","weather-11.png","weather-12.png","weather-13.png","weather-14.png","weather-15.png","weather-16.png","weather-17.png","weather-18.png","weather-19.png","weather-20.png","weather-21.png","weather-22.png","weather-23.png","weather-24.png","weather-25.png","weather-26.png","weather-27.png","weather-28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 36,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_du.png',
              unit_tc: 'unit_du.png',
              unit_en: 'unit_du.png',
              negative_image: 'huminumfh.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 359,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit_du.png',
              unit_tc: 'unit_du.png',
              unit_en: 'unit_du.png',
              negative_image: 'huminumfh.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 415,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 415,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dots.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 20,
              y: 200,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 34,
              day_startY: 244,
              day_sc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_tc_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_en_array: ["datenum_0.png","datenum_1.png","datenum_2.png","datenum_3.png","datenum_4.png","datenum_5.png","datenum_6.png","datenum_7.png","datenum_8.png","datenum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 97,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 95,
              src: 'bioicon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 98,
              font_array: ["huminum_0.png","huminum_1.png","huminum_2.png","huminum_3.png","huminum_4.png","huminum_5.png","huminum_6.png","huminum_7.png","huminum_8.png","huminum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 95,
              src: 'bpmicon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 99,
              hour_startY: 200,
              hour_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 200,
              minute_array: ["hour_0.png","hour_1.png","hour_2.png","hour_3.png","hour_4.png","hour_5.png","hour_6.png","hour_7.png","hour_8.png","hour_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 285,
              w: 100,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 285,
              w: 100,
              h: 55,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 83,
              w: 100,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 83,
              w: 100,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 410,
              w: 100,
              h: 65,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 345,
              w: 100,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 345,
              w: 100,
              h: 60,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 200,
              w: 90,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 200,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 120,
              y: 200,
              w: 90,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 83,
              w: 100,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            //#region weather_few_days
            function weather_few_days() {
              console.log('weather_few_days()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;

              for (let i = 0; i < 7; i++) {
                // DOW images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  normal_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, normal_forecast_date_week_img_array[dowIndex]);
                };
              
                // Images
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  normal_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, normal_forecast_image_array[weatherIndex]);
                };
              
                // DOW images
                if (screenType == hmSetting.screen_type.AOD) {
                  let dowIndex = timeSensor.week - 1;
                  dowIndex += i;
                  while (dowIndex >= 7) {dowIndex -= 7;}
                  idle_forecast_date_week_img[i].setProperty(hmUI.prop.SRC, idle_forecast_date_week_img_array[dowIndex]);
                };
              
                // Images
                if (screenType == hmSetting.screen_type.AOD) {
                  let weatherIndex = 25
                  if (i < forecastData.count) weatherIndex = forecastData.data[i].index;
                  idle_forecast_image_progress_img_level[i].setProperty(hmUI.prop.SRC, idle_forecast_image_array[weatherIndex]);
                };
              
              };  // end for

            };
            //#endregion

            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Number
              let pressureValue = baroSensor.pressure;
              let normal_pressure_text = '-';
              if (pressureValue) normal_pressure_text = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_text_img.setProperty(hmUI.prop.TEXT, normal_pressure_text);
              // Pressure Number
              let idle_pressure_text = '-';
              if (pressureValue) idle_pressure_text = Math.round(pressureValue * 0.75006375541921).toString();
              idle_pressure_text_text_img.setProperty(hmUI.prop.TEXT, idle_pressure_text);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();

                weather_few_days();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}