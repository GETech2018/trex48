try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.WATCHFACE_EDIT_BG, {
                            edit_id: 1,
                            x: 0,
                            y: 0,
                            bg_config: [
                                {
                                    'id': 1,
                                    'path': '4.png',
                                    'preview': '5.png'
                                },
                                {
                                    'id': 2,
                                    'path': '6.png',
                                    'preview': '7.png'
                                },
                                {
                                    'id': 3,
                                    'path': '8.png',
                                    'preview': '9.png'
                                }
                            ],
                            count: 3,
                            default_id: 1,
                            fg: '3.png',
                            tips_x: 0,
                            tips_y: 0,
                            tips_bg: '2.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL | hmUI__default.default.show_level.ONLY_EDIT
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_WEEK, {
                            x: 145,
                            y: 92,
                            week_en: [
                                '10.png',
                                '11.png',
                                '12.png',
                                '13.png',
                                '14.png',
                                '15.png',
                                '16.png'
                            ],
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 198,
                            y: 41,
                            type: hmUI__default.default.data_type.BATTERY,
                            font_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            align_h: hmUI__default.default.align.RIGHT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '27.png',
                            unit_tc: '27.png',
                            unit_en: '27.png',
                            padding: true,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 256,
                            y: 42,
                            src: '28.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 131,
                            hour_startY: 128,
                            hour_array: [
                                '29.png',
                                '30.png',
                                '31.png',
                                '32.png',
                                '33.png',
                                '34.png',
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png'
                            ],
                            hour_space: -2,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 250,
                            minute_startY: 129,
                            minute_array: [
                                '39.png',
                                '40.png',
                                '41.png',
                                '42.png',
                                '43.png',
                                '44.png',
                                '45.png',
                                '46.png',
                                '47.png',
                                '48.png'
                            ],
                            minute_space: 0,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            second_zero: 1,
                            second_startX: 353,
                            second_startY: 177,
                            second_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            second_space: 0,
                            second_align: hmUI__default.default.align.LEFT,
                            second_follow: 0,
                            am_x: 85,
                            am_y: 176,
                            am_en_path: '49.png',
                            pm_x: 0,
                            pm_y: 0,
                            pm_en_path: '50.png',
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_DATE, {
                            month_startX: 302,
                            month_startY: 95,
                            month_sc_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            month_tc_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            month_en_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            month_align: hmUI__default.default.align.LEFT,
                            month_zero: 1,
                            month_follow: 0,
                            month_space: 0,
                            month_is_character: false,
                            day_startX: 252,
                            day_startY: 94,
                            day_sc_array: [
                                '51.png',
                                '52.png',
                                '53.png',
                                '54.png',
                                '55.png',
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png'
                            ],
                            day_tc_array: [
                                '51.png',
                                '52.png',
                                '53.png',
                                '54.png',
                                '55.png',
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png'
                            ],
                            day_en_array: [
                                '51.png',
                                '52.png',
                                '53.png',
                                '54.png',
                                '55.png',
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png'
                            ],
                            day_align: hmUI__default.default.align.CENTER_H,
                            day_zero: 1,
                            day_follow: 0,
                            day_space: 0,
                            day_is_character: false,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 286,
                            y: 96,
                            src: '61.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 177,
                            y: 341,
                            type: hmUI__default.default.data_type.HEART,
                            font_array: [
                                '62.png',
                                '63.png',
                                '64.png',
                                '65.png',
                                '66.png',
                                '67.png',
                                '68.png',
                                '69.png',
                                '70.png',
                                '71.png'
                            ],
                            align_h: hmUI__default.default.align.RIGHT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '72.png',
                            padding: true,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 215,
                            y: 131,
                            src: '73.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 246,
                            y: 341,
                            type: hmUI__default.default.data_type.BIO_CHARGE,
                            font_array: [
                                '74.png',
                                '75.png',
                                '76.png',
                                '77.png',
                                '78.png',
                                '79.png',
                                '80.png',
                                '81.png',
                                '82.png',
                                '83.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '84.png',
                            padding: true,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 136,
                            y: 368,
                            type: hmUI__default.default.data_type.STEP,
                            font_array: [
                                '85.png',
                                '86.png',
                                '87.png',
                                '88.png',
                                '89.png',
                                '90.png',
                                '91.png',
                                '92.png',
                                '93.png',
                                '94.png'
                            ],
                            align_h: hmUI__default.default.align.CENTER_H,
                            h_space: -2,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TIME_POINTER, {
                            hour_centerX: 240,
                            hour_centerY: 240,
                            hour_posX: 26,
                            hour_posY: 240,
                            hour_path: '95.png',
                            hour_cover_x: 0,
                            hour_cover_y: 0,
                            minute_centerX: 240,
                            minute_centerY: 240,
                            minute_posX: 32,
                            minute_posY: 240,
                            minute_path: '96.png',
                            minute_cover_x: 0,
                            minute_cover_y: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 71,
                            y: 236,
                            image_array: [
                                '97.png',
                                '98.png',
                                '99.png',
                                '100.png',
                                '101.png',
                                '102.png',
                                '103.png',
                                '104.png',
                                '105.png',
                                '106.png',
                                '107.png',
                                '108.png',
                                '109.png',
                                '110.png',
                                '111.png',
                                '112.png',
                                '113.png',
                                '114.png',
                                '115.png',
                                '116.png',
                                '117.png',
                                '118.png',
                                '119.png',
                                '120.png',
                                '121.png',
                                '122.png',
                                '123.png',
                                '124.png',
                                '125.png'
                            ],
                            image_length: 29,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 108,
                            y: 239,
                            type: hmUI__default.default.data_type.WEATHER_CURRENT,
                            font_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '128.png',
                            unit_tc: '128.png',
                            unit_en: '128.png',
                            negative_image: '127.png',
                            invalid_image: '126.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 330,
                            y: 239,
                            type: hmUI__default.default.data_type.STRESS,
                            font_array: [
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png'
                            ],
                            align_h: hmUI__default.default.align.RIGHT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '130.png',
                            unit_tc: '130.png',
                            unit_en: '130.png',
                            invalid_image: '129.png',
                            padding: false,
                            isCharacter: false
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}