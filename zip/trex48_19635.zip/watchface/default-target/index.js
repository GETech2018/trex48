try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            src: '2.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 142,
                            hour_startY: 304,
                            hour_array: [
                                '3.png',
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png'
                            ],
                            hour_space: 1,
                            hour_unit_sc: '13.png',
                            hour_unit_tc: '13.png',
                            hour_unit_en: '13.png',
                            hour_align: hmUI__default.default.align.RIGHT,
                            minute_zero: 1,
                            minute_startX: 248,
                            minute_startY: 304,
                            minute_array: [
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png',
                                '23.png'
                            ],
                            minute_space: 1,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 120,
                            y: 237,
                            type: hmUI__default.default.data_type.STEP,
                            font_array: [
                                '24.png',
                                '25.png',
                                '26.png',
                                '27.png',
                                '28.png',
                                '29.png',
                                '30.png',
                                '31.png',
                                '32.png',
                                '33.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 135,
                            y: 185,
                            src: '34.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_POINTER, {
                            src: '36.png',
                            center_x: 329,
                            center_y: 224,
                            x: 9,
                            y: 41,
                            type: hmUI__default.default.data_type.BIO_CHARGE,
                            start_angle: 0,
                            end_angle: 360,
                            cover_path: '35.png',
                            cover_x: 317,
                            cover_y: 212,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_POINTER, {
                            src: '38.png',
                            center_x: 151,
                            center_y: 224,
                            x: 9,
                            y: 41,
                            type: hmUI__default.default.data_type.STAND,
                            start_angle: 0,
                            end_angle: 360,
                            cover_path: '37.png',
                            cover_x: 139,
                            cover_y: 212,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 309,
                            y: 240,
                            type: hmUI__default.default.data_type.HEART,
                            font_array: [
                                '39.png',
                                '40.png',
                                '41.png',
                                '42.png',
                                '43.png',
                                '44.png',
                                '45.png',
                                '46.png',
                                '47.png',
                                '48.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 1,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            invalid_image: '49.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 312,
                            y: 186,
                            src: '50.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_DATE, {
                            month_startX: 177,
                            month_startY: 126,
                            month_en_array: [
                                '51.png',
                                '52.png',
                                '53.png',
                                '54.png',
                                '55.png',
                                '56.png',
                                '57.png',
                                '58.png',
                                '59.png',
                                '60.png',
                                '61.png',
                                '62.png'
                            ],
                            month_align: hmUI__default.default.align.LEFT,
                            month_zero: 0,
                            month_follow: 0,
                            month_space: 0,
                            month_is_character: true,
                            day_startX: 226,
                            day_startY: 126,
                            day_sc_array: [
                                '63.png',
                                '64.png',
                                '65.png',
                                '66.png',
                                '67.png',
                                '68.png',
                                '69.png',
                                '70.png',
                                '71.png',
                                '72.png'
                            ],
                            day_tc_array: [
                                '63.png',
                                '64.png',
                                '65.png',
                                '66.png',
                                '67.png',
                                '68.png',
                                '69.png',
                                '70.png',
                                '71.png',
                                '72.png'
                            ],
                            day_en_array: [
                                '63.png',
                                '64.png',
                                '65.png',
                                '66.png',
                                '67.png',
                                '68.png',
                                '69.png',
                                '70.png',
                                '71.png',
                                '72.png'
                            ],
                            day_align: hmUI__default.default.align.LEFT,
                            day_zero: 1,
                            day_follow: 0,
                            day_space: 0,
                            day_is_character: false,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_WEEK, {
                            x: 258,
                            y: 126,
                            week_en: [
                                '73.png',
                                '74.png',
                                '75.png',
                                '76.png',
                                '77.png',
                                '78.png',
                                '79.png'
                            ],
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_LEVEL, {
                            x: 209,
                            y: 365,
                            image_array: [
                                '80.png',
                                '81.png',
                                '82.png',
                                '83.png',
                                '84.png',
                                '85.png',
                                '86.png',
                                '87.png',
                                '88.png',
                                '89.png'
                            ],
                            image_length: 10,
                            type: hmUI__default.default.data_type.BATTERY,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TEXT_IMG, {
                            x: 243,
                            y: 365,
                            type: hmUI__default.default.data_type.BATTERY,
                            font_array: [
                                '90.png',
                                '91.png',
                                '92.png',
                                '93.png',
                                '94.png',
                                '95.png',
                                '96.png',
                                '97.png',
                                '98.png',
                                '99.png'
                            ],
                            align_h: hmUI__default.default.align.LEFT,
                            h_space: 0,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL,
                            unit_sc: '100.png',
                            unit_tc: '100.png',
                            unit_en: '100.png',
                            padding: false,
                            isCharacter: false
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TIME_POINTER, {
                            hour_centerX: 240,
                            hour_centerY: 239,
                            hour_posX: 24,
                            hour_posY: 137,
                            hour_path: '101.png',
                            hour_cover_x: 0,
                            hour_cover_y: 0,
                            minute_centerX: 240,
                            minute_centerY: 239,
                            minute_posX: 21,
                            minute_posY: 183,
                            minute_path: '102.png',
                            minute_cover_x: 0,
                            minute_cover_y: 0,
                            second_centerX: 240,
                            second_centerY: 239,
                            second_posX: 17,
                            second_posY: 173,
                            second_path: '103.png',
                            second_cover_x: 0,
                            second_cover_y: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}