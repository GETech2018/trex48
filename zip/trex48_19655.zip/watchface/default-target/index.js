try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const utils = __$$RQR$$__('@zos/utils');
                const hmUI = __$$RQR$$__('@zos/ui');
                const _interopDefaultCompat = e => e && typeof e === 'object' && 'default' in e ? e : { default: e };
                const hmUI__default = _interopDefaultCompat(hmUI);
                const logger = utils.log.getLogger('watchface');
                __$$module$$__.module = WatchFace({
                    initView() {
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            src: '2.png',
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 18,
                            hour_startY: 160,
                            hour_array: [
                                '3.png',
                                '4.png',
                                '5.png',
                                '6.png',
                                '7.png',
                                '8.png',
                                '9.png',
                                '10.png',
                                '11.png',
                                '12.png'
                            ],
                            hour_space: 0,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 199,
                            minute_startY: 160,
                            minute_array: [
                                '13.png',
                                '14.png',
                                '15.png',
                                '16.png',
                                '17.png',
                                '18.png',
                                '19.png',
                                '20.png',
                                '21.png',
                                '22.png'
                            ],
                            minute_space: 0,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            second_zero: 1,
                            second_startX: 400,
                            second_startY: 212,
                            second_array: [
                                '23.png',
                                '24.png',
                                '25.png',
                                '26.png',
                                '27.png',
                                '28.png',
                                '29.png',
                                '30.png',
                                '31.png',
                                '32.png'
                            ],
                            second_space: 0,
                            second_align: hmUI__default.default.align.LEFT,
                            second_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.TIME_POINTER, {
                            second_centerX: 424,
                            second_centerY: 229,
                            second_posX: 44,
                            second_posY: 44,
                            second_path: '33.png',
                            second_cover_x: 0,
                            second_cover_y: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_NORMAL
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG, {
                            x: 0,
                            y: 0,
                            w: 480,
                            h: 480,
                            src: '34.png',
                            show_level: hmUI__default.default.show_level.ONLY_AOD
                        });
                        hmUI__default.default.createWidget(hmUI__default.default.widget.IMG_TIME, {
                            hour_zero: 1,
                            hour_startX: 53,
                            hour_startY: 160,
                            hour_array: [
                                '35.png',
                                '36.png',
                                '37.png',
                                '38.png',
                                '39.png',
                                '40.png',
                                '41.png',
                                '42.png',
                                '43.png',
                                '44.png'
                            ],
                            hour_space: 0,
                            hour_align: hmUI__default.default.align.LEFT,
                            minute_zero: 1,
                            minute_startX: 248,
                            minute_startY: 160,
                            minute_array: [
                                '45.png',
                                '46.png',
                                '47.png',
                                '48.png',
                                '49.png',
                                '50.png',
                                '51.png',
                                '52.png',
                                '53.png',
                                '54.png'
                            ],
                            minute_space: 0,
                            minute_align: hmUI__default.default.align.LEFT,
                            minute_follow: 0,
                            enable: false,
                            show_level: hmUI__default.default.show_level.ONLY_AOD
                        });
                    },
                    onInit() {
                        logger.log('index page.js on init invoke');
                    },
                    build() {
                        logger.log('index page.js on build invoke');
                        this.initView();
                    },
                    onDestroy() {
                        logger.log('index page.js on destroy invoke');
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}