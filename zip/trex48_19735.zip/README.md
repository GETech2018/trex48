# Aviation Radar 480

AppId 1133079, author Djalma Ribeiro, version 1.0.0 (code 1).
Independent 480x480 adaptation of Radar GTR 4; the original 466px project is unchanged.

Four editable backgrounds (colorful default), moving decorative aircraft, orange/yellow
hands, framed battery/date panels and firmware-managed digital AOD are preserved.
Logical geometry remains 466px; createWidget scales positional fields to 480px.
Traffic coordinates are scaled once at the render boundary. Angles, alpha, timing,
API enums and IDs are never scaled. Asset preparation uses the same rounding.
The watchface selection thumbnail is 324x324; store preview is 360x360.

## Supported device declarations

Balance, Balance 2, Balance 3, Balance Ultra, Active Max, T-Rex 3,
T-Rex 3 Pro 48mm, T-Rex Ultra 2 and Cheetah Pro (24 regional IDs).
Exact official identifiers and source are in tools/devices-480.json.
GTR 3 Pro is excluded because it runs Zepp OS 1.0 and this code requires API 2.1.
Cheetah 2 Ultra is pending: its official IDs are not accepted by Zeus 1.9.3,
including after a successful zeus cache update. Do not invent another device ID.

## Commands

1. python tools/prepare_assets.py
2. node tools/test.cjs
3. python tools/verify_assets.py
4. zeus build -t 480x480-round
5. zeus prune --ip

The approved original PNGs are preserved under art/base466-assets for reproducible
scaling. They are not distributed in the installed package.
Tests cover geometry, moving targets, fading, native AOD, editing and lifecycle
using mocked APIs; they are not firmware emulation or physical device validation.
The AOD conservative maximum lit pixel area is checked below 10%.
No physical-device or simulator-window validation was performed for this adaptation.
