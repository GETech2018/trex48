# Variantes de fundo — geração integrada image_gen

Arquivos finais de arte: `radar-map-blue-master.png` e `radar-map-weather-master.png`.
Os PNGs de aplicação em 466x466 ficam em `assets/466x466-amazfit-gtr-4/radar/themes/`.
As imagens de referência foram usadas como orientação visual; texto, logotipos,
dispositivos e dados apresentados nelas não fazem parte das novas artes.

## Azul — edição de radar-map-master.png

Edit the provided production map texture for a 466x466 aviation radar watchface. Preserve the EXACT coastline, islands, estuary, roads, city blocks and topographic contours and their positions. Recolor the entire monochrome green map into a dark BLUE and CYAN aviation chart: near-black navy waterways, deep midnight blue land, restrained luminous azure/cyan fine coastlines, roads and contour lines. Blue must be clearly visible and rich, not gray or green. Keep the same overall restrained darkness/contrast to allow bright orange aircraft clock hands to be overlaid later. This is an edge-to-edge SQUARE FLAT MAP TEXTURE ONLY, no circular boundary, no bezel, no dial, no radar rings, no compass, no numbers, no letters, no labels, no airplanes, no aircraft hands, no sweep, no buttons, no photos or mockup. Preserve all map geometry; change palette only. The exact geometric markings will be added by software.

## Colorido — mapa original + fotografia como referência de estilo

Image 1 is the map texture to edit. Image 2 is STYLE REFERENCE ONLY for a colorful weather radar palette; do NOT reproduce the device or text. Create a production background texture for an aviation radar watchface by preserving Image 1's coastline, estuary, islands, streets and map composition, changing it into a colorful dark weather radar chart. Base map: dark desaturated teal/slate/blue land, almost-black navy waterways, thin muted cyan coastlines/roads. Add irregular clustered precipitation-like decorative color patches mostly along the upper left, upper edge, upper right and lower-left perimeter, with blue and cyan bands, some green/yellow inner bands and a few small orange/red cores, like the weather radar style in Image 2. These should look organic and granular like radar returns, not smooth colored clouds. Keep the central region calm, mostly dark and free of intense yellow/red, so orange/yellow clock hands remain readable. Good contrast without overwhelming 466x466 display. Square flat edge-to-edge map texture; no circular crop, no bezel, no device, no clock face, no rings, no sweep, no symbols, no aircraft, no numbers, no text, no labels, no logos or attribution copied from the reference. This is decorative artwork, not live weather. The green radial lines and hour numerals will be added by software separately.
