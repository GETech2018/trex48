"""Scale the approved 466px design resources to the 480px native geometry."""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'art/base466-assets'
OUT = ROOT / 'assets/480x480-round'

def scale(value):
    return int(value * 480 / 466 + 0.5)

for source in SOURCE.rglob('*.png'):
    relative = source.relative_to(SOURCE)
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as image:
        size = (324, 324) if relative.as_posix() == 'icon.png' else tuple(scale(v) for v in image.size)
        image = image.resize(size, Image.Resampling.LANCZOS)
        if source.name.startswith('aod-'):
            if image.mode == 'RGBA':
                image.putalpha(image.getchannel('A').point(lambda v: v if v >= 48 else 0))
            else:
                image = image.convert('RGB')
                image.putdata([p if max(p) >= 48 else (0, 0, 0) for p in image.getdata()])
        image.save(target, optimize=True)
print('Prepared 480px backgrounds, pointers, panels, aircraft, AOD; thumbnail 324px.')
