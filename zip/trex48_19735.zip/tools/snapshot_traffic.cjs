// Render the real traffic model to JSON for thumbnails/previews, without a Zepp runtime.
const fs=require('node:fs'), path=require('node:path'), vm=require('node:vm')
if(!vm.SourceTextModule) {
  const result=require('node:child_process').spawnSync(process.execPath,['--experimental-vm-modules',__filename,...process.argv.slice(2)],{stdio:'inherit'})
  process.exit(result.status===null?1:result.status)
}
async function main(){
  const source=fs.readFileSync(path.join(__dirname,'../watchface/traffic.js'),'utf8')
  const module=new vm.SourceTextModule(source)
  await module.link(()=>{throw Error('Traffic module must have no dependencies')})
  await module.evaluate()
  const {createTraffic,advanceTraffic}=module.namespace
  const states=Array.from({length:4},(_,i)=>createTraffic(i))
  const end=Number(process.argv[2] || 36540916)
  for(let time=end-12000;time<=end;time+=50){
    const hour=Math.floor(time/3600000)%24
    for(const state of states) advanceTraffic(state,time,(time%6000)*360/6000,hour)
  }
  process.stdout.write(JSON.stringify(states))
}
main().catch(error=>{console.error(error);process.exitCode=1})
