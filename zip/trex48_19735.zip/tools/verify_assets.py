"""Verify native asset dimensions and the conservative maximum AOD lit area."""
from pathlib import Path
from PIL import Image
def scale(value):
    return int(value * 480 / 466 + 0.5)

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'assets/480x480-round'
for source in (ROOT / 'art/base466-assets').rglob('*.png'):
    relative = source.relative_to(ROOT / 'art/base466-assets')
    with Image.open(source) as original, Image.open(BASE / relative) as image:
        expected = (324,324) if relative.as_posix() == 'icon.png' else tuple(scale(v) for v in original.size)
        assert image.size == expected, (relative,image.size,expected)

def count(name):
    with Image.open(BASE / 'radar' / name) as image:
        return sum(1 for r,g,b,a in image.convert('RGBA').getdata() if a and max(r,g,b))

large = [count(f'aod-time-{i}.png') for i in range(10)]
small = [count(f'aod-digit-{i}.png') for i in range(10)]
time_max = max(sum(large[int(c)] for c in f'{h:02}{m:02}') for h in range(24) for m in range(60))
date_max = max(sum(small[int(c)] for c in f'{d:02}') for d in range(1,32))
bound = (count('aod-digital-panel.png') + time_max + date_max) / 480**2
assert bound < .1, bound
print(f'PASS: dimensions of all PNG assets; conservative AOD lit-area bound {bound:.2%}.')
