import hmUI from '@zos/ui'

// Temporary transport/runtime diagnostic; the full radar remains in index.js.
WatchFace({
  onInit() { console.log('[radar-test v3] onInit; ui=' + typeof hmUI) },
  build() {
    console.log('[radar-test v3] build; createWidget=' + (hmUI ? typeof hmUI.createWidget : 'missing'))
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 0, y: 0, w: 466, h: 466, color: 0x003300,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    })
    hmUI.createWidget(hmUI.widget.TEXT, {
      x: 50, y: 190, w: 366, h: 70, color: 0xffffff,
      text: 'RADAR OK', text_size: 40, align_h: hmUI.align.CENTER_H,
      align_v: hmUI.align.CENTER_V,
      show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD
    })
    console.log('[radar-test] build complete')
  },
  onDestroy() { console.log('[radar-test] destroyed') }
})
