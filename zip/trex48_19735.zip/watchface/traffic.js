// Pure decorative traffic simulation; no GPS or live aircraft data.
export const FLIGHT_MS = 72000
export const RETURN_MS = 5000
const C = 233
const TYPES = ['airliner', 'prop', 'cargo', 'fighter', 'helicopter', 'glider']
const SIZES = ['small', 'medium', 'large']
const mod = (value, divisor) => ((value % divisor) + divisor) % divisor

export function trafficFrame(now, index) {
  const clock = now + index * FLIGHT_MS / 4
  const cycle = Math.floor(clock / FLIGHT_MS)
  const progress = mod(clock, FLIGHT_MS) / FLIGHT_MS
  const heading = mod(90 + index * 90 + mod(cycle, 4) * 45, 360)
  const a = heading * Math.PI / 180
  const dx = Math.sin(a), dy = -Math.cos(a)
  const offset = [-82, 98, -116, 64][mod(index + cycle, 4)]
  const half = Math.sqrt(260 * 260 - offset * offset)
  const along = (2 * progress - 1) * half
  const x = C + dx * along - dy * offset
  const y = C + dy * along + dx * offset
  return { cycle, progress, heading, x, y, radius: Math.hypot(x - C, y - C),
    bearing: mod(Math.atan2(x - C, C - y) * 180 / Math.PI, 360) }
}

export function trafficAppearance(cycle, index, hour) {
  const period = Math.floor(hour / 3)
  const type = TYPES[mod(cycle + period + index * 2, TYPES.length)]
  const size = SIZES[mod(Math.floor(cycle / 2) + period + index, SIZES.length)]
  return { type, size, src: 'radar/traffic-' + type + '-' + size + '.png' }
}

export function createTraffic(index) {
  return { index, cycle: null, previousPhase: null, lastSeen: null,
    alpha: 0, x: 0, y: 0, angle: 0, src: '' }
}

export function advanceTraffic(state, now, sweep, hour) {
  const frame = trafficFrame(now, state.index)
  if (frame.cycle !== state.cycle) {
    // Routes begin beyond the rim: appearance changes happen off the display.
    const appearance = trafficAppearance(frame.cycle, state.index, hour)
    state.cycle = frame.cycle
    state.src = appearance.src
    state.type = appearance.type
    state.size = appearance.size
    state.previousPhase = null
    state.lastSeen = null
  }
  const phase = mod(sweep - frame.bearing, 360)
  const inside = frame.radius < 218
  const crossed = state.previousPhase === null ? phase <= 3.1
    : state.previousPhase - phase > 180
  if (inside && crossed) state.lastSeen = now
  state.previousPhase = inside ? phase : null
  if (!inside) state.lastSeen = null
  const remaining = state.lastSeen === null ? 0 : Math.max(0, 1 - (now - state.lastSeen) / RETURN_MS)
  const edge = Math.max(0, Math.min(1, (218 - frame.radius) / 12))
  state.alpha = Math.round(255 * remaining * remaining * (3 - 2 * remaining) * edge)
  state.x = Math.round(frame.x - 24)
  state.y = Math.round(frame.y - 24)
  state.angle = frame.heading
  return state
}
