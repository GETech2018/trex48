# TrailPulse watch face (Zepp OS, every round and square watch)

Our own Zepp OS watch face (API 1.0), black, white and orange, in 24 languages, for the Zepp store.
Designed on the Amazfit T-Rex 3 Pro (480 x 480) and scaled to every other Zepp OS screen.

Main screen:

- alarm icon and the next alarm time (only when an alarm is set)
- date `13 TUESDAY / OCT`, current weather icon and temperature with today's ▲max / ▼min next to it
- big time with gray seconds next to it, and **the flag the user picked** under the seconds (none by default)
- row of four fields: ♥ heart rate, STRESS, TEMP (air), HybridCharge
- today's heart rate graph with numbers on the axes (50/100/150 bpm, 0-24 h), an orange dot where you are now,
  `MIN` top left and `MAX` top right (today's lowest and highest reading; the line is averaged over 7.5 minutes,
  so it can look flatter; after a restart of the watch the curve starts at the restart time); can be switched
  to sleep
- steps, `DISTANCE x KM`, step goal bar, `BATTERY x%`
- values turn orange (labels stay gray): battery under 20%, STRESS over 60, HybridCharge under 30 (only if the
  firmware lets the code read HybridCharge; it has no documented sensor)

Always-on: analog hands (outline with orange inserts and a black border, so they pass cleanly over the text),
12 hour marks, weather, temperature with today's max/min, date, and at the bottom today's distance, centred and
as big as the temperature, with a small spaced-out `DISTANCE` above it. No seconds hand and no flag.
Everything is drawn at 70% brightness, about 5% of the screen is lit (Zepp's limit is 10%).

Every field opens its app on tap (heart rate, stress, weather, HybridCharge, steps, battery, alarm and so on);
the big time opens the timer.

`pregled/glavni.png`, `pregled/aod.png` and `pregled/uredjivanje.png` are drawn from a simulated run of
this code; `pregled/jezici.png` shows every language and `pregled/ekrani.png` every screen size.

## Languages

Every language of the watch's list that uses the Latin, Cyrillic or Greek alphabet (24): English, Serbian
(Latin), Spanish, Italian, German, French, Portuguese, Polish, Czech, Turkish, Hungarian, Swedish, Romanian,
Dutch, Catalan, Indonesian, Norwegian, Malay, Danish, Finnish, Vietnamese, Russian, Ukrainian and Greek.
Chinese, Japanese, Korean, Thai, Arabic and Hebrew show English. The face follows the watch's language
(`hmSetting.getLanguage()`); it reads it when the face loads, so after changing the language switch to another
face and back. English uses a decimal point (3.05 KM), the others a comma.

All words are in `tools/strings.py`. Saira has no Cyrillic or Greek, so Russian, Ukrainian and Greek words
are drawn in Fira Sans Condensed with the same capital height. Long weekdays (DONNERSTAG, ВОСКРЕСЕНЬЕ) are drawn
a little smaller so they end before the weather icon. A word or label that is the same in several languages is
drawn once. The words of edit mode (titles of the choices and the 251 country names) are in
`assets/*/lang/<lang>.bin`, and the face reads only the watch's language from there (`hmFS.open_asset`);
English is also in `layout.js` in case that read fails.

## Screens

One design at 480 x 480. When the store package is built, Zepp's build tool shrinks every image to the width of
each screen (`Math.floor(width * screen / 480)`), and `watchface/index.js` scales every coordinate the same way
(`hmSetting.getDeviceInfo()`). Round screens (480, 466, 454, 416, 360) get the whole design; square screens
(390 x 450, 336 x 384, 320 x 380, Bip Max 432 x 514) get the same round design as wide as the screen, centred
vertically. `app.json` targets `st: r` and `st: s`, `assets/common.s` is a copy of `assets/common.r`.
`_pikeCompatibled` makes the Bip Max report its real 432 px width, which the build scales the images to.

## Flags

More than 250 flags (every country and territory in flag-icons, plus EU, UN, England, Scotland, Wales,
Northern Ireland, Catalonia, Galicia, Basque Country), 4:3, with rounded corners. Places that share a flag
appear once (Heard Island is Australia). In edit mode the list is alphabetical in the watch's language, with the
names from Unicode CLDR, and starts with "No flag", the default. A flag's edit id comes from its code
(`110000 + letters`), so the choice survives updates that add flags. The flag is centred under the seconds and
moves with them.

## Install on the watch (free)

Zeus CLI and Zepp developer mode.

1. In this folder: `zeus preview`, pick the watch, scan the QR code in the Zepp app
   (Profile → Developer mode → Scan).
2. On the watch: long press the current face and pick **TrailPulse**.

## Store

1. `sh tools/build.sh` (refreshes images, previews, the 324 x 324 cover at 10:09 and the store pictures).
2. `zeus build` makes the ZAB with a package for every screen (14 packages, 3 to 4.5 MB each, 60 MB in all;
   zeus downloads the device list from upload-cdn.zepp.com). If the console refuses a ZAB that big,
   `zeus prune --ip` drops the intermediate files from it.
3. Zepp Console → Watchface: upload the ZAB (appId 25757 must be the one registered there), then for each
   language the name, the details and the pictures from `store/` (`store/listing.md` has the text in seven
   languages; it says first where to pick the flag, since none is shown until the user picks one).

## Changing fields

Long press the face → edit (pencil). The seven small fields, the graph and the flag can be changed:

| Field | Default | Note |
| --- | --- | --- |
| row, 1st | Heart rate | narrow, offers only heart rate and UV |
| row, 2nd | Stress | |
| row, 3rd | Temperature (air) | |
| row, 4th | HybridCharge | |
| bottom left | Steps | |
| bottom right | Distance | |
| bottom | Battery | |
| graph | Heart rate | or Sleep (drawn by the watch) |
| under the seconds | No flag | any of the flags |

Also offered where they fit: Calories, Blood oxygen, PAI, Readiness, Recovery, Floors, Humidity, UV, Stand,
VO2max, Training load, Sunset, Today's max/min, Running this month (km).

A field offers an option in the languages where its largest realistic value (e.g. 24680 steps, 18.88 km,
100%) still fits with at least the short label, and shows the long label where that fits too (DIST, BAT...).
The defaults fit in every language. If an option is not offered in the language the watch is switched to, the
field shows its default.

HybridCharge: the watch calls it `BIO_CHARGE` internally; if the firmware has a newer `HYBRID_CHARGE`
type, that one is used.

## Files

- `watchface/index.js`: the face. `watchface/layout.js` is generated, do not edit.
- `assets/common.r/`, `assets/common.s/`: all images (digits, labels in every language, icons, hands, flags),
  generated.
- `tools/gen_assets.py`: draws every image and writes `layout.js` (needs Python 3 with Pillow and the
  fonts in `fonts-src/`). `GRAPH=watch` lets the watch draw the heart rate graph instead (hours only on the
  axis), `AOD_TEMP=bottom` moves the always-on temperature under the distance, `AOD_HALO=0` drops the hand
  border, `HILO=0` drops the max/min temperature, `HRMIN=right|off` moves the graph MIN next to MAX or drops it,
  `SECONDS=js` draws the seconds with our own 1-second timer (natural digit spacing, but it wakes the watch
  every second; default `watch` lets the watch draw them), `AOD_DIM=1 AOD_TICKS=60` brings back the
  full-brightness always-on with all 60 ticks, `AOD_LAYOUT=dodge|rim` are the two always-on layouts we did not
  pick (info jumps away from the hands, or sits at the rim with short hands).
- `tools/strings.py`: every word in the 24 languages.
- `tools/flags.mjs`: renders `art-src/flags/` (flag pictures and their names in every language) from
  flag-icons; only needed when the flag set changes.
- `tools/sim.js` + `tools/render.py`: run the face against a fake watch API and draw what it shows
  (`lang=de`, `flag=rs`, `width=416`, `square=1 width=390 height=450`, ...). `tools/sheet.py` puts renders side by
  side.
- `tools/build.sh`: regenerates images, runs the simulation in every language and on every screen, refreshes
  `pregled/`, `store/`, `cover.png` and `icon.png`; fails when a value does not fit its box.
- `store/`: store pictures and `listing.md` (store text in seven languages).

Fonts: Saira Semi Condensed and Fira Sans Condensed (both SIL Open Font License, from github.com/google/fonts).
Flags: flag-icons by
Panayiotis Lipiridis, MIT License (`art-src/flags/LICENSE-flag-icons`).
