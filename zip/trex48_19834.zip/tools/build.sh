#!/bin/sh
# Regenerates assets + layout, runs the face in the simulator and renders:
#   pregled/glavni.png, aod.png, uredjivanje.png  main screen, always-on, edit mode with the flag picker
#   pregled/jezici.png                             main screen in all 24 languages, widest values
#   pregled/ekrani.png                             main screen and always-on on every screen size
#   store/                                         pictures for the store listing
# and the cover (assets/common.*/cover.png, 324 x 324) from the main screen at 10:09 with the default data
# of the Zepp watch face specification. Fails when a value does not fit its box.
# Needs python3 with Pillow and node. Run from anywhere.
set -e
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
log="$tmp/render.log"
python3 -I tools/gen_assets.py

sim() { node tools/sim.js "$@" 2>/dev/null; }
render() { python3 -I tools/render.py "$@" | tee -a "$log"; }

# Zepp preview data: 10:09:36, 86 bpm, 8670 steps, 5.30 km, battery 75%, 22 degrees
SPEC="hour=10 minute=9 second=36 HEART=86 STEP=8670 DISTANCE=5.3 BATTERY=75 WEATHER_CURRENT=22 WEATHER_HIGH=25 WEATHER_LOW=14 CAL=280"

sim normal "$tmp/normal.json" $SPEC
sim aod "$tmp/aod.json" $SPEC
sim edit "$tmp/edit.json" flag=rs
render "$tmp/normal.json" pregled/glavni.png --transparent
render "$tmp/aod.json" pregled/aod.png
render "$tmp/edit.json" pregled/uredjivanje.png --select flag

# every language, with the widest realistic values
items=""
for lang in en sr es it de fr pt pl cs tr hu sv ro nl ca id nb ms da fi vi ru uk el; do
  sim normal "$tmp/w_$lang.json" lang=$lang worst=1 flag=eu
  render "$tmp/w_$lang.json" "$tmp/w_$lang.png"
  items="$items $lang=$tmp/w_$lang.png"
done
python3 -I tools/sheet.py pregled/jezici.png 6 $items

# every screen size the build makes a package for
items=""
for size in 480x480r 466x466r 454x454r 416x416r 360x360r 390x450s 336x384s 320x380s 432x514s; do
  w=${size%%x*}; rest=${size#*x}; h=${rest%?}; shape=${size#${size%?}}
  extra=""; [ "$shape" = s ] && extra="square=1"
  for mode in normal aod; do
    sim $mode "$tmp/$size-$mode.json" width=$w height=$h $extra flag=br $SPEC
    render "$tmp/$size-$mode.json" "$tmp/$size-$mode.png"
  done
  items="$items $w×$h=$tmp/$size-normal.png $w×$h-AOD=$tmp/$size-aod.png"
done
python3 -I tools/sheet.py pregled/ekrani.png 6 $items

# store listing: main screen with a flag in each language, always-on, the flag picker
mkdir -p store
for pair in en:us sr:rs es:es it:it de:de fr:fr pt:br; do
  lang=${pair%%:*}; flag=${pair#*:}
  sim normal "$tmp/s_$lang.json" lang=$lang flag=$flag $SPEC
  render "$tmp/s_$lang.json" "store/$lang-main.png" --transparent
  sim edit "$tmp/e_$lang.json" lang=$lang flag=$flag
  render "$tmp/e_$lang.json" "store/$lang-flag-picker.png" --transparent --select flag
done
render "$tmp/aod.json" store/aod.png --transparent

python3 -I tools/gen_assets.py >/dev/null   # picks up pregled/glavni.png as cover.png
if grep -q '!' "$log"; then
  echo "values that do not fit their box:" >&2
  grep '!' "$log" >&2
  exit 1
fi
rm -rf "$tmp"
echo "ok: previews in pregled/, store pictures in store/, cover.png in assets/"
