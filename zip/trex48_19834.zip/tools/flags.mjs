// Renders the flag pictures and the country names that tools/gen_assets.py uses.
//
// Flags come from flag-icons (MIT, github.com/lipis/flag-icons), 4:3 versions, rendered at 144 x 108 (3x the size on the watch) into
// art-src/flags/<code>.png. Names come from the Unicode CLDR data built into Node (Intl.DisplayNames) in the
// face's seven languages, written to art-src/flags/names.json. Only needed when the flag set changes:
//
//   mkdir -p /tmp/fl && cd /tmp/fl && npm i flag-icons@7.6.0 @resvg/resvg-js@2.6.2
//   NODE_PATH=/tmp/fl/node_modules node tools/flags.mjs
import fs from 'fs'
import path from 'path'
import { createRequire } from 'module'
import { fileURLToPath } from 'url'

const require = createRequire(import.meta.url)
const resolve = (m) => require.resolve(m, { paths: (process.env.NODE_PATH || '').split(':').filter(Boolean) })
const { Resvg } = require(resolve('@resvg/resvg-js'))
const FI = path.dirname(resolve('flag-icons/package.json'))

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const OUT = path.join(ROOT, 'art-src', 'flags')
// the face's languages (tools/strings.py) -> CLDR locale
const LANGS = {
  en: 'en', sr: 'sr-Latn', es: 'es', it: 'it', de: 'de', fr: 'fr', pt: 'pt', pl: 'pl', cs: 'cs', tr: 'tr', hu: 'hu',
  sv: 'sv', ro: 'ro', nl: 'nl', ca: 'ca', id: 'id', nb: 'nb', ms: 'ms', da: 'da', fi: 'fi', vi: 'vi', ru: 'ru',
  uk: 'uk', el: 'el'
}

// groups of countries, not places a person is from
const SKIP = new Set(['xx', 'arab', 'asean', 'cefta', 'eac', 'pc'])
// flags of parts of a country that CLDR has no name for, in the order of LANGS
const NAMES = {
  'gb-eng': 'England|Engleska|Inglaterra|Inghilterra|England|Angleterre|Inglaterra|Anglia|Anglie|İngiltere|Anglia|England|Anglia|Engeland|Anglaterra|Inggris|England|England|England|Englanti|Anh|Англия|Англія|Αγγλία',
  'gb-sct': 'Scotland|Škotska|Escocia|Scozia|Schottland|Écosse|Escócia|Szkocja|Skotsko|İskoçya|Skócia|Skottland|Scoția|Schotland|Escòcia|Skotlandia|Skottland|Scotland|Skotland|Skotlanti|Scotland|Шотландия|Шотландія|Σκωτία',
  'gb-wls': 'Wales|Vels|Gales|Galles|Wales|Pays de Galles|País de Gales|Walia|Wales|Galler|Wales|Wales|Țara Galilor|Wales|Gal·les|Wales|Wales|Wales|Wales|Wales|Xứ Wales|Уэльс|Уельс|Ουαλία',
  'gb-nir': 'Northern Ireland|Severna Irska|Irlanda del Norte|Irlanda del Nord|Nordirland|Irlande du Nord|Irlanda do Norte|Irlandia Północna|Severní Irsko|Kuzey İrlanda|Észak-Írország|Nordirland|Irlanda de Nord|Noord-Ierland|Irlanda del Nord|Irlandia Utara|Nord-Irland|Ireland Utara|Nordirland|Pohjois-Irlanti|Bắc Ireland|Северная Ирландия|Північна Ірландія|Βόρεια Ιρλανδία',
  'es-ct': 'Catalonia|Katalonija|Cataluña|Catalogna|Katalonien|Catalogne|Catalunha|Katalonia|Katalánsko|Katalonya|Katalónia|Katalonien|Catalonia|Catalonië|Catalunya|Katalonia|Catalonia|Catalonia|Catalonien|Katalonia|Catalonia|Каталония|Каталонія|Καταλονία',
  'es-ga': 'Galicia|Galicija|Galicia|Galizia|Galicien|Galice|Galiza|Galicja|Galicie|Galiçya|Galicia|Galicien|Galicia|Galicië|Galícia|Galisia|Galicia|Galicia|Galicien|Galicia|Galicia|Галисия|Галісія|Γαλικία',
  'es-pv': 'Basque Country|Baskija|País Vasco|Paesi Baschi|Baskenland|Pays basque|País Basco|Kraj Basków|Baskicko|Bask Bölgesi|Baszkföld|Baskien|Țara Bascilor|Baskenland|País Basc|Negara Basque|Baskerland|Negara Basque|Baskerlandet|Baskimaa|Xứ Basque|Страна Басков|Країна Басків|Χώρα των Βάσκων'
}
// codes whose CLDR region is not the last part of the code
const REGION = { 'sh-hl': 'SH' } // Saint Helena (sh itself draws the British flag in flag-icons)
// when two codes draw the same flag (Bouvet Island and Norway...), the country keeps it
const PARENTS = ['no', 'au', 'us', 'fr', 'nl', 'gb', 'dk', 'nz', 'fi', 'cn', 'io']

function name(code, key, locale) {
  if (NAMES[code]) return NAMES[code].split('|')[Object.keys(LANGS).indexOf(key)]
  const region = REGION[code] || code.split('-').pop().toUpperCase() // sh-ac: Ascension Island is AC in CLDR
  const long = new Intl.DisplayNames([locale], { type: 'region' }).of(region)
  const short = new Intl.DisplayNames([locale], { type: 'region', style: 'short' }).of(region)
  // the short form when it is a word ("Bosnia", "Hong Kong"), not an abbreviation ("US", "UK", "США")
  return short && short !== long && /\p{Ll}/u.test(short) ? short : long
}

fs.mkdirSync(OUT, { recursive: true })
for (const f of fs.readdirSync(OUT)) if (f.endsWith('.png')) fs.unlinkSync(path.join(OUT, f))
const codes = fs
  .readdirSync(path.join(FI, 'flags', '4x3'))
  .map((f) => f.replace('.svg', ''))
  .filter((c) => !SKIP.has(c))
  .sort((a, b) => (PARENTS.includes(b) ? 1 : 0) - (PARENTS.includes(a) ? 1 : 0) || a.localeCompare(b))

const seen = new Map()
const names = {}
const dropped = []
for (const code of codes) {
  const svg = fs.readFileSync(path.join(FI, 'flags', '4x3', code + '.svg'))
  const png = new Resvg(svg, { fitTo: { mode: 'width', value: 144 } }).render().asPng()
  const key = new Resvg(svg, { fitTo: { mode: 'width', value: 48 } }).render().pixels.toString('base64')
  if (seen.has(key)) {
    dropped.push(code + '=' + seen.get(key))
    continue
  }
  const n = Object.entries(LANGS).map(([k, l]) => [k, name(code, k, l)])
  if (n.some(([, v]) => !v || v.toUpperCase() === code.toUpperCase())) {
    dropped.push(code + ' (no name)')
    continue
  }
  seen.set(key, code)
  fs.writeFileSync(path.join(OUT, code + '.png'), png)
  names[code] = Object.fromEntries(n)
}
const sorted = Object.fromEntries(Object.keys(names).sort().map((c) => [c, names[c]]))
// the order of the list in edit mode: alphabetical by the name in each language (Č after C in Serbian)
const order = Object.fromEntries(
  Object.entries(LANGS).map(([k, l]) => {
    const coll = new Intl.Collator(l)
    return [k, Object.keys(names).sort((a, b) => coll.compare(names[a][k], names[b][k]))]
  })
)
fs.writeFileSync(path.join(OUT, 'names.json'), JSON.stringify({ names: sorted, order }, null, 1) + '\n')
fs.copyFileSync(path.join(FI, 'LICENSE'), path.join(OUT, 'LICENSE-flag-icons'))
console.log(Object.keys(names).length + ' flags; left out: ' + dropped.join(', '))
