#!/usr/bin/env python3
"""Draws every image of the TrailPulse watch face and writes watchface/layout.js.

Run from anywhere: python3 tools/gen_assets.py
Everything is drawn once for a 480 x 480 round screen. The Zepp build (zeus/zpm) shrinks the images for
every other screen (Math.floor(width * screen / 480)) and watchface/index.js scales the coordinates the
same way, so one design serves all round screens; square screens get the same design, centred.
Words come in seven languages (tools/strings.py), flags from art-src/flags (tools/flags.mjs).

Choices still open can be switched with environment variables:
  AOD_TEMP=top|bottom (temperature on always-on),
  GRAPH=js|watch (heart rate graph drawn by our code on a fixed scale with numbers, or by the watch itself),
  AOD_LAYOUT=stay|dodge|rim (always-on: fixed layout, info jumps away from the hands, or info at the rim with
  short hands), AOD_HALO=1|0 (black border around the always-on hands), HILO=1|0 (today's max/min
  temperature next to the current one at the top), HRMIN=left|right|off (today's lowest heart rate on the
  graph: top left, or next to MAX), SECONDS=watch|js (seconds drawn by the watch with equal-width digits, or
  by our code every second with natural spacing; js wakes the watch every second), AOD_DIM=<0..1> (brightness
  of everything on the always-on screen, default 0.7, 1 = full; dimmed, the always-on screen gets its own copies of
  shared images), AOD_TICKS=12|60 (always-on ring: only the 12 hour marks, or every minute).
Images go to assets/common.r/ (round) and assets/common.s/ (square, the same files), coordinates shared with
the JS go to watchface/layout.js, so the picture and the code never drift apart.
"""
import importlib.util
import json
import math
import os
import shutil

from PIL import Image, ImageChops, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'common.r')
OUT_SQUARE = os.path.join(ROOT, 'assets', 'common.s')
FONT_SB = os.path.join(ROOT, 'fonts-src', 'SairaSemiCondensed-SemiBold.ttf')
FONT_B = os.path.join(ROOT, 'fonts-src', 'SairaSemiCondensed-Bold.ttf')
# Saira has no Cyrillic or Greek: words in those alphabets (Russian, Ukrainian, Greek) are drawn in Fira Sans
# Condensed, sized so its capitals are as tall as Saira's
FONT_ALT = os.path.join(ROOT, 'fonts-src', 'FiraSansCondensed-SemiBold.ttf')
FLAGS_DIR = os.path.join(ROOT, 'art-src', 'flags')  # flag-icons (MIT), rendered by tools/flags.mjs
AOD_TEMP = os.environ.get('AOD_TEMP', 'top')
GRAPH = os.environ.get('GRAPH', 'js')
AOD_LAYOUT = os.environ.get('AOD_LAYOUT', 'stay')
AOD_HALO = os.environ.get('AOD_HALO', '1') == '1'
HILO = os.environ.get('HILO', '1') == '1'  # today's max/min temperature next to the current one
SECONDS = os.environ.get('SECONDS', 'watch')  # seconds drawn by the watch (IMG_TIME, no timer) or by our code every second
AOD_DIM = float(os.environ.get('AOD_DIM', '0.7'))  # always-on brightness: fewer lit subpixels, less battery
AOD_TICKS = os.environ.get('AOD_TICKS', '12')  # always-on ring: only the 12 hour marks, or all 60 ticks
HRMIN = os.environ.get('HRMIN', 'left')  # today's lowest heart rate on the graph: left, right (next to MAX) or off

_spec = importlib.util.spec_from_file_location('strings', os.path.join(ROOT, 'tools', 'strings.py'))
S = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(S)
LANGS = S.LANGS

# heart rate graph area (x, y, w, h): narrow enough that the axis numbers stay inside the round screen
GX, GY, GW, GH = 64, 296, 352, 62
# flag under the seconds: 4:3, with a transparent margin so the same image is the edit-mode preview
FW, FH, FPAD = 48, 36, 4
FLAG_NONE = 109000  # edit-mode id of "no flag"; a flag's id comes from its code (flag_id)
TIPS_W = 200  # edit-mode tip with the name of the choice

W = 480
SS = 4  # supersampling for icons

WHITE = (255, 255, 255, 255)
GRAY = (140, 140, 140, 255)
LABEL_GRAY = (172, 172, 172, 255)  # field labels, a bit lighter than the seconds for reading in the sun
DIM = (60, 60, 60, 255)
GRID = (44, 44, 44, 255)
ORANGE = (255, 122, 0, 255)
EMPTY = (72, 72, 72, 255)
BLACK = (0, 0, 0, 255)
CLEAR = (0, 0, 0, 0)

layout = {}
TEXTS = {}  # words edit mode shows, per language: written to lang/<lang>.bin (see lang_files)


def save(img, rel):
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, optimize=True)
    return rel


def font(size, bold=False, alt=False):
    if alt:
        return ImageFont.truetype(FONT_ALT, round(size * _cap(FONT_B if bold else FONT_SB) / _cap(FONT_ALT)))
    return ImageFont.truetype(FONT_B if bold else FONT_SB, size)


def _cap(path):
    """Capital height of a font per pixel of size."""
    return -ImageFont.truetype(path, 200).getbbox('H', anchor='ls')[1] / 200


def needs_alt(text):
    """Text with Greek or Cyrillic letters."""
    return any(0x0370 <= ord(ch) <= 0x052F for ch in text)


# ---------------------------------------------------------------- text styles

class Style:
    """All images of one style share height and baseline, so they line up when placed
    with top = baseline - self.base."""

    def __init__(self, name, size, color, bold=False, digits_only=False, tracking=0):
        self.name, self.size, self.color, self.bold, self.tracking = name, size, color, bold, tracking
        self.f = font(size, bold)
        self.fa = font(size, bold, alt=True)
        top = self.f.getbbox('0123456789:' if digits_only else 'ĐČĆŠŽÅÉÌÛỄẪ0123456789°%Ąbdhkl', anchor='ls')[1]
        bottom = self.f.getbbox('0123456789:' if digits_only else 'gjpqy,ĄęÇẬỢ', anchor='ls')[3]
        if not digits_only:
            top = min(top, self.fa.getbbox('ЙЁЇΪ', anchor='ls')[1])
            bottom = max(bottom, self.fa.getbbox('ДЩЦ', anchor='ls')[3])
        self.base = -top + 1
        self.h = self.base + bottom + 1

    def font_for(self, text, size=None):
        if size is None:
            return self.fa if needs_alt(text) else self.f
        return font(size, self.bold, alt=needs_alt(text))

    def width(self, text):
        return int(math.ceil(self.f.getlength(text)))

    @property
    def cell(self):
        """Width of every digit image in a TEXT_IMG set: the watch draws each digit in a cell this wide
        (a narrow "1" left a gap after it and pushed "MAX 118" into its label), so all digits get it."""
        return max(self.width(d) for d in '0123456789') + 1

    def text_w(self, text):
        """Width of a value drawn by TEXT_IMG with this style's digit set."""
        return sum(self.cell if ch.isdigit() else self.width(ch) + 1 for ch in text)

    def render(self, text, extra_left=0, color=None, f=None):
        f = f or self.font_for(text)
        if self.tracking:  # letters drawn one by one with extra space between them
            advances = [f.getlength(ch) for ch in text]
            w = int(math.ceil(sum(advances) + self.tracking * (len(text) - 1))) + extra_left + 1
            img = Image.new('RGBA', (w, self.h), CLEAR)
            d = ImageDraw.Draw(img)
            x = extra_left
            for ch, adv in zip(text, advances):
                d.text((x, self.base), ch, font=f, fill=color or self.color, anchor='ls')
                x += adv + self.tracking
            return img
        w = int(math.ceil(f.getlength(text))) + extra_left + 1
        img = Image.new('RGBA', (w, self.h), CLEAR)
        ImageDraw.Draw(img).text((extra_left, self.base), text, font=f, fill=color or self.color, anchor='ls')
        return img

    def save_text(self, text, rel, extra_left=0, color=None):
        img = self.render(text, extra_left, color)
        save(img, rel)
        return img.width

    def save_fit(self, text, rel, room, color=None):
        """Like save_text, but a word wider than room is drawn a little smaller (same baseline and height):
        DONNERSTAG next to the date."""
        size = self.size
        img = self.render(text, color=color)
        while img.width > room and size > self.size * 0.7:
            size -= 1
            img = self.render(text, color=color, f=self.font_for(text, size))
        assert img.width <= room, (text, img.width, room)
        save(img, rel)
        return img.width

    def digit_set(self, folder, extras=True, color=None, tabular=True):
        """0-9 plus separators/units/invalid for TEXT_IMG. Returns layout info.
        tabular: every digit centred in an image of the same width (needed for TEXT_IMG on the watch);
        sets placed digit by digit by our code (time, seconds, day) keep their natural widths."""
        widths = []
        for d in '0123456789':
            if tabular:
                img = Image.new('RGBA', (self.cell, self.h), CLEAR)
                dx = round((self.cell - 1 - self.width(d)) / 2)
                ImageDraw.Draw(img).text((dx, self.base), d, font=self.f, fill=color or self.color, anchor='ls')
                save(img, f'{folder}/{d}.png')
                widths.append(img.width)
            else:
                widths.append(self.save_text(d, f'{folder}/{d}.png', color=color))
        info = {'dir': folder, 'h': self.h, 'base': self.base, 'w': widths}
        if extras:
            def t(text, name, **kw):
                return self.save_text(text, f'{folder}/{name}.png', color=color, **kw)
            info['comma'] = t(',', 'comma')
            info['dot'] = t('.', 'dot')  # decimal point in English, comma in the other languages
            info['colon'] = t(':', 'colon')
            info['minus'] = t('-', 'minus')
            info['deg'] = t('°', 'deg')
            info['pct'] = t('%', 'pct')
            info['km'] = t('KM', 'km', extra_left=max(3, self.size // 6))
            info['mi'] = t('MI', 'mi', extra_left=max(3, self.size // 6))
            info['hr'] = t('h', 'h', extra_left=2)
            info['none'] = t('--', 'none')
        return info


T_BIG = Style('time', 134, WHITE, digits_only=True)
T_SEC = Style('sec', 54, GRAY, digits_only=True)
D_DAY = Style('day', 58, WHITE, digits_only=True)
V25 = Style('v25', 25, WHITE)
V24 = Style('v24', 24, WHITE)
V18 = Style('v18', 18, WHITE)
L18 = Style('l18', 18, LABEL_GRAY)
V20 = Style('v20', 20, WHITE)  # top row of fields (STRES, TEMP, HybridCharge), a bit bigger than the bottom ones
L20 = Style('l20', 20, LABEL_GRAY)
LABEL_STYLES = {'l18': L18, 'l20': L20}
N25 = Style('n25', 25, WHITE)
A40 = Style('a40', 40, WHITE, digits_only=True)
N17 = Style('n17', 17, WHITE)
AC = Style('ac', 15, (205, 205, 205, 255), tracking=1.5)  # always-on caption over the distance
AX = Style('ax', 16, (165, 165, 165, 255))  # graph axis numbers
MX = Style('mx', 16, WHITE, digits_only=True)  # today's highest heart rate on the graph
WX = Style('wx', 17, (205, 205, 205, 255))  # today's max/min temperature


# ---------------------------------------------------------------- icon helpers

class Canvas:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new('RGBA', (w * SS, h * SS), CLEAR)
        self.d = ImageDraw.Draw(self.im)

    def P(self, pts):
        return [(x * SS, y * SS) for x, y in pts]

    def line(self, pts, fill, w):
        self.d.line(self.P(pts), fill=fill, width=max(1, int(w * SS)), joint='curve')

    def circle(self, cx, cy, r, fill=None, outline=None, w=1):
        self.d.ellipse([(cx - r) * SS, (cy - r) * SS, (cx + r) * SS, (cy + r) * SS], fill=fill, outline=outline,
                       width=int(w * SS))

    def poly(self, pts, fill):
        self.d.polygon(self.P(pts), fill=fill)

    def rrect(self, x0, y0, x1, y1, r, fill=None, outline=None, w=1):
        self.d.rounded_rectangle([x0 * SS, y0 * SS, x1 * SS, y1 * SS], radius=r * SS, fill=fill, outline=outline,
                                 width=int(w * SS))

    def pie(self, box, start, end, fill):
        self.d.pieslice([v * SS for v in box], start=start, end=end, fill=fill)

    def done(self):
        return self.im.resize((self.w, self.h), Image.LANCZOS)


def heart_icon(size=18, col=ORANGE):
    c = Canvas(size + 2, size + 2)
    cx, cy, s = (size + 2) / 2, (size + 2) / 2 + 1, size
    r = s * 0.27
    c.circle(cx - r, cy - s * 0.12, r, fill=col)
    c.circle(cx + r, cy - s * 0.12, r, fill=col)
    c.poly([(cx - 2 * r - 0.2, cy - s * 0.06), (cx + 2 * r + 0.2, cy - s * 0.06), (cx, cy + s * 0.48)], col)
    return c.done()


def feet_icon(col=WHITE):
    c = Canvas(20, 22)
    for dx, dy in ((1, 16), (11, 10)):
        c.d.ellipse([(dx) * SS, (dy - 12) * SS, (dx + 7.5) * SS, (dy + 1) * SS], fill=col)
        c.d.ellipse([(dx + 0.8) * SS, (dy + 2.6) * SS, (dx + 6.7) * SS, (dy + 7.6) * SS], fill=col)
    return c.done()


def alarm_icon(col=WHITE):
    c = Canvas(30, 30)
    cx, cy = 15, 16.5
    c.circle(cx, cy, 10.5, outline=col, w=2.6)
    c.line([(cx, cy - 6), (cx, cy), (cx + 4.5, cy + 2)], col, 2.2)
    for sx in (-1, 1):
        c.pie((cx + sx * 9 - 6, cy - 15, cx + sx * 9 + 6, cy - 3), 180 if sx < 0 else 270, 270 if sx < 0 else 360, col)
        c.line([(cx + sx * 6.5, cy + 8.5), (cx + sx * 10, cy + 13)], col, 2.4)
    return c.done()


# ---------------------------------------------------------------- weather icons (Zepp index 0-28)

def weather_icon(idx):
    c = Canvas(56, 46)

    def sun(x, y, r=10):
        for i in range(8):
            a = i * math.pi / 4
            c.line([(x + math.cos(a) * (r + 3.5), y + math.sin(a) * (r + 3.5)),
                    (x + math.cos(a) * (r + 8), y + math.sin(a) * (r + 8))], ORANGE, 2.4)
        c.circle(x, y, r, fill=ORANGE)

    def moon(x, y, r=11):
        c.circle(x, y, r, fill=ORANGE)
        c.circle(x + r * 0.55, y - r * 0.35, r * 0.85, fill=CLEAR)

    def cloud(x, y, col=WHITE, scale=1.0, cut=True):
        s = scale
        if cut:
            c.circle(x - 4 * s, y + 3 * s, 9.5 * s, fill=BLACK)
            c.circle(x + 9 * s, y - 2 * s, 12.5 * s, fill=BLACK)
            c.rrect(x - 18 * s, y + 1 * s, x + 26 * s, y + 18.5 * s, 8.5 * s, fill=BLACK)
        c.circle(x - 4 * s, y + 3 * s, 8 * s, fill=col)
        c.circle(x + 9 * s, y - 2 * s, 11 * s, fill=col)
        c.rrect(x - 16.5 * s, y + 2.5 * s, x + 24.5 * s, y + 17 * s, 7.2 * s, fill=col)

    def drops(n, x0=14, y0=37, col=WHITE):
        for i in range(n):
            x = x0 + i * (26 / max(1, n - 1) if n > 1 else 0) + (6 if n == 1 else 0)
            c.line([(x + 2, y0), (x - 1, y0 + 7)], col, 2.4)

    def flakes(n, x0=14, y0=40):
        for i in range(n):
            x = x0 + i * (26 / max(1, n - 1) if n > 1 else 0) + (6 if n == 1 else 0)
            for a in (0, 60, 120):
                r = math.radians(a)
                c.line([(x - math.cos(r) * 3.5, y0 - math.sin(r) * 3.5), (x + math.cos(r) * 3.5, y0 + math.sin(r) * 3.5)],
                       WHITE, 1.6)

    def bolt(x=27, y=30):
        c.poly([(x + 2, y), (x - 5, y + 9), (x - 0.5, y + 9), (x - 3, y + 16), (x + 5, y + 6), (x + 0.5, y + 6), (x + 3, y)],
               ORANGE)

    def hail(n=3, y=42):
        for i in range(n):
            c.circle(16 + i * 11, y, 1.8, fill=WHITE)

    def lines(n=3, y0=33, col=GRAY, x0=8, x1=48):
        for i in range(n):
            y = y0 + i * 5
            c.line([(x0 + (i % 2) * 4, y), (x1 - ((i + 1) % 2) * 4, y)], col, 2.2)

    def waves(n=3, y0=14, col=ORANGE):
        for i in range(n):
            y = y0 + i * 9
            pts = [(6 + t, y + math.sin(t / 5.0) * 2.5) for t in range(0, 45, 2)]
            c.line(pts, col, 2.4)

    top_cloud = (30, 14)
    if idx == 3:
        sun(28, 23, 11)
    elif idx == 28:
        moon(28, 23, 12)
    elif idx in (0, 1, 2):
        sun(19, 13, 9)
        cloud(*top_cloud)
        if idx == 1:
            drops(2, 16, 38)
        if idx == 2:
            flakes(2, 16, 41)
    elif idx in (26, 27):
        moon(19, 13, 10)
        cloud(*top_cloud)
        if idx == 27:
            drops(2, 16, 38)
    elif idx == 4:
        cloud(22, 12, GRAY, 0.8, cut=False)
        cloud(30, 18, WHITE)
    elif idx in (5, 7, 10, 24, 18, 21):
        dark = idx in (18, 21, 24)
        cloud(28, 10, GRAY if dark else WHITE, cut=False)
        n = {5: 2, 7: 3, 10: 4, 24: 4, 18: 5, 21: 5}[idx]
        drops(n, 12 if n > 3 else 16, 35)
    elif idx in (6, 8, 9, 16):
        cloud(28, 10, WHITE, cut=False)
        n = {6: 2, 8: 3, 9: 4, 16: 5}[idx]
        flakes(n, 12 if n > 3 else 16, 39)
    elif idx == 12:
        cloud(28, 10, WHITE, cut=False)
        drops(1, 12, 35)
        flakes(1, 30, 39)
    elif idx == 13:
        cloud(28, 8, GRAY, cut=False)
        lines(3, 30)
    elif idx == 14:
        sun(28, 14, 9)
        lines(3, 31)
    elif idx in (15, 20):
        cloud(28, 8, GRAY, cut=False)
        bolt(27, 27)
        if idx == 20:
            hail(2, 41)
    elif idx == 19:
        cloud(28, 10, WHITE, cut=False)
        drops(2, 14, 35)
        hail(3, 42)
    elif idx in (11, 22, 23, 17):
        waves(3 if idx != 23 else 4, 12, ORANGE if idx != 17 else GRAY)
        if idx == 17:
            for x, y in ((12, 38), (26, 41), (40, 37)):
                c.circle(x, y, 1.6, fill=ORANGE)
    else:  # 25 = no data
        c.line([(18, 23), (38, 23)], GRAY, 3)
    return c.done()


# ---------------------------------------------------------------- main screen layout

def build_main():
    L = {}
    # alarm: icon + next alarm time (both only while an alarm is set), centred as a pair
    save(alarm_icon(), 'icons/alarm.png')
    save(Image.new('RGBA', (1, 1), CLEAR), 'icons/blank.png')
    pair = 30 + 6 + V20.text_w('06:30') + 5
    ax = round(240 - pair / 2)
    L['alarm'] = {'x': ax, 'y': 21, 'w': 30, 'h': 30, 'tx': ax + 36, 'ty': 44 - V20.base, 'tw': 70}

    # date: day digits right-aligned to x 158, weekday/month at x 166, ending before the weather icon
    L['day'] = D_DAY.digit_set('day', extras=False, tabular=False)
    L['day'].update({'right': 158, 'baseline': 107})
    room = 310 - 166 - 4
    wk = word_set(N25, S.WEEKDAYS, 'week', room)
    mo = word_set(N25, S.MONTHS, 'month', room, color=ORANGE)
    L['week'] = {'x': 166, 'y': 80 - N25.base, 'h': N25.h, **wk}
    L['month'] = {'x': 166, 'y': 107 - N25.base, 'h': N25.h, **mo}

    for i in range(29):
        save(weather_icon(i), f'weather/{i}.png')
    L['weather'] = {'x': 310, 'y': 38, 'w': 56, 'h': 46, 'none': 25}
    L['v25'] = V25.digit_set('v25')
    if HILO:
        # current temperature right-aligned, today's max over min (small, with arrows) right of it;
        # the pair is centred under the icon for a typical "6°" + "12°"
        hx = 336
        L['temp'] = {'x': hx - 7 - 100, 'w': 100, 'y': 107 - V25.base, 'align': 'right'}
        L['wx'] = WX.digit_set('wx')
        for name, up in (('up', True), ('down', False)):
            c = Canvas(9, 7)
            c.poly([(0, 6.5), (9, 6.5), (4.5, 0.5)] if up else [(0, 0.5), (9, 0.5), (4.5, 6.5)], LABEL_GRAY)
            save(c.done(), f'icons/{name}.png')
        L['hilo'] = {'arrowX': hx, 'x': hx + 12, 'w': 60, 'hiY': 98 - WX.base, 'loY': 117 - WX.base,
                     'upY': 98 - 9, 'downY': 117 - 9}
    else:
        L['temp'] = {'x': 288, 'w': 100, 'y': 107 - V25.base, 'align': 'center'}

    L['sep'] = {'x': 56, 'y': 121, 'w': 368, 'h': 2, 'color': 0x3c3c3c}

    # time: digits, colon and seconds as single images; JS centres the group each minute
    L['time'] = T_BIG.digit_set('time', extras=False, tabular=False)
    L['time']['colon'] = T_BIG.save_text(':', 'time/colon.png')
    L['time']['y'] = 234 - T_BIG.base
    # the watch draws IMG_TIME digits in fixed cells, so its set is tabular; our own code places natural widths
    if SECONDS == 'watch':
        L['sec'] = T_SEC.digit_set('sect', extras=False, tabular=True)
    else:
        L['sec'] = T_SEC.digit_set('sec', extras=False, tabular=False)
    L['sec']['mode'] = SECONDS
    L['sec']['y'] = 178 - T_SEC.base
    L['sec']['gap'] = 12

    L['v18'] = V18.digit_set('v18')
    L['v20'] = V20.digit_set('v20')
    L['v24'] = V24.digit_set('v24')
    # orange digits for the battery value when it is low
    V20.digit_set('v20o', color=ORANGE)
    V24.digit_set('v24o', color=ORANGE)

    L['lbase'] = {k: st.base for k, st in LABEL_STYLES.items()}
    save(feet_icon(), 'icons/feet.png')

    # graph: frame, grid and axis numbers in one image; the curve is drawn on top (by our code or the watch).
    # x: 0-24 h with a line every 6 h; y (our code only): fixed 35-185 bpm
    gx, gy, gw, gh = GX, GY, GW, GH
    lo, hi = 35, 185
    top = 292
    img = Image.new('RGBA', (W, 86), CLEAR)
    gc = Canvas(W, 86)
    oy = gy - top
    gc.line([(gx, oy), (gx + gw, oy)], GRID, 1.6)
    gc.line([(gx, oy + gh), (gx + gw, oy + gh)], GRID, 1.6)
    for k in range(5):
        xx = gx + k * gw / 4
        gc.line([(xx, oy), (xx, oy + gh)], GRID, 1.6)
    if GRAPH == 'js':
        for v in (50, 100, 150):
            yy = oy + (1 - (v - lo) / (hi - lo)) * gh
            gc.line([(gx, yy), (gx + gw, yy)], (34, 34, 34, 255), 1.2)
    img.alpha_composite(gc.done())
    d = ImageDraw.Draw(img)
    for k, hour in enumerate((0, 6, 12, 18, 24)):
        d.text((gx + k * gw / 4, oy + gh + 16), str(hour), font=AX.f, fill=AX.color, anchor='ms')
    if GRAPH == 'js':
        for v in (50, 100, 150):
            yy = oy + (1 - (v - lo) / (hi - lo)) * gh
            d.text((gx - 4, yy), str(v), font=AX.f, fill=AX.color, anchor='rm')
    save(img, 'graph/grid.png')
    L['graph'] = {'mode': GRAPH, 'gridX': 0, 'gridY': top, 'x': gx, 'y': gy, 'w': gw, 'h': gh, 'lo': lo, 'hi': hi,
                  'color': 0xff7a00, 'fill': 0x5c2c00}
    # where you are now: orange dot with a black ring at the end of the line
    dot = Canvas(14, 14)
    dot.circle(7, 7, 6.5, fill=BLACK)
    dot.circle(7, 7, 4.6, fill=ORANGE)
    save(dot.done(), 'graph/dot.png')
    # today's highest heart rate, top right inside the graph: gray "MAX" + white number
    L['mx'] = MX.digit_set('mx', extras=False, tabular=False)  # placed digit by digit by JS
    lw = AX.save_text('MAX', 'graph/max.png')
    L['graph'].update({'dot': 14, 'maxRight': gx + gw - 4, 'maxY': gy + 15 - MX.base, 'maxLabelY': gy + 15 - AX.base,
                       'maxLabelW': lw, 'maxGap': 4})
    # today's lowest heart rate (about the resting one): top left inside the graph, or just before MAX
    if HRMIN != 'off':
        L['graph'].update({'min': HRMIN, 'minLeft': gx + 5, 'minLabelW': AX.save_text('MIN', 'graph/min.png'),
                           'pairGap': 12})

    # step goal bar: 22 slanted segments, IMG_LEVEL frames 0..22
    n, seg, gapw, slant = 22, 8.2, 3, 4
    bw = int(math.ceil(n * (seg + gapw) + slant))
    for k in range(n + 1):
        c = Canvas(bw, 12)
        for i in range(n):
            sx = i * (seg + gapw)
            c.poly([(sx + slant, 0.5), (sx + seg + slant, 0.5), (sx + seg, 11.5), (sx, 11.5)], ORANGE if i < k else EMPTY)
        save(c.done(), f'bar/{k}.png')
    L['bar'] = {'x': 118, 'y': 413, 'n': n + 1}
    return L


def word_set(style, words, folder, room=None, color=None):
    """Weekday or month names of every language: an image per different word (a language whose word is the
    same as an earlier language's uses that one: a = one base-36 digit per word naming the language whose
    picture to use) and the widths, per language."""
    first, widths, alias = {}, {}, {}
    for li, lang in enumerate(LANGS):
        widths[lang], alias[lang] = [], ''
        for i, word in enumerate(words[lang]):
            if (i, word) not in first:
                rel = f'{folder}/{lang}/{i + 1}.png'
                w = style.save_fit(word, rel, room, color) if room else style.save_text(word, rel, color=color)
                first[(i, word)] = (li, w)
            src, w = first[(i, word)]
            widths[lang].append(w)
            alias[lang] += B36[src]
    return {'w': widths, 'a': alias}


def time_row(L, text):
    """Where updateTime() in index.js puts the digits of text ("10:08") and the seconds: same arithmetic."""
    t, s = L['time'], L['sec']
    sec_max = max(s['w'][a] + s['w'][b] for a in range(6) for b in range(10))
    ws = [t['colon'] if ch == ':' else t['w'][int(ch)] for ch in text]
    x = round(240 - (sum(ws) + s['gap'] + sec_max) / 2)
    xs = []
    for w in ws:
        xs.append(x)
        x += w
    return xs, x + s['gap'], sec_max


# ---------------------------------------------------------------- flag under the seconds

def flag_id(code):
    """Edit-mode id of a flag, made from its code so a chosen flag survives updates that add flags."""
    if len(code) == 2:
        return 110000 + (ord(code[0]) - 97) * 26 + (ord(code[1]) - 97)
    return 111000 + FLAG_EXTRA.index(code)


FLAG_EXTRA = ['gb-eng', 'gb-sct', 'gb-wls', 'gb-nir', 'es-ct', 'es-ga', 'es-pv', 'sh-ac', 'sh-hl', 'sh-ta']


def build_flags(main):
    with open(os.path.join(FLAGS_DIR, 'names.json')) as fh:
        data = json.load(fh)
    names, order = data['names'], data['order']
    mask = Canvas(FW, FH)
    mask.rrect(0, 0, FW, FH, 3.5, fill=WHITE)
    mask = mask.done().split()[3]
    for code in names:
        flag = Image.open(os.path.join(FLAGS_DIR, code + '.png')).convert('RGBA').resize((FW, FH), Image.LANCZOS)
        flag.putalpha(ImageChops.multiply(flag.split()[3], mask))
        img = Image.new('RGBA', (FW + 2 * FPAD, FH + 2 * FPAD), CLEAR)
        img.alpha_composite(flag, (FPAD, FPAD))
        save(img, f'flags/{code}.png')
    # edit-mode picture of "no flag": a dashed outline with a slash
    c = Canvas(FW + 2 * FPAD, FH + 2 * FPAD)
    col = (120, 120, 120, 255)
    x0, y0, x1, y1 = FPAD + 1, FPAD + 1, FPAD + FW - 1, FPAD + FH - 1
    for a, b in (((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))):
        steps = 6
        for k in range(steps):
            p = [a[i] + (b[i] - a[i]) * k / steps for i in (0, 1)]
            q = [a[i] + (b[i] - a[i]) * (k + 0.55) / steps for i in (0, 1)]
            c.line([tuple(p), tuple(q)], col, 1.6)
    c.line([(x0 + 8, y1 - 6), (x1 - 8, y0 + 6)], col, 2)
    save(c.done(), 'flags/none.png')

    # the flag is centred under the seconds by JS; in edit mode its box stands where it is for 10:08
    _, sec_x, sec_max = time_row(main, '10:08')
    y = 230 - FH - FPAD
    box = {'x': round(sec_x + (sec_max - FW) / 2) - FPAD, 'y': y, 'w': FW + 2 * FPAD, 'h': FH + 2 * FPAD}
    for name, colr in (('sel', ORANGE), ('unsel', (110, 110, 110, 255))):
        c = Canvas(box['w'], box['h'])
        c.rrect(1, 1, box['w'] - 1, box['h'] - 1, 6, outline=colr, w=2)
        save(c.done(), f'edit/flag_{name}.png')
    tips_left = min(max(box['x'] + (box['w'] - TIPS_W) / 2, 30), W - 30 - TIPS_W)
    # the list in each language (codes in the alphabetical order of the names, and the names) goes to that
    # language's text file (lang_files)
    TEXTS['fl'] = {lang: '|'.join(order[lang]) for lang in LANGS}
    TEXTS['fn'] = {lang: '|'.join(names[c][lang] for c in order[lang]) for lang in LANGS}
    return {'w': FW, 'h': FH, 'pad': FPAD, 'y': y, 'edit': 109, 'none': FLAG_NONE, 'box': box,
            'tipsX': round(tips_left - box['x']), 'tipsY': -40, 'extra': FLAG_EXTRA}


# ---------------------------------------------------------------- data slots (editable)

# key: hmUI.data_type name(s) (first one the firmware knows wins), unit, sample value for previews,
# widest realistic value (an option is offered in a slot only if this still fits in every language).
# Labels and titles are in tools/strings.py.
OPTIONS = [
    (100001, ['HEART'], '', '63', '199'),
    (100002, ['STRESS'], '', '28', '100'),
    (100003, ['WEATHER_CURRENT'], 'deg', '6', '-18'),
    (100004, ['HYBRID_CHARGE', 'BIO_CHARGE'], '', '72', '100'),
    (100005, ['BODY_TEMP'], 'deg', '36,5', '37,8'),
    (100006, ['STEP'], '', '3829', '24680'),
    (100007, ['DISTANCE'], 'km', '3,05', '18,88'),
    (100008, ['BATTERY'], 'pct', '45', '100'),
    (100009, ['CAL'], '', '412', '2888'),
    (100010, ['SPO2'], 'pct', '97', '100'),
    (100011, ['PAI_WEEKLY'], '', '86', '188'),
    (100012, ['READINESS'], '', '74', '100'),
    (100013, ['RECOVERY_TIME'], 'hr', '18', '88'),
    (100014, ['FLOOR'], '', '6', '88'),
    (100015, ['HUMIDITY'], 'pct', '64', '100'),
    (100016, ['UVI'], '', '2', '10'),
    (100017, ['STAND'], '', '7', '12'),
    (100018, ['VO2MAX'], '', '48', '65'),
    (100019, ['TRAINING_LOAD'], '', '312', '999'),
    (100020, ['SUN_SET'], 'hhmm', '18:12', '21:59'),
    (100021, ['WEATHER_HIGH'], 'deg', '12', '-18'),
    (100022, ['WEATHER_LOW'], 'deg', '3', '-25'),
    (100023, ['MONTH_RUN_DISTANCE'], 'km', '86,42', '288,88'),
]
# value turns orange (label stays gray): sensor name(s), 'above' or 'below', threshold
WARN = {100002: (['STRESS'], 'above', 60), 100004: (['HYBRID_CHARGE', 'BIO_CHARGE'], 'below', 30),
        100008: (['BATTERY'], 'below', 20)}


def label_image(label, style=L18, color=None):
    if label == '#heart':
        return heart_icon(style.size)
    if label == '#feet':
        return feet_icon()
    return style.render(label, color=color)


B36 = '0123456789abcdefghijklmnopqrstuvwxyz'


def labw(o, ls, lang):
    """[long w, long h, short w, short h] of an option's label in a label style and language."""
    li = LANGS.index(lang)
    a, b = LANGS[B36.index(o['la'][li])], LANGS[B36.index(o['sa'][li])]
    return o['lw'][a][ls] + o['sw'][b][ls]


def tips_place(box):
    """Edit-mode tip centred over or under its box, but kept inside the round screen."""
    bx, by, bw, bh = box
    left = min(max(bx + (bw - TIPS_W) / 2, 30), W - 30 - TIPS_W)
    return round(left - bx), (-40 if by > 300 else bh + 6)


def preview_path(slot, o, lang, ox, short):
    """Edit-mode preview of an option in a slot; index.js builds the same name. Two previews with the same name
    show the same thing: same value style, place, label picture and decimal sign."""
    li = LANGS.index(lang)
    alias = LANGS[B36.index((o['sa'] if short else o['la'])[li])]
    point = 'p' if lang == 'en' and ',' in o['sample'] else ''
    return f'preview/{slot["style"]}_{ox}/{alias}/{o["id"]}{"s" if short else ""}{point}.png'


def build_slots(main):
    """Slot boxes. Row slots are spaced so the default of every slot fits in every language."""
    opts = []
    for oid, keys, unit, sample, worst in OPTIONS:
        labels = S.LABELS[oid]
        o = {'id': oid, 'keys': keys, 'unit': unit, 'sample': sample, 'worst': worst,
             'icon': labels['en'][0].startswith('#')}
        # a label is drawn once per different text: each language points at the first language with the same
        # words (la: long label, sa: short label, one base-36 digit per language)
        for key, sizes_key, variant, suffix in (('la', 'lw', 0, ''), ('sa', 'sw', 1, 's')):
            first, alias, sizes = {}, '', {}
            for lang in LANGS:
                text = labels[lang][variant]
                if text not in first:
                    first[text] = lang
                    sizes[lang] = {}
                    for ls, style in LABEL_STYLES.items():
                        img = label_image(text, style)
                        save(img, f'label/{ls}/{lang}/{oid}{suffix}.png')
                        sizes[lang][ls] = [img.width, img.height]
                alias += B36[LANGS.index(first[text])]
            o[key], o[sizes_key] = alias, sizes
        if oid in WARN:
            o['warn'] = {'sensors': WARN[oid][0], 'when': WARN[oid][1], 'limit': WARN[oid][2]}
        opts.append(o)

    def content_w(o, digits_style, ls, lang, short=False, value='worst'):
        w = labw(o, ls, lang)[2 if short else 0] + (4 if o['icon'] else 6)
        # each TEXT_IMG glyph image is its advance + 1px (see Style.render)
        w += digits_style.text_w(o[value])
        if o['unit']:
            w += 1 + {'deg': digits_style.width('°'), 'pct': digits_style.width('%'), 'hr': digits_style.width('h') + 2,
                      'km': digits_style.width('KM') + max(3, digits_style.size // 6), 'hhmm': 0}[o['unit']]
        return w

    by = {o['id']: o for o in opts}
    defaults = [100001, 100002, 100003, 100004]

    def need(oid):
        # the English label in full; other languages fall back to their short label where the long one
        # does not fit
        return max([content_w(by[oid], V20, 'l20', 'en')] +
                   [content_w(by[oid], V20, 'l20', lang, short=True) for lang in LANGS])

    # room each row slot needs: its default's widest value in its longest language. Body temperature
    # ("37,8°") no longer fits the TEMP slot in every language; it is offered in the bottom slots.
    widths = [need(d) for d in defaults]
    # the row is at the widest part of the screen: the circle leaves x 5-475 even at the bottom of the boxes
    left, right = 12, 472  # TEXT_IMG digits are all as wide as the widest one
    gap = (right - left - sum(widths)) / 3
    assert gap >= 7, ('row of fields too tight', gap)
    xs, x = [], left
    for w in widths:
        xs.append(round(x))
        x += w + gap
    slots = []
    for i, d in enumerate(defaults):
        x0 = xs[i]
        x1 = (xs[i + 1] - 8) if i < 3 else right
        slots.append({'id': f'row{i + 1}', 'edit': 101 + i, 'def': d, 'style': 'v20', 'ls': 'l20', 'x': x0,
                      'baseline': 277, 'box': [x0 - 4, 258, x1 - x0 + 7, 28]})  # 1px between neighbouring boxes
    slots.append({'id': 'steps', 'edit': 105, 'def': 100006, 'style': 'v24', 'ls': 'l18', 'x': 94, 'baseline': 402,
                  'box': [89, 381, 114, 28]})
    slots.append({'id': 'dist', 'edit': 106, 'def': 100007, 'style': 'v20', 'ls': 'l20', 'x': 214, 'baseline': 402,
                  'box': [209, 382, 200, 28]})
    # battery is centred under the bar, for the length of its label in each language
    bws = {lang: content_w(by[100008], V20, 'l20', lang, value='sample') for lang in LANGS}
    bxl = {lang: round(240 - bws[lang] / 2) for lang in LANGS}
    b0 = min(bxl.values()) - 22
    b1 = max(bxl[lang] + bws[lang] for lang in LANGS) + 22
    slots.append({'id': 'bat', 'edit': 107, 'def': 100008, 'style': 'v20', 'ls': 'l20', 'x': bxl['en'], 'xl': bxl,
                  'baseline': 459, 'box': [b0, 439, b1 - b0, 28]})

    styles = {'v18': V18, 'v20': V20, 'v24': V24}
    for s in slots:
        bx, by_, bw_, bh = s['box']
        st, ls = styles[s['style']], s['ls']

        def sx(lang):
            return s['xl'][lang] if 'xl' in s else s['x']

        def max_w(lang):
            # max content width that still fits before the box edge
            return bw_ - (sx(lang) - bx) - 2
        # an option is offered in the languages where its value fits with at least the short label, and shows
        # the long label where that fits too (fit, short: option id -> one bit per language)
        s['fit'], s['short'] = {}, {}
        for o in opts:
            fit = sum(1 << i for i, lang in enumerate(LANGS) if content_w(o, st, ls, lang, short=True) <= max_w(lang))
            if not fit:
                continue
            s['fit'][o['id']] = fit
            short = sum(1 << i for i, lang in enumerate(LANGS) if content_w(o, st, ls, lang) > max_w(lang))
            if short:
                s['short'][o['id']] = short
        assert s['fit'].get(s['def']) == (1 << len(LANGS)) - 1, (s['id'], 'default does not fit in every language')
        s['tipsX'], s['tipsY'] = tips_place(s['box'])
        # previews start where the slot's content starts; battery (placed per language) uses its leftmost place
        s['pox'] = min(s['xl'].values()) - bx if 'xl' in s else s['x'] - bx
        # edit-mode frames
        for name, col in (('sel', ORANGE), ('unsel', (110, 110, 110, 255))):
            c = Canvas(bw_, bh)
            c.rrect(1, 1, bw_ - 1, bh - 1, 7, outline=col, w=2)
            save(c.done(), f'edit/{s["id"]}_{name}.png')
        # previews: what the slot shows with each option (sample value), as wide as what is drawn. Named by
        # what is in them (preview_path), so slots and languages that show the same share one image.
        for o in opts:
            for li, lang in enumerate(LANGS):
                if not s['fit'].get(o['id'], 0) >> li & 1:
                    continue
                short = bool(s['short'].get(o['id'], 0) >> li & 1)
                ox = s['pox']
                rel = preview_path(s, o, lang, ox, short)
                if os.path.exists(os.path.join(OUT, rel)):
                    continue
                alias = LANGS[B36.index((o['sa'] if short else o['la'])[li])]
                lab = Image.open(os.path.join(OUT, f'label/{ls}/{alias}/{o["id"]}{"s" if short else ""}.png'))
                if o['icon']:
                    ly = (s['baseline'] - by_) - lab.height + 2
                else:
                    ly = (s['baseline'] - by_) - LABEL_STYLES[ls].base
                vx = ox + lab.width + (4 if o['icon'] else 6)
                sample = o['sample'].replace(',', '.') if lang == 'en' else o['sample']
                val = st.render(sample + {'deg': '°', 'pct': '%', 'hr': 'h', 'km': ' KM', 'hhmm': '', '': ''}[o['unit']])
                img = Image.new('RGBA', (min(bw_, vx + val.width + 1), bh), CLEAR)
                assert vx + val.width <= bw_ + 2, ('preview wider than its box', s['id'], o['id'], lang)
                img.alpha_composite(lab, (ox, max(0, ly)))
                img.alpha_composite(val, (vx, (s['baseline'] - by_) - st.base))
                save(img, rel)
    tips = Canvas(TIPS_W, 34)
    tips.rrect(0, 0, TIPS_W, 34, 17, fill=(40, 40, 44, 255))
    save(tips.done(), 'edit/tips.png')
    # transparent click areas
    for s in slots:
        save(Image.new('RGBA', (s['box'][2], s['box'][3]), CLEAR), f'click/{s["id"]}.png')
    save(Image.new('RGBA', (60, 74), CLEAR), 'click/weather.png')
    save(Image.new('RGBA', (GW, GH + 8), CLEAR), 'click/graph.png')
    save(Image.new('RGBA', (130, 40), CLEAR), 'click/alarm.png')
    save(Image.new('RGBA', (400, 100), CLEAR), 'click/time.png')
    return opts, slots


def build_graph_options():
    """Graph slot: HR (default) or sleep. Previews are small drawings of each."""
    import random
    random.seed(3)
    outs = []
    gw, gh = GW, GH
    for oid, kind in ((100101, 'hr'), (100102, 'sleep')):
        c = Canvas(gw, gh)
        if kind == 'hr':
            pts = []
            for i in range(0, 260, 3):
                y = gh - 10 - random.random() * 8 - (40 if 150 < i < 170 else 0) - (18 if 200 < i < 215 else 0)
                pts.append((i, y))
            c.poly(pts + [(pts[-1][0], gh), (0, gh)], (255, 122, 0, 70))
            c.line(pts, ORANGE, 2)
        else:
            for x, w, lvl in ((0, 70, 2), (70, 60, 3), (130, 90, 1), (220, 50, 3), (270, 80, 2), (350, 50, 1)):
                c.rrect(x + 2, 8 + lvl * 16, x + w - 2, gh - 1, 3, fill=(255, 122, 0, 110 + lvl * 40))
        prev = Image.new('RGBA', (gw + 8, gh + 8), CLEAR)  # same size as the edit box, graph at +4,+4
        prev.alpha_composite(c.done(), (4, 4))
        save(prev, f'preview/graph_{oid}.png')
        outs.append({'id': oid, 'kind': kind})
    for name, col in (('sel', ORANGE), ('unsel', (110, 110, 110, 255))):
        c = Canvas(gw + 8, gh + 8)
        c.rrect(1, 1, gw + 7, gh + 7, 8, outline=col, w=2)
        save(c.done(), f'edit/graph_{name}.png')
    return outs


# ---------------------------------------------------------------- always-on display (version A)

def polar(angle, r, side=0, c=240):
    a = math.radians(angle)
    ux, uy = math.sin(a), -math.cos(a)
    return (c + ux * r - uy * side, c + uy * r + ux * side)


def dim_files(rels, factor):
    """Multiplies the colour of these images (files or folders under OUT) by factor, alpha unchanged."""
    for rel in rels:
        path = os.path.join(OUT, rel)
        if os.path.isfile(path):
            files = [path]
        else:
            files = [os.path.join(dp, f) for dp, _, fs in os.walk(path) for f in sorted(fs)]
        for f in files:
            im = Image.open(f).convert('RGBA')
            r, g, b, a = im.split()
            r, g, b = (ch.point(lambda v: round(v * factor)) for ch in (r, g, b))
            Image.merge('RGBA', (r, g, b, a)).save(f, optimize=True)


def build_aod(main):
    L = {'layout': AOD_LAYOUT}
    ring = Canvas(W, W)

    def capsule(angle, r0, r1, width, col):
        p0, p1 = polar(angle, r0), polar(angle, r1)
        ring.line([p0, p1], col, width)
        for p in (p0, p1):
            ring.circle(p[0], p[1], width / 2, fill=col)

    for i in range(60):
        if i % 5 == 0:
            capsule(i * 6, 205, 228, 6.5 if i else 8, ORANGE if i == 0 else WHITE)
        elif AOD_TICKS == '60':
            capsule(i * 6, 221, 229, 3, (225, 225, 225, 255))
    save(ring.done(), 'aod/ring.png')

    # date block: day digits + weekday over month, centred by JS from the real widths
    L['day'] = A40.digit_set('aday', extras=False, tabular=False)
    L['week'] = {'h': N17.h, **word_set(N17, S.WEEKDAYS, 'aweek')}
    L['month'] = {'h': N17.h, **word_set(N17, S.MONTHS, 'amonth', color=ORANGE)}
    L['dateGap'] = 8

    for i in range(29):
        save(weather_icon(i).resize((40, 33), Image.LANCZOS), f'aweather/{i}.png')

    # distance: the value centred under the hands' pivot, as big as the temperature, with a small spaced-out
    # caption in the watch's language above it
    L['distCap'] = {lang: AC.save_text(S.LABELS[100007][lang][0], f'aod/cap/{lang}.png') for lang in LANGS}
    L['distW'] = 220  # box the value is centred in

    # where the info sits: baselines of temperature, date and distance value.
    # 'dodge' has a second arrangement (mirrored) that JS switches to when the hands cover the top.
    def arrangement(temp, date, dist):
        return {'iconY': temp - 30, 'tempY': temp - V25.base, 'hiY': temp - 9 - WX.base, 'loY': temp + 10 - WX.base,
                'upY': temp - 18, 'downY': temp + 1, 'dayY': date - A40.base,
                'weekY': date - 17 - N17.base, 'monthY': date - N17.base,
                'distCapY': dist - 30 - AC.base, 'distValueY': dist - V25.base}

    if AOD_LAYOUT == 'rim':
        L['sets'] = [arrangement(80, 120, 420)]
        hour_len, minute_len = 74, 112
    else:
        temp_top = {'top': 96, 'bottom': 432}[AOD_TEMP]
        L['sets'] = [arrangement(temp_top, 150, 400)]
        if AOD_LAYOUT == 'dodge':
            L['sets'].append(arrangement(414, 360, 110))
            L['dodgeAngle'] = 40  # a hand closer than this to 12 (or 6) covers the top (or bottom) block
        hour_len, minute_len = 122, 196
    if HILO:
        # icon, current temperature right-aligned, then today's max over min (as on the main screen);
        # the group is centred for a typical "6°" and "-18°" still clears the icon
        L['temp'] = {'iconX': 172, 'x': 162, 'w': 100, 'align': 'right', 'arrowX': 269, 'hiX': 281, 'hiW': 60}
    else:
        L['temp'] = {'iconX': 236 - 40, 'x': 242, 'w': 80, 'align': 'left'}

    # hands, drawn pointing up; rotation centre at (cx, cy) of each image.
    # With AOD_HALO the hand is filled black and gets a black border, so text under it is cut cleanly
    # instead of showing through (Zepp's always-on guideline asks for a black edge on the hands).
    halo = 3 if AOD_HALO else 0

    def hand_img(length, w0, w1, rel):
        pad = 6 + halo
        width = int(max(w0, w1) + pad * 2)
        height = int(length + 30 + pad)
        cx, cy = width / 2, length + pad
        c = Canvas(width, height)

        def P(r, side):
            return (cx + side, cy - r)
        body = [P(22, -w0 / 2), P(length - w1, -w1 / 2), P(length, 0), P(length - w1, w1 / 2), P(22, w0 / 2)]
        if halo:
            c.line([P(0, 0), P(24, 0)], BLACK, 3.6 + 2 * halo)
            c.circle(cx, cy, 1.8 + halo, fill=BLACK)
            c.poly(body, BLACK)
            c.line(body + [body[0], body[1]], BLACK, 2.6 + 2 * halo)
        c.line([P(0, 0), P(24, 0)], WHITE, 3.6)
        c.circle(cx, cy, 1.8, fill=WHITE)
        c.line(body + [body[0], body[1]], WHITE, 2.6)
        ins = [P(length * 0.62, -w1 / 2 + 3), P(length - w1, -w1 / 2 + 3), P(length - 4, 0), P(length - w1, w1 / 2 - 3),
               P(length * 0.62, w1 / 2 - 3)]
        c.poly(ins, ORANGE)
        save(c.done(), rel)
        return {'path': rel, 'posX': round(cx), 'posY': round(cy), 'w': width}

    L['hour'] = hand_img(hour_len, 13, 15, 'aod/hour.png')
    L['minute'] = hand_img(minute_len, 10, 12, 'aod/minute.png')
    cs = 20 + 2 * halo
    cov = Canvas(cs, cs)
    if halo:
        cov.circle(cs / 2, cs / 2, 8.5 + halo, fill=BLACK)
    cov.circle(cs / 2, cs / 2, 8.5, fill=ORANGE)
    cov.circle(cs / 2, cs / 2, 3.2, fill=BLACK)
    save(cov.done(), 'aod/cover.png')
    L['cover'] = {'path': 'aod/cover.png', 'x': 240 - cs // 2, 'y': 240 - cs // 2, 'w': cs}

    # digit sets and arrows shared with the main screen; dimmed, the always-on screen needs its own copies
    L['up'], L['down'] = 'icons/up.png', 'icons/down.png'
    for key in ('v25', 'wx'):
        if key in main:
            L[key] = main[key]
    if AOD_DIM < 1:
        own = ['aod', 'aday', 'aweek', 'amonth', 'aweather']
        for key in ('v25', 'wx'):
            if key in L:
                shutil.copytree(os.path.join(OUT, main[key]['dir']), os.path.join(OUT, 'a' + key))
                L[key] = {**main[key], 'dir': 'a' + key}
                own.append('a' + key)
        L['up'], L['down'] = 'aod/up.png', 'aod/down.png'
        shutil.copy(os.path.join(OUT, 'icons/up.png'), os.path.join(OUT, L['up']))
        shutil.copy(os.path.join(OUT, 'icons/down.png'), os.path.join(OUT, L['down']))
        dim_files(own, AOD_DIM)
    return L


# ---------------------------------------------------------------- edit-mode background, icon, cover

def build_edit_bg(main):
    """Dimmed static parts so the slots have context while editing: the day, and the time 10:08 with its
    seconds where the face puts them (the flag box sits under the seconds)."""
    img = Image.new('RGBA', (W, W), BLACK)
    dim = (90, 90, 90, 255)
    d = ImageDraw.Draw(img)
    xs, sec_x, _ = time_row(main, '10:08')
    for ch, x in zip('10:08', xs):
        d.text((x, 234), ch, font=T_BIG.f, fill=dim, anchor='ls')
    d.text((sec_x, 178), '36', font=T_SEC.f, fill=(60, 60, 60, 255), anchor='ls')
    d.text((158, 107), '13', font=D_DAY.f, fill=dim, anchor='rs')
    d.rectangle([56, 121, 424, 122], fill=(40, 40, 40, 255))
    save(img, 'edit/bg.png')


def lang_files(opts, graph_opts):
    """The words of edit mode for each language in assets lang/<lang>.bin (JSON as UTF-16LE, which the watch
    reads back with String.fromCharCode): titles of the choices and the flag list. Only the watch's language
    is read, so the face does not carry 24 copies; English is also kept in layout.js in case reading fails.
    Returns the English one."""
    out = {}
    for lang in LANGS:
        data = {'t': {o['id']: S.title(o['id'], lang) for o in opts},
                'g': {g['kind']: S.title(g['kind'], lang) for g in graph_opts},
                'nf': S.title('noflag', lang), 'fl': TEXTS['fl'][lang], 'fn': TEXTS['fn'][lang]}
        text = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
        path = os.path.join(OUT, 'lang', lang + '.bin')
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as fh:
            fh.write(text.encode('utf-16-le'))
        out[lang] = data
    return out['en']


def build_icon_and_cover(preview_png):
    """Icon and cover both show the face itself (render of the main screen at 10:09 from tools/build.sh).
    The cover is the watch face preview: 324 x 324 for a 480 screen (Zepp watch face specification)."""
    if os.path.exists(preview_png):
        face = Image.open(preview_png).convert('RGBA')
        save(face.resize((324, 324), Image.LANCZOS), 'cover.png')
        save(face.resize((248, 248), Image.LANCZOS), 'icon.png')
    else:  # first run, before build.sh has rendered the face
        ic = Canvas(248, 248)
        ic.circle(124, 124, 120, fill=BLACK)
        ic.circle(124, 124, 120, outline=ORANGE, w=8)
        save(ic.done(), 'icon.png')
        save(ic.done().resize((324, 324), Image.LANCZOS), 'cover.png')


def main():
    for d in (OUT, OUT_SQUARE):
        if os.path.isdir(d):
            shutil.rmtree(d)
    os.makedirs(OUT)
    m = build_main()
    opts, slots = build_slots(m)
    graph_opts = build_graph_options()
    flag = build_flags(m)
    aod = build_aod(m)
    build_edit_bg(m)
    english = lang_files(opts, graph_opts)
    build_icon_and_cover(os.path.join(ROOT, 'pregled', 'glavni.png'))
    layout.update({'langs': LANGS, 'zepp': S.ZEPP, 'en': english, 'tipsW': TIPS_W, 'main': m, 'options': opts, 'slots': slots,
                   'graphOptions': graph_opts, 'flag': flag, 'aod': aod,
                   'graphSlot': {'edit': 108, 'box': [GX - 4, GY - 4, GW + 8, GH + 8]}})
    layout['graphSlot']['tipsX'], layout['graphSlot']['tipsY'] = tips_place(layout['graphSlot']['box'])
    js = ('// Generated by tools/gen_assets.py. Do not edit by hand.\nexport const L = '
          + json.dumps(layout, separators=(',', ':'), ensure_ascii=False) + '\n')
    os.makedirs(os.path.join(ROOT, 'watchface'), exist_ok=True)
    with open(os.path.join(ROOT, 'watchface', 'layout.js'), 'w') as fh:
        fh.write(js)
    # square screens: the same images (the build scales them to the screen width like the round ones)
    shutil.copytree(OUT, OUT_SQUARE)
    n = sum(len(f) for _, _, f in os.walk(OUT))
    size = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(OUT) for f in fs)
    print(f'{n} images ({size // 1024} KB) per screen shape, layout.js {len(js) // 1024} KB')


if __name__ == '__main__':
    main()
