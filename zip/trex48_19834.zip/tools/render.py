"""Draws the widget dump from tools/sim.js the way the watch would, for checking the layout.

Usage: python3 tools/render.py dump.json out.png [--clicks] [--select <slot>] [--transparent]
"""
import json
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
ASSETS = os.path.join(ROOT, 'assets', 'common.r')
FONT = os.path.join(ROOT, 'fonts-src', 'SairaSemiCondensed-SemiBold.ttf')
FONT_ALT = os.path.join(ROOT, 'fonts-src', 'FiraSansCondensed-SemiBold.ttf')
_cache = {}
SCALE = [1.0]  # screen width / 480 of the render under way


def load(src):
    """An image as the watch gets it: the Zepp build shrinks every image to Math.floor(width * screen / 480)
    (sharp, cubic) and keeps its proportions."""
    k = SCALE[0]
    if (src, k) not in _cache:
        im = Image.open(os.path.join(ASSETS, src)).convert('RGBA')
        w = math.floor(im.width * k)
        if k != 1 and w > 0:
            im = im.resize((w, max(1, round(im.height * w / im.width))), Image.BICUBIC)
        _cache[(src, k)] = im
    return _cache[(src, k)]


def paste(canvas, src, x, y):
    im = load(src)
    canvas.alpha_composite(im, (int(x), int(y)))
    return im


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255, 255)


def fmt_value(v, key=None):
    if key in ('DISTANCE', 'MONTH_RUN_DISTANCE') and not isinstance(v, str):
        return '%.2f' % v
    if isinstance(v, str):
        return v
    if isinstance(v, float) and not v.is_integer():
        return ('%.2f' % v).rstrip('0').rstrip('.')
    return str(int(v))


def text_img(canvas, p, dump):
    key = dump['dataTypes'].get(str(p.get('type')))
    value = dump['sample'].get(key) if key else None
    if p.get('type') is None and 'text' in p:  # text set by our code
        value = p['text'] or None
        if value is None:
            return
    parts = []
    if value is None:
        parts.append(p['invalid_image'])
    else:
        text = fmt_value(value, key)
        if p.get('padding') and ':' in text:  # zero-padded hours (what padding: true should do on the watch)
            text = text.rjust(5, '0')
        for ch in text:
            if ch in '.:':
                parts.append(p['dot_image'])
            elif ch == '-':
                parts.append(p['negative_image'])
            else:
                parts.append(p['font_array'][int(ch)])
        if p.get('unit_en'):
            parts.append(p['unit_en'])
    widths = [load(s).width for s in parts]
    total = sum(widths) + p.get('h_space', 0) * (len(parts) - 1)
    x = p['x']
    align = p.get('align_h', 1)
    if align == 4:
        x = p['x'] + (p['w'] - total) // 2
    elif align == 2:
        x = p['x'] + p['w'] - total
    if total > p['w']:
        print('  ! TEXT_IMG %s at %d,%d is %dpx wide, box is %d' % (key, p['x'], p['y'], total, p['w']))
    for s, w in zip(parts, widths):
        paste(canvas, s, x, p['y'])
        x += w + p.get('h_space', 0)


def img_level(canvas, p, dump):
    key = dump['dataTypes'].get(str(p.get('type')))
    ratio = dump['sample'].get(key, 0) / dump['target'].get(key, 100)
    n = p['image_length']
    idx = max(0, min(n - 1, int(ratio * (n - 1))))
    paste(canvas, p['image_array'][idx], p['x'], p['y'])


def polyline(canvas, p, dump):
    kind = dump['dataTypes'].get(str(p.get('type')))
    x0, y0, w, h = p['x'], p['y'], p['w'], p['h']
    col = rgb(p['line_color'])
    if kind == 'HEART':
        # what the watch draws (approximation): today's HR scaled to the area, line + fading fill
        today = dump.get('heartToday', [])
        pts = []
        for px in range(w):
            seg = [v for v in today[int(px * 1440 / w):int((px + 1) * 1440 / w)] if 0 < v < 250]
            if seg:
                pts.append((px, sum(seg) / len(seg)))
        if len(pts) < 2:
            return
        lo, hi = min(v for _, v in pts), max(v for _, v in pts)
        xy = [(x0 + px, y0 + h - 2 - (v - lo) / max(1, hi - lo) * (h - 6)) for px, v in pts]
        fill = Image.new('RGBA', canvas.size, (0, 0, 0, 0))
        ImageDraw.Draw(fill).polygon(xy + [(xy[-1][0], y0 + h), (xy[0][0], y0 + h)], fill=col[:3] + (255,))
        grad = Image.new('L', canvas.size, 0)
        gd = ImageDraw.Draw(grad)
        for yy in range(y0, y0 + h):
            gd.line([(0, yy), (canvas.size[0], yy)], fill=int(150 - 110 * (yy - y0) / h))
        fill.putalpha(Image.composite(grad, Image.new('L', canvas.size, 0), fill.split()[3]))
        canvas.alpha_composite(fill)
        ImageDraw.Draw(canvas).line(xy, fill=col, width=p.get('line_width', 2))
        return
    d = ImageDraw.Draw(canvas)
    if kind == 'SLEEP':
        d.rectangle([x0, y0 + h // 2, x0 + w, y0 + h - 2], outline=col)
        return
    for line in p.get('_lines', []):  # drawn by our code: y counts from the top (as on the watch)
        pts = [(x0 + q['x'], y0 + q['y']) for q in line['data']]
        d.line(pts, fill=rgb(line.get('color_from', p['line_color'])), width=p.get('line_width', 2))


def hand(canvas, path, cx, cy, posx, posy, angle):
    im = load(path)
    big = Image.new('RGBA', (960, 960), (0, 0, 0, 0))
    big.alpha_composite(im, (480 - posx, 480 - posy))
    big = big.rotate(-angle, center=(480, 480), resample=Image.BICUBIC)
    canvas.alpha_composite(big, (cx - 480, cy - 480))


def time_pointer(canvas, p, t):
    h = (t['hour'] % 12 + t['minute'] / 60) * 30
    m = (t['minute'] + t['second'] / 60) * 6
    hand(canvas, p['hour_path'], p['hour_centerX'], p['hour_centerY'], p['hour_posX'], p['hour_posY'], h)
    hand(canvas, p['minute_path'], p['minute_centerX'], p['minute_centerY'], p['minute_posX'], p['minute_posY'], m)
    if p.get('minute_cover_path'):
        paste(canvas, p['minute_cover_path'], p['minute_cover_x'], p['minute_cover_y'])


def render(dump, out, clicks=False, select=None, transparent=False):
    scr = dump.get('screen', {'w': 480, 'h': 480, 'round': True})
    SW, SH = scr['w'], scr['h']
    SCALE[0] = SW / 480
    canvas = Image.new('RGBA', (SW, SH), (0, 0, 0, 255))
    level = dump['level']
    click_boxes = []
    groups = []
    for w in dump['widgets']:
        p = w['props']
        p['_lines'] = w.get('lines', [])
        t = w['type']
        if t == 'WATCHFACE_EDIT_GROUP':
            groups.append(p)
            continue
        if not (p.get('show_level', 1) & level) or p.get('visible') is False:
            continue
        if t == 'IMG_STATUS' and p.get('type') == 'clock' and not dump['sample'].get('ALARM_CLOCK'):
            continue
        if t == 'FILL_RECT':
            ImageDraw.Draw(canvas).rectangle([p['x'], p['y'], p['x'] + p['w'] - 1, p['y'] + p['h'] - 1], fill=rgb(p['color']))
        elif t in ('IMG', 'IMG_STATUS'):
            paste(canvas, p['src'], p['x'], p['y'])
        elif t == 'TEXT_IMG':
            text_img(canvas, p, dump)
        elif t == 'IMG_LEVEL':
            img_level(canvas, p, dump)
        elif t == 'IMG_TIME' and 'second_array' in p:  # seconds drawn by the watch, digits in fixed cells
            x = p['second_startX']
            for ch in '%02d' % dump['time']['second']:
                src = p['second_array'][int(ch)]
                paste(canvas, src, x, p['second_startY'])
                x += load(src).width + p.get('second_space', 0)
        elif t == 'GRADKIENT_POLYLINE':
            polyline(canvas, p, dump)
        elif t == 'TIME_POINTER':
            time_pointer(canvas, p, dump['time'])
        elif t == 'IMG_CLICK':
            click_boxes.append(p)
        else:
            print('  ? not drawn:', t)
    if level == 4:
        for g in groups:
            sel = select and g['select_image'].startswith('edit/' + select + '_')
            current = g.get('current_type', g['default_type'])
            preview = next((o['preview'] for o in g['optional_types'] if o['type'] == current), None)
            if preview:
                paste(canvas, preview, g['x'], g['y'])
            paste(canvas, g['select_image'] if sel else g['un_select_image'], g['x'], g['y'])
            if sel:
                tip = paste(canvas, g['tips_BG'], g['x'] + g['tips_x'], g['y'] + g['tips_y'])
                title = next((o['title_en'] for o in g['optional_types'] if o['type'] == current), '')
                alt = any(0x0370 <= ord(ch) <= 0x052F for ch in title)  # Greek, Cyrillic: the watch's own font has them
                f = ImageFont.truetype(FONT_ALT if alt else FONT, max(10, round(19 * SCALE[0])))
                ImageDraw.Draw(canvas).text((g['x'] + g['tips_x'] + tip.width / 2, g['y'] + g['tips_y'] + tip.height / 2),
                                            title, font=f, fill=(255, 255, 255, 255), anchor='mm')
    if clicks:
        d = ImageDraw.Draw(canvas)
        for c in click_boxes:
            d.rectangle([c['x'], c['y'], c['x'] + c['w'] - 1, c['y'] + c['h'] - 1], outline=(0, 200, 255, 255))
    # screen mask: round, or a square screen with rounded corners
    mask = Image.new('L', (SW, SH), 0)
    if scr['round']:
        ImageDraw.Draw(mask).ellipse([0, 0, SW - 1, SH - 1], fill=255)
    else:
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, SW - 1, SH - 1], radius=round(SW * 0.12), fill=255)
    if transparent:
        canvas.putalpha(mask)
        canvas.save(out)
        return
    bg = Image.new('RGBA', (SW, SH), (40, 40, 40, 255))
    bg.paste(canvas, (0, 0), mask)
    bg.convert('RGB').save(out)


if __name__ == '__main__':
    a = sys.argv[1:]
    sel = a[a.index('--select') + 1] if '--select' in a else None
    with open(a[0]) as f:
        render(json.load(f), a[1], clicks='--clicks' in a, select=sel, transparent='--transparent' in a)
