"""Puts renders side by side with a caption under each, for checking many screens at once.

Usage: python3 tools/sheet.py out.png <columns> "caption=path.png" ...
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
FONT = os.path.join(ROOT, 'fonts-src', 'SairaSemiCondensed-SemiBold.ttf')


def main(out, cols, items):
    cell, cap, pad = 480, 40, 16
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * (cell + pad) + pad, rows * (cell + cap + pad) + pad), (24, 24, 26))
    d = ImageDraw.Draw(sheet)
    f = ImageFont.truetype(FONT, 24)
    for i, item in enumerate(items):
        caption, path = item.split('=', 1)
        im = Image.open(path).convert('RGBA')
        x = pad + (i % cols) * (cell + pad)
        y = pad + (i // cols) * (cell + cap + pad)
        sheet.paste(im, (x + (cell - im.width) // 2, y + (cell - im.height) // 2), im)
        d.text((x + cell // 2, y + cell + cap // 2 + 2), caption, font=f, fill=(200, 200, 200), anchor='mm')
    sheet.save(out)


if __name__ == '__main__':
    main(sys.argv[1], int(sys.argv[2]), sys.argv[3:])
