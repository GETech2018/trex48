// Runs watchface/index.js against mocked Zepp OS API 1.0 globals and dumps the widget tree
// as JSON for tools/render.py. Usage: node tools/sim.js <mode> [out.json] [key=value ...]
//   mode: normal | aod | edit
//   keys: hour, minute, second, day, month, week, timefmt (0 = 12h), weather, worst=1, battery, stress, bio,
//         biosensor=1, noalarm=1, maxhr (caps the day's heart rate), restart=<minute of a watch restart>,
//         any SAMPLE key in capitals (STEP=1947),
//         choose=<slot>:<id>, flag=<code> (rs, gb-sct...), lang=<en|sr|es|it|de|fr|pt or Zepp number>,
//         width=<px> height=<px> square=1 (screen; default 480 x 480 round)
const fs = require('fs')
const path = require('path')
const vm = require('vm')

const root = path.join(__dirname, '..')
const mode = process.argv[2] || 'normal'
const out = process.argv[3] || '-'
const args = {}
process.argv.slice(4).forEach((a) => {
  const [k, v] = a.split('=')
  if (k === 'choose') {
    const [slot, id] = v.split(':')
    args.choose = args.choose || {}
    args.choose[slot] = Number(id)
  } else if (k === 'flag' || k === 'lang') args[k] = v
  else args[k] = Number(v)
})

const DATA_KEYS = [
  'BATTERY', 'STEP', 'STEP_TARGET', 'CAL', 'CAL_TARGET', 'HEART', 'PAI_DAILY', 'PAI_WEEKLY', 'DISTANCE',
  'STAND', 'STAND_TARGET', 'WEATHER_CURRENT', 'WEATHER_LOW', 'WEATHER_HIGH', 'UVI', 'AQI', 'HUMIDITY',
  'ACTIVITY', 'FAT_BURNING', 'SPO2', 'STRESS', 'BODY_TEMP', 'FLOOR', 'ALARM_CLOCK', 'SLEEP', 'READINESS',
  'RECOVERY_TIME', 'TRAINING_LOAD', 'VO2MAX', 'BIO_CHARGE', 'SUN_RISE', 'SUN_SET', 'MOON', 'WIND',
  'MONTH_RUN_DISTANCE', 'COUNT_DOWN', 'STOP_WATCH'
]
const data_type = {}
DATA_KEYS.forEach((k, i) => (data_type[k] = i + 1))

// sample readings used to draw TEXT_IMG and IMG_LEVEL in the render
const SAMPLE = {
  BATTERY: 45, STEP: 3829, HEART: 63, DISTANCE: 3.05, STRESS: 28, WEATHER_CURRENT: 6, BIO_CHARGE: 72,
  BODY_TEMP: 36.5, CAL: 412, SPO2: 97, PAI_WEEKLY: 86, READINESS: 74, RECOVERY_TIME: 18, FLOOR: 6,
  HUMIDITY: 64, UVI: 2, STAND: 7, VO2MAX: 48, TRAINING_LOAD: 312, SUN_SET: '18:12', WEATHER_HIGH: 12,
  WEATHER_LOW: 3, MONTH_RUN_DISTANCE: 86.42
}
const TARGET = { STEP: 8000, BATTERY: 100 }

const widgets = []
let nextId = 1
const props = (o) => JSON.parse(JSON.stringify(o, (k, v) => (typeof v === 'function' ? undefined : v)))

const widgetNames = [
  'IMG', 'TEXT', 'TEXT_IMG', 'FILL_RECT', 'STROKE_RECT', 'ARC', 'ARC_PROGRESS', 'CIRCLE', 'IMG_TIME', 'IMG_DATE',
  'IMG_WEEK', 'IMG_LEVEL', 'IMG_STATUS', 'IMG_CLICK', 'IMG_POINTER', 'TIME_POINTER', 'DATE_POINTER',
  'GRADKIENT_POLYLINE', 'WATCHFACE_EDIT_GROUP', 'WIDGET_DELEGATE', 'IMG_PROGRESS', 'IMG_ANIM', 'BUTTON', 'GROUP'
]
const widget = {}
widgetNames.forEach((n) => (widget[n] = n))
const prop = { SRC: 'src', X: 'x', Y: 'y', W: 'w', H: 'h', TEXT: 'text', LEVEL: 'level', CURRENT_TYPE: 'current_type', MORE: 'more', VISIBLE: 'visible' }

const hmUI = {
  widget,
  prop,
  data_type,
  show_level: { ONLY_NORMAL: 1, ONAL_AOD: 2, ONLY_EDIT: 4 },
  align: { LEFT: 1, RIGHT: 2, CENTER_H: 4, TOP: 8, BOTTOM: 16, CENTER_V: 32 },
  system_status: { CLOCK: 'clock', DISCONNECT: 'disconnect', DISTURB: 'disturb', LOCK: 'lock' },
  createWidget(type, p) {
    if (!widget[type]) throw new Error('unknown widget ' + type)
    const w = { id: nextId++, type, props: props(p || {}), lines: [] }
    if (type === 'WIDGET_DELEGATE') w.delegate = p
    widgets.push(w)
    return {
      _w: w,
      setProperty(k, v) {
        if (!k) throw new Error('setProperty with undefined prop on ' + type)
        w.props[k] = v
      },
      getProperty(k) {
        if (k === 'current_type') {
          const slot = Object.keys(EDIT_IDS).find((s) => EDIT_IDS[s] === w.props.edit_id)
          const t = args.choose && slot && args.choose[slot] ? args.choose[slot] : w.props.default_type
          w.props.current_type = t // for the render
          return t
        }
        return w.props[k]
      },
      clear() {
        w.lines = []
      },
      addLine(l) {
        w.lines.push(props(l))
      }
    }
  }
}

hmUI.deleteWidget = (o) => {
  const i = widgets.indexOf(o && o._w)
  if (i < 0) throw new Error('deleteWidget on a widget that does not exist')
  widgets.splice(i, 1)
}

const EDIT_IDS = {}
const layoutSrc = fs.readFileSync(path.join(root, 'watchface/layout.js'), 'utf8').replace('export const L', 'var L')
const L = new Function(layoutSrc + '\nreturn L')()
L.slots.forEach((s) => (EDIT_IDS[s.id] = s.edit))
EDIT_IDS.graph = L.graphSlot.edit
EDIT_IDS.flag = L.flag.edit
if (args.flag) {
  if (!fs.existsSync(path.join(root, 'assets/common.r/flags', args.flag + '.png'))) throw new Error('no flag ' + args.flag)
  const id = args.flag.length === 2
    ? 110000 + (args.flag.charCodeAt(0) - 97) * 26 + (args.flag.charCodeAt(1) - 97)
    : 111000 + L.flag.extra.indexOf(args.flag)
  args.choose = { ...(args.choose || {}), flag: id }
}
const ZEPP_OF = Object.fromEntries(Object.entries(L.zepp).map(([n, l]) => [l, Number(n)]))
const langNumber = args.lang === undefined ? 2 : /^\d+$/.test(args.lang) ? Number(args.lang) : ZEPP_OF[args.lang]
if (langNumber === undefined) throw new Error('no language ' + args.lang)
const screen = { w: args.width || 480, h: args.height || args.width || 480, round: !args.square }

// worst=1: draw the widest realistic value of every option instead of the sample
if (args.worst) {
  L.options.forEach((o) => {
    o.keys.forEach((k) => {
      if (k in SAMPLE) SAMPLE[k] = o.worst.includes(':') ? o.worst : Number(o.worst.replace(',', '.'))
    })
  })
}

if (args.battery !== undefined) SAMPLE.BATTERY = args.battery
if (args.stress !== undefined) SAMPLE.STRESS = args.stress
// any sample can be set as KEY=value, e.g. STEP=1947 WEATHER_HIGH=16
Object.keys(args).forEach((k) => {
  if (k in SAMPLE && k === k.toUpperCase()) SAMPLE[k] = args[k]
})
if (args.bio !== undefined) SAMPLE.BIO_CHARGE = args.bio
SAMPLE.ALARM_CLOCK = args.noalarm ? null : '6:30' // as the watch reports it, without the leading zero

const now = {
  hour: args.hour ?? 16,
  minute: args.minute ?? 6,
  second: args.second ?? 54,
  day: args.day ?? 13,
  month: args.month ?? 10,
  week: args.week ?? 2
}
const listeners = []
const sensors = {
  TIME: () => ({
    ...now,
    year: 2026,
    event: { MINUTEEND: 'minuteEnd' },
    addEventListener(e, f) {
      listeners.push(f)
    },
    removeEventListener() {}
  }),
  WEATHER: () => ({ curAirIconIndex: args.weather ?? 3 }),
  BATTERY: () => ({ current: SAMPLE.BATTERY }),
  STRESS: () => ({ current: SAMPLE.STRESS }),
  HEART: () => {
    // a plausible day: low and calm at night, noisy during the day, a run at 7:15 and a walk at noon
    let seed = 7
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647)
    const today = []
    const mins = now.hour * 60 + now.minute
    let drift = 0
    for (let i = 0; i < mins; i++) {
      const h = i / 60
      drift = drift * 0.9 + (rnd() - 0.5) * 6
      let v = h < 6.5 ? 52 + drift * 0.4 : 70 + drift + rnd() * 10 + (rnd() < 0.03 ? 25 * rnd() : 0)
      if (h > 7.2 && h < 8) v += 45 + 30 * Math.abs(Math.sin(i / 3)) + rnd() * 20
      if (h > 12 && h < 12.5) v += 25 + rnd() * 20
      if (h > 14.6 && h < 14.75) v += 40 + rnd() * 15
      today.push(i % 97 === 5 ? 0 : Math.min(args.maxhr ?? 250, Math.round(v)))
    }
    // restart=<minute>: the watch was restarted then and only keeps readings from that minute on
    return { current: 63, last: 63, today: args.restart ? today.slice(args.restart) : today }
  }
}
// HybridCharge has no documented sensor; biosensor=1 pretends the firmware has one
if (args.biosensor) sensors.BIO_CHARGE = () => ({ current: SAMPLE.BIO_CHARGE })
const hmSensor = {
  id: Object.fromEntries(Object.keys(sensors).map((k) => [k, k])),
  createSensor(id) {
    if (!sensors[id]) throw new Error('unknown sensor ' + id)
    return sensors[id]()
  }
}
const hmSetting = {
  screen_type: { WATCHFACE: 1, AOD: 2, SETTINGS: 4 },
  getScreenType: () => (mode === 'aod' ? 2 : mode === 'edit' ? 4 : 1),
  getTimeFormat: () => args.timefmt ?? 1,
  getLanguage: () => langNumber,
  getDeviceInfo: () => ({ width: screen.w, height: screen.h, screenShape: screen.round ? 1 : 0, keyNumber: 2 })
}
// assets read by the face (lang/<lang>.bin), from assets/common.r
const files = []
const hmFS = {
  O_RDONLY: 0,
  stat_asset(p) {
    const f = path.join(root, 'assets/common.r', p)
    if (!fs.existsSync(f)) return [null, -1]
    return [{ size: fs.statSync(f).size, mtime: 0 }, 0]
  },
  open_asset(p) {
    files.push(fs.readFileSync(path.join(root, 'assets/common.r', p)))
    return files.length - 1
  },
  read(fd, buf, pos, len) {
    new Uint8Array(buf, pos, len).set(files[fd].subarray(0, len))
    return [[], 0]
  },
  close() {
    return 0
  }
}
const timers = []
const timer = {
  createTimer(delay, period, cb) {
    timers.push(cb)
    return timers.length
  },
  stopTimer() {}
}

let face = null
const sandbox = {
  hmUI,
  hmSensor,
  hmSetting,
  hmFS,
  timer,
  console,
  Math,
  JSON,
  WatchFace(o) {
    face = o
  }
}
vm.createContext(sandbox)
const indexSrc = fs
  .readFileSync(path.join(root, 'watchface/index.js'), 'utf8')
  .replace(/^import \{ L \} from '\.\/layout'\s*$/m, '')
vm.runInContext(layoutSrc + '\n' + indexSrc, sandbox, { filename: 'watchface/index.js' })
if (!face) throw new Error('WatchFace() was not called')

face.build()
const delegate = widgets.find((w) => w.type === 'WIDGET_DELEGATE')
if (delegate) delegate.delegate.resume_call()
// one seconds tick and one minute tick must not throw
timers.forEach((t) => t())
listeners.forEach((f) => f())

const level = { normal: 1, aod: 2, edit: 4 }[mode]
const dump = {
  mode,
  screen,
  heartToday: sensors.HEART().today,
  level,
  sample: SAMPLE,
  target: TARGET,
  dataTypes: Object.fromEntries(Object.entries(data_type).map(([k, v]) => [v, k])),
  time: now,
  widgets: widgets
    .filter((w) => w.type !== 'WIDGET_DELEGATE')
    .map((w) => ({ id: w.id, type: w.type, props: w.props, lines: w.lines }))
}
const json = JSON.stringify(dump, null, 1)
if (out === '-') process.stdout.write(json)
else fs.writeFileSync(out, json)
console.error(mode + ': ' + dump.widgets.length + ' widgets')
