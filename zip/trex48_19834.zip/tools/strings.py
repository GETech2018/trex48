"""Every word the face shows, in its 24 languages: every language of the watch's language list that uses the
Latin, Cyrillic or Greek alphabet.

The face picks the watch's language (hmSetting.getLanguage(), ZEPP below); a language it does not have
(Chinese, Japanese, Korean, Thai, Arabic, Hebrew) shows English. Words drawn on the face are capitals;
titles are what edit mode shows in its tip. Tables are "lang: long / short" (labels) or "lang: text".
"""

LANGS = ['en', 'sr', 'es', 'it', 'de', 'fr', 'pt', 'pl', 'cs', 'tr', 'hu', 'sv', 'ro', 'nl', 'ca', 'id', 'nb', 'ms',
         'da', 'fi', 'vi', 'ru', 'uk', 'el']

# hmSetting.getLanguage() -> language (Zepp docs, "Multilingual Mapping"; 24 is Serbian Latin)
ZEPP = {2: 'en', 3: 'es', 4: 'ru', 6: 'fr', 7: 'de', 8: 'id', 9: 'pl', 10: 'it', 14: 'vi', 15: 'pt', 16: 'nl',
        17: 'tr', 18: 'uk', 20: 'pt', 21: 'ro', 22: 'cs', 23: 'el', 24: 'sr', 25: 'ca', 26: 'fi', 27: 'nb',
        28: 'da', 29: 'sv', 30: 'hu', 31: 'ms'}


def _rows(text):
    out = {}
    for line in text.strip().splitlines():
        lang, rest = line.split(':', 1)
        out[lang.strip()] = rest.strip()
    missing = [lang for lang in LANGS if lang not in out]
    assert not missing, ('missing languages', missing, text[:40])
    return out


def _list(text):
    return {lang: [w.strip() for w in v.split(',')] for lang, v in _rows(text).items()}


def _labels(text):
    return {lang: tuple(p.strip() for p in v.split('/')) if '/' in v else (v, v) for lang, v in _rows(text).items()}


WEEKDAYS = _list('''
en: MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
sr: PONEDELJAK, UTORAK, SREDA, ČETVRTAK, PETAK, SUBOTA, NEDELJA
es: LUNES, MARTES, MIÉRCOLES, JUEVES, VIERNES, SÁBADO, DOMINGO
it: LUNEDÌ, MARTEDÌ, MERCOLEDÌ, GIOVEDÌ, VENERDÌ, SABATO, DOMENICA
de: MONTAG, DIENSTAG, MITTWOCH, DONNERSTAG, FREITAG, SAMSTAG, SONNTAG
fr: LUNDI, MARDI, MERCREDI, JEUDI, VENDREDI, SAMEDI, DIMANCHE
pt: SEGUNDA, TERÇA, QUARTA, QUINTA, SEXTA, SÁBADO, DOMINGO
pl: PONIEDZIAŁEK, WTOREK, ŚRODA, CZWARTEK, PIĄTEK, SOBOTA, NIEDZIELA
cs: PONDĚLÍ, ÚTERÝ, STŘEDA, ČTVRTEK, PÁTEK, SOBOTA, NEDĚLE
tr: PAZARTESİ, SALI, ÇARŞAMBA, PERŞEMBE, CUMA, CUMARTESİ, PAZAR
hu: HÉTFŐ, KEDD, SZERDA, CSÜTÖRTÖK, PÉNTEK, SZOMBAT, VASÁRNAP
sv: MÅNDAG, TISDAG, ONSDAG, TORSDAG, FREDAG, LÖRDAG, SÖNDAG
ro: LUNI, MARȚI, MIERCURI, JOI, VINERI, SÂMBĂTĂ, DUMINICĂ
nl: MAANDAG, DINSDAG, WOENSDAG, DONDERDAG, VRIJDAG, ZATERDAG, ZONDAG
ca: DILLUNS, DIMARTS, DIMECRES, DIJOUS, DIVENDRES, DISSABTE, DIUMENGE
id: SENIN, SELASA, RABU, KAMIS, JUMAT, SABTU, MINGGU
nb: MANDAG, TIRSDAG, ONSDAG, TORSDAG, FREDAG, LØRDAG, SØNDAG
ms: ISNIN, SELASA, RABU, KHAMIS, JUMAAT, SABTU, AHAD
da: MANDAG, TIRSDAG, ONSDAG, TORSDAG, FREDAG, LØRDAG, SØNDAG
fi: MAANANTAI, TIISTAI, KESKIVIIKKO, TORSTAI, PERJANTAI, LAUANTAI, SUNNUNTAI
vi: THỨ HAI, THỨ BA, THỨ TƯ, THỨ NĂM, THỨ SÁU, THỨ BẢY, CHỦ NHẬT
ru: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ
uk: ПОНЕДІЛОК, ВІВТОРОК, СЕРЕДА, ЧЕТВЕР, П’ЯТНИЦЯ, СУБОТА, НЕДІЛЯ
el: ΔΕΥΤΕΡΑ, ΤΡΙΤΗ, ΤΕΤΑΡΤΗ, ΠΕΜΠΤΗ, ΠΑΡΑΣΚΕΥΗ, ΣΑΒΒΑΤΟ, ΚΥΡΙΑΚΗ
''')

MONTHS = _list('''
en: JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC
sr: JAN, FEB, MAR, APR, MAJ, JUN, JUL, AVG, SEP, OKT, NOV, DEC
es: ENE, FEB, MAR, ABR, MAY, JUN, JUL, AGO, SEP, OCT, NOV, DIC
it: GEN, FEB, MAR, APR, MAG, GIU, LUG, AGO, SET, OTT, NOV, DIC
de: JAN, FEB, MÄR, APR, MAI, JUN, JUL, AUG, SEP, OKT, NOV, DEZ
fr: JANV, FÉVR, MARS, AVR, MAI, JUIN, JUIL, AOÛT, SEPT, OCT, NOV, DÉC
pt: JAN, FEV, MAR, ABR, MAI, JUN, JUL, AGO, SET, OUT, NOV, DEZ
pl: STY, LUT, MAR, KWI, MAJ, CZE, LIP, SIE, WRZ, PAŹ, LIS, GRU
cs: LED, ÚNO, BŘE, DUB, KVĚ, ČVN, ČVC, SRP, ZÁŘ, ŘÍJ, LIS, PRO
tr: OCA, ŞUB, MAR, NİS, MAY, HAZ, TEM, AĞU, EYL, EKİ, KAS, ARA
hu: JAN, FEB, MÁR, ÁPR, MÁJ, JÚN, JÚL, AUG, SZEP, OKT, NOV, DEC
sv: JAN, FEB, MAR, APR, MAJ, JUN, JUL, AUG, SEP, OKT, NOV, DEC
ro: IAN, FEB, MAR, APR, MAI, IUN, IUL, AUG, SEP, OCT, NOV, DEC
nl: JAN, FEB, MRT, APR, MEI, JUN, JUL, AUG, SEP, OKT, NOV, DEC
ca: GEN, FEB, MARÇ, ABR, MAIG, JUNY, JUL, AG, SET, OCT, NOV, DES
id: JAN, FEB, MAR, APR, MEI, JUN, JUL, AGU, SEP, OKT, NOV, DES
nb: JAN, FEB, MAR, APR, MAI, JUN, JUL, AUG, SEP, OKT, NOV, DES
ms: JAN, FEB, MAC, APR, MEI, JUN, JUL, OGO, SEP, OKT, NOV, DIS
da: JAN, FEB, MAR, APR, MAJ, JUN, JUL, AUG, SEP, OKT, NOV, DEC
fi: TAMMI, HELMI, MAALIS, HUHTI, TOUKO, KESÄ, HEINÄ, ELO, SYYS, LOKA, MARRAS, JOULU
vi: TH1, TH2, TH3, TH4, TH5, TH6, TH7, TH8, TH9, TH10, TH11, TH12
ru: ЯНВ, ФЕВ, МАР, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК
uk: СІЧ, ЛЮТ, БЕР, КВІ, ТРА, ЧЕР, ЛИП, СЕР, ВЕР, ЖОВ, ЛИС, ГРУ
el: ΙΑΝ, ΦΕΒ, ΜΑΡ, ΑΠΡ, ΜΑΪ, ΙΟΥΝ, ΙΟΥΛ, ΑΥΓ, ΣΕΠ, ΟΚΤ, ΝΟΕ, ΔΕΚ
''')


def SAME(long, short=None, **other):
    """The same label in every language, except the languages given (lang=(long, short))."""
    out = {lang: (long, short or long) for lang in LANGS}
    out.update(other)
    return out


# field label on the face; '#heart' and '#feet' are icons. A slot shows the long label when the value still
# fits, else the short one.
LABELS = {
    100001: SAME('#heart'),
    100002: _labels('''
en: STRESS
sr: STRES
es: ESTRÉS
it: STRESS
de: STRESS
fr: STRESS
pt: STRESS
pl: STRES
cs: STRES
tr: STRES
hu: STRESSZ / STRESS
sv: STRESS
ro: STRES
nl: STRESS
ca: ESTRÈS
id: STRES
nb: STRESS
ms: TEKANAN / TEKAN
da: STRESS
fi: STRESSI / STRESS
vi: CĂNG THẲNG / STRESS
ru: СТРЕСС
uk: СТРЕС
el: ΑΓΧΟΣ
'''),
    100003: SAME('TEMP', ru=('ТЕМП', 'ТЕМП'), uk=('ТЕМП', 'ТЕМП'), el=('ΘΕΡΜ', 'ΘΕΡΜ')),
    100004: SAME('HybridCharge', 'HC'),
    100005: _labels('''
en: BODY
sr: TELO
es: CUERPO / CUER
it: CORPO / CORP
de: KÖRPER / KÖRP
fr: CORPS / CORP
pt: CORPO / CORP
pl: CIAŁO
cs: TĚLO
tr: VÜCUT
hu: TEST
sv: KROPP
ro: CORP
nl: LICHAAM / LICH
ca: COS
id: TUBUH
nb: KROPP
ms: BADAN
da: KROP
fi: KEHO
vi: CƠ THỂ / THÂN
ru: ТЕЛО
uk: ТІЛО
el: ΣΩΜΑ
'''),
    100006: SAME('#feet'),
    100007: _labels('''
en: DISTANCE / DIST
sr: DISTANCA / DIST
es: DISTANCIA / DIST
it: DISTANZA / DIST
de: DISTANZ / DIST
fr: DISTANCE / DIST
pt: DISTÂNCIA / DIST
pl: DYSTANS / DYST
cs: VZDÁLENOST / VZD
tr: MESAFE / MES
hu: TÁVOLSÁG / TÁV
sv: DISTANS / DIST
ro: DISTANȚĂ / DIST
nl: AFSTAND / AFST
ca: DISTÀNCIA / DIST
id: JARAK
nb: DISTANSE / DIST
ms: JARAK
da: DISTANCE / DIST
fi: MATKA
vi: QUÃNG ĐƯỜNG / Q.ĐƯỜNG
ru: ДИСТАНЦИЯ / ДИСТ
uk: ДИСТАНЦІЯ / ДИСТ
el: ΑΠΟΣΤΑΣΗ / ΑΠΟΣΤ
'''),
    100008: _labels('''
en: BATTERY / BAT
sr: BATERIJA / BAT
es: BATERÍA / BAT
it: BATTERIA / BAT
de: AKKU
fr: BATTERIE / BAT
pt: BATERIA / BAT
pl: BATERIA / BAT
cs: BATERIE / BAT
tr: PİL
hu: AKKU
sv: BATTERI / BATT
ro: BATERIE / BAT
nl: BATTERIJ / BATT
ca: BATERIA / BAT
id: BATERAI / BAT
nb: BATTERI / BATT
ms: BATERI / BAT
da: BATTERI / BATT
fi: AKKU
vi: PIN
ru: БАТАРЕЯ / БАТ
uk: БАТАРЕЯ / БАТ
el: ΜΠΑΤΑΡΙΑ / ΜΠΑΤ
'''),
    100009: SAME('KCAL'),
    100010: SAME('SPO2'),
    100011: SAME('PAI'),
    100012: _labels('''
en: READINESS / READY
sr: SPREMNOST / SPREM
es: PREPARACIÓN / PREP
it: PRONTEZZA / PRONT
de: BEREITSCHAFT / BEREIT
fr: DISPONIBILITÉ / DISPO
pt: PRONTIDÃO / PRONT
pl: GOTOWOŚĆ / GOTOW
cs: PŘIPRAVENOST / PŘIPR
tr: HAZIRLIK / HAZIR
hu: FELKÉSZÜLTSÉG / FELK
sv: BEREDSKAP / BERED
ro: PREGĂTIRE / PREG
nl: PARAATHEID / PARAT
ca: PREPARACIÓ / PREP
id: KESIAPAN / SIAP
nb: BEREDSKAP / BERED
ms: KESEDIAAN / SEDIA
da: PARATHED / PARAT
fi: VALMIUS / VALM
vi: SẴN SÀNG / SẴN
ru: ГОТОВНОСТЬ / ГОТОВ
uk: ГОТОВНІСТЬ / ГОТОВ
el: ΕΤΟΙΜΟΤΗΤΑ / ΕΤΟΙΜ
'''),
    100013: _labels('''
en: RECOVERY / RECOV
sr: OPORAVAK / OPOR
es: RECUPERACIÓN / RECUP
it: RECUPERO / RECUP
de: ERHOLUNG / ERHOL
fr: RÉCUPÉRATION / RÉCUP
pt: RECUPERAÇÃO / RECUP
pl: REGENERACJA / REGEN
cs: ZOTAVENÍ / ZOTAV
tr: TOPARLANMA / TOPAR
hu: REGENERÁCIÓ / REGEN
sv: ÅTERHÄMTNING / ÅTERH
ro: RECUPERARE / RECUP
nl: HERSTEL / HERST
ca: RECUPERACIÓ / RECUP
id: PEMULIHAN / PULIH
nb: RESTITUSJON / REST
ms: PEMULIHAN / PULIH
da: RESTITUTION / REST
fi: PALAUTUMINEN / PALAUT
vi: PHỤC HỒI / PHỤC
ru: ВОССТАНОВЛЕНИЕ / ВОССТ
uk: ВІДНОВЛЕННЯ / ВІДН
el: ΑΠΟΚΑΤΑΣΤΑΣΗ / ΑΠΟΚ
'''),
    100014: _labels('''
en: FLOORS / FLRS
sr: SPRATOVI / SPRAT
es: PISOS
it: PIANI
de: ETAGEN / ETAG
fr: ÉTAGES / ÉTAG
pt: ANDARES / AND
pl: PIĘTRA / PIĘTR
cs: PATRA
tr: KAT
hu: EMELET / EMEL
sv: VÅNINGAR / VÅN
ro: ETAJE
nl: VERDIEPINGEN / VERD
ca: PISOS
id: LANTAI
nb: ETASJER / ETG
ms: TINGKAT / TKT
da: ETAGER / ETG
fi: KERROKSET / KERR
vi: TẦNG
ru: ЭТАЖИ / ЭТАЖ
uk: ПОВЕРХИ / ПОВ
el: ΟΡΟΦΟΙ / ΟΡΟΦ
'''),
    100015: _labels('''
en: HUMIDITY / HUM
sr: VLAGA
es: HUMEDAD / HUM
it: UMIDITÀ / UMID
de: FEUCHTE / FEUCHT
fr: HUMIDITÉ / HUM
pt: UMIDADE / UMID
pl: WILGOTNOŚĆ / WILG
cs: VLHKOST / VLHK
tr: NEM
hu: PÁRATARTALOM / PÁRA
sv: LUFTFUKTIGHET / FUKT
ro: UMIDITATE / UMID
nl: VOCHTIGHEID / VOCHT
ca: HUMITAT / HUM
id: KELEMBAPAN / LEMBAP
nb: FUKTIGHET / FUKT
ms: KELEMBAPAN / LEMBAP
da: FUGTIGHED / FUGT
fi: KOSTEUS / KOST
vi: ĐỘ ẨM
ru: ВЛАЖНОСТЬ / ВЛАЖН
uk: ВОЛОГІСТЬ / ВОЛОГ
el: ΥΓΡΑΣΙΑ / ΥΓΡ
'''),
    100016: SAME('UV'),
    100017: _labels('''
en: STAND
sr: STAJANJE / STAJ
es: DE PIE / PIE
it: IN PIEDI / PIEDI
de: STEHEN / STEH
fr: DEBOUT / DEB
pt: EM PÉ / PÉ
pl: STANIE / STAN
cs: STÁNÍ
tr: AYAKTA / AYAK
hu: ÁLLÁS
sv: STÅ
ro: ÎN PICIOARE / PIC
nl: STAAN
ca: DE PEU / PEU
id: BERDIRI / DIRI
nb: STÅ
ms: BERDIRI / DIRI
da: STÅ
fi: SEISOMINEN / SEIS
vi: ĐỨNG
ru: СТОЯНИЕ / СТОЯ
uk: СТОЯННЯ / СТОЯ
el: ΟΡΘΙΟΣ / ΟΡΘ
'''),
    100018: SAME('VO2MAX', 'VO2'),
    100019: _labels('''
en: LOAD
sr: OPTEREĆENJE / OPT
es: CARGA
it: CARICO
de: BELASTUNG / BELAST
fr: CHARGE
pt: CARGA
pl: OBCIĄŻENIE / OBC
cs: ZÁTĚŽ
tr: YÜK
hu: TERHELÉS / TERH
sv: BELASTNING / BEL
ro: SARCINĂ / SARC
nl: BELASTING / BEL
ca: CÀRREGA / CÀRR
id: BEBAN
nb: BELASTNING / BEL
ms: BEBAN
da: BELASTNING / BEL
fi: KUORMA
vi: TẢI
ru: НАГРУЗКА / НАГР
uk: НАВАНТАЖЕННЯ / НАВАНТ
el: ΦΟΡΤΙΟ / ΦΟΡΤ
'''),
    100020: _labels('''
en: SUNSET / SET
sr: ZALAZAK / ZAL
es: OCASO
it: TRAMONTO / TRAM
de: UNTERGANG / UNTERG
fr: COUCHER / COUCH
pt: PÔR DO SOL / PÔR
pl: ZACHÓD / ZACH
cs: ZÁPAD
tr: GÜN BATIMI / BATIM
hu: NAPNYUGTA / NYUG
sv: SOLNEDGÅNG / SOLN
ro: APUS
nl: ZONSONDERGANG / ZONS
ca: POSTA DE SOL / POSTA
id: TERBENAM / BENAM
nb: SOLNEDGANG / SOLN
ms: TERBENAM / BENAM
da: SOLNEDGANG / SOLN
fi: AURINGONLASKU / LASKU
vi: HOÀNG HÔN / H.HÔN
ru: ЗАКАТ
uk: ЗАХІД
el: ΔΥΣΗ
'''),
    100021: SAME('MAX'),
    100022: SAME('MIN'),
    100023: _labels('''
en: MONTH / MON
sr: MESEČNO / MES
es: MES
it: MESE
de: MONAT / MON
fr: MOIS
pt: MÊS
pl: MIESIĄC / MIES
cs: MĚSÍC / MĚS
tr: AY
hu: HÓNAP / HÓ
sv: MÅNAD / MÅN
ro: LUNĂ
nl: MAAND / MND
ca: MES
id: BULAN / BLN
nb: MÅNED / MND
ms: BULAN / BLN
da: MÅNED / MD
fi: KUUKAUSI / KK
vi: THÁNG
ru: МЕСЯЦ / МЕС
uk: МІСЯЦЬ / МІС
el: ΜΗΝΑΣ / ΜΗΝ
'''),
}

# what edit mode calls each choice
TITLES = {
    100001: _rows('''
en: Heart rate
sr: Puls
es: Pulso
it: Battito
de: Puls
fr: Pouls
pt: Batimentos
pl: Tętno
cs: Tep
tr: Nabız
hu: Pulzus
sv: Puls
ro: Puls
nl: Hartslag
ca: Pols
id: Detak jantung
nb: Puls
ms: Kadar denyutan
da: Puls
fi: Syke
vi: Nhịp tim
ru: Пульс
uk: Пульс
el: Παλμοί
'''),
    100002: _rows('''
en: Stress
sr: Stres
es: Estrés
it: Stress
de: Stress
fr: Stress
pt: Estresse
pl: Stres
cs: Stres
tr: Stres
hu: Stressz
sv: Stress
ro: Stres
nl: Stress
ca: Estrès
id: Stres
nb: Stress
ms: Tekanan
da: Stress
fi: Stressi
vi: Căng thẳng
ru: Стресс
uk: Стрес
el: Άγχος
'''),
    100003: _rows('''
en: Temperature
sr: Temperatura
es: Temperatura
it: Temperatura
de: Temperatur
fr: Température
pt: Temperatura
pl: Temperatura
cs: Teplota
tr: Sıcaklık
hu: Hőmérséklet
sv: Temperatur
ro: Temperatură
nl: Temperatuur
ca: Temperatura
id: Suhu
nb: Temperatur
ms: Suhu
da: Temperatur
fi: Lämpötila
vi: Nhiệt độ
ru: Температура
uk: Температура
el: Θερμοκρασία
'''),
    100004: {lang: 'HybridCharge' for lang in LANGS},
    100005: _rows('''
en: Body temp.
sr: Telesna temp.
es: Temp. corporal
it: Temp. corporea
de: Körpertemp.
fr: Temp. corporelle
pt: Temp. corporal
pl: Temp. ciała
cs: Teplota těla
tr: Vücut sıcaklığı
hu: Testhőmérséklet
sv: Kroppstemp.
ro: Temp. corporală
nl: Lichaamstemp.
ca: Temp. corporal
id: Suhu tubuh
nb: Kroppstemp.
ms: Suhu badan
da: Kropstemp.
fi: Kehon lämpö
vi: Nhiệt độ cơ thể
ru: Темп. тела
uk: Темп. тіла
el: Θερμ. σώματος
'''),
    100006: _rows('''
en: Steps
sr: Koraci
es: Pasos
it: Passi
de: Schritte
fr: Pas
pt: Passos
pl: Kroki
cs: Kroky
tr: Adım
hu: Lépések
sv: Steg
ro: Pași
nl: Stappen
ca: Passos
id: Langkah
nb: Skritt
ms: Langkah
da: Skridt
fi: Askeleet
vi: Bước
ru: Шаги
uk: Кроки
el: Βήματα
'''),
    100007: _rows('''
en: Distance
sr: Distanca
es: Distancia
it: Distanza
de: Distanz
fr: Distance
pt: Distância
pl: Dystans
cs: Vzdálenost
tr: Mesafe
hu: Távolság
sv: Distans
ro: Distanță
nl: Afstand
ca: Distància
id: Jarak
nb: Distanse
ms: Jarak
da: Distance
fi: Matka
vi: Quãng đường
ru: Дистанция
uk: Дистанція
el: Απόσταση
'''),
    100008: _rows('''
en: Battery
sr: Baterija
es: Batería
it: Batteria
de: Akku
fr: Batterie
pt: Bateria
pl: Bateria
cs: Baterie
tr: Pil
hu: Akkumulátor
sv: Batteri
ro: Baterie
nl: Batterij
ca: Bateria
id: Baterai
nb: Batteri
ms: Bateri
da: Batteri
fi: Akku
vi: Pin
ru: Батарея
uk: Батарея
el: Μπαταρία
'''),
    100009: _rows('''
en: Calories
sr: Kalorije
es: Calorías
it: Calorie
de: Kalorien
fr: Calories
pt: Calorias
pl: Kalorie
cs: Kalorie
tr: Kalori
hu: Kalória
sv: Kalorier
ro: Calorii
nl: Calorieën
ca: Calories
id: Kalori
nb: Kalorier
ms: Kalori
da: Kalorier
fi: Kalorit
vi: Calo
ru: Калории
uk: Калорії
el: Θερμίδες
'''),
    100010: _rows('''
en: Blood oxygen
sr: Kiseonik
es: Oxígeno
it: Ossigeno
de: Blutsauerstoff
fr: Oxygène
pt: Oxigênio
pl: Tlen we krwi
cs: Kyslík v krvi
tr: Kan oksijeni
hu: Véroxigén
sv: Blodsyre
ro: Oxigen
nl: Bloedzuurstof
ca: Oxigen
id: Oksigen darah
nb: Blodoksygen
ms: Oksigen darah
da: Iltmætning
fi: Veren happi
vi: Oxy trong máu
ru: Кислород
uk: Кисень
el: Οξυγόνο
'''),
    100011: {lang: 'PAI' for lang in LANGS},
    100012: _rows('''
en: Readiness
sr: Spremnost
es: Preparación
it: Prontezza
de: Bereitschaft
fr: Disponibilité
pt: Prontidão
pl: Gotowość
cs: Připravenost
tr: Hazırlık
hu: Felkészültség
sv: Beredskap
ro: Pregătire
nl: Paraatheid
ca: Preparació
id: Kesiapan
nb: Beredskap
ms: Kesediaan
da: Parathed
fi: Valmius
vi: Sẵn sàng
ru: Готовность
uk: Готовність
el: Ετοιμότητα
'''),
    100013: _rows('''
en: Recovery
sr: Oporavak
es: Recuperación
it: Recupero
de: Erholung
fr: Récupération
pt: Recuperação
pl: Regeneracja
cs: Zotavení
tr: Toparlanma
hu: Regeneráció
sv: Återhämtning
ro: Recuperare
nl: Herstel
ca: Recuperació
id: Pemulihan
nb: Restitusjon
ms: Pemulihan
da: Restitution
fi: Palautuminen
vi: Phục hồi
ru: Восстановление
uk: Відновлення
el: Αποκατάσταση
'''),
    100014: _rows('''
en: Floors
sr: Spratovi
es: Pisos
it: Piani
de: Etagen
fr: Étages
pt: Andares
pl: Piętra
cs: Patra
tr: Katlar
hu: Emeletek
sv: Våningar
ro: Etaje
nl: Verdiepingen
ca: Pisos
id: Lantai
nb: Etasjer
ms: Tingkat
da: Etager
fi: Kerrokset
vi: Tầng
ru: Этажи
uk: Поверхи
el: Όροφοι
'''),
    100015: _rows('''
en: Humidity
sr: Vlažnost
es: Humedad
it: Umidità
de: Feuchtigkeit
fr: Humidité
pt: Umidade
pl: Wilgotność
cs: Vlhkost
tr: Nem
hu: Páratartalom
sv: Luftfuktighet
ro: Umiditate
nl: Luchtvochtigheid
ca: Humitat
id: Kelembapan
nb: Fuktighet
ms: Kelembapan
da: Fugtighed
fi: Kosteus
vi: Độ ẩm
ru: Влажность
uk: Вологість
el: Υγρασία
'''),
    100016: _rows('''
en: UV index
sr: UV indeks
es: Índice UV
it: Indice UV
de: UV-Index
fr: Indice UV
pt: Índice UV
pl: Indeks UV
cs: UV index
tr: UV indeksi
hu: UV-index
sv: UV-index
ro: Indice UV
nl: UV-index
ca: Índex UV
id: Indeks UV
nb: UV-indeks
ms: Indeks UV
da: UV-indeks
fi: UV-indeksi
vi: Chỉ số UV
ru: УФ-индекс
uk: УФ-індекс
el: Δείκτης UV
'''),
    100017: _rows('''
en: Stand
sr: Stajanje
es: De pie
it: In piedi
de: Stehen
fr: Debout
pt: Em pé
pl: Stanie
cs: Stání
tr: Ayakta
hu: Állás
sv: Stå
ro: În picioare
nl: Staan
ca: De peu
id: Berdiri
nb: Stå
ms: Berdiri
da: Stå
fi: Seisominen
vi: Đứng
ru: Стояние
uk: Стояння
el: Όρθιος
'''),
    100018: {lang: 'VO2max' for lang in LANGS},
    100019: _rows('''
en: Training load
sr: Opterećenje
es: Carga
it: Carico
de: Belastung
fr: Charge
pt: Carga de treino
pl: Obciążenie
cs: Zátěž
tr: Antrenman yükü
hu: Terhelés
sv: Träningsbelastning
ro: Sarcină
nl: Trainingsbelasting
ca: Càrrega
id: Beban latihan
nb: Treningsbelastning
ms: Beban latihan
da: Træningsbelastning
fi: Kuormitus
vi: Tải luyện tập
ru: Нагрузка
uk: Навантаження
el: Φορτίο
'''),
    100020: _rows('''
en: Sunset
sr: Zalazak sunca
es: Puesta del sol
it: Tramonto
de: Sonnenuntergang
fr: Coucher du soleil
pt: Pôr do sol
pl: Zachód słońca
cs: Západ slunce
tr: Gün batımı
hu: Napnyugta
sv: Solnedgång
ro: Apus
nl: Zonsondergang
ca: Posta de sol
id: Matahari terbenam
nb: Solnedgang
ms: Matahari terbenam
da: Solnedgang
fi: Auringonlasku
vi: Hoàng hôn
ru: Закат
uk: Захід сонця
el: Δύση ηλίου
'''),
    100021: _rows('''
en: Today's max
sr: Max temp. danas
es: Máx. hoy
it: Max oggi
de: Max heute
fr: Max du jour
pt: Máx. hoje
pl: Maks. dziś
cs: Max dnes
tr: Bugün maks.
hu: Mai max.
sv: Max idag
ro: Max azi
nl: Max vandaag
ca: Màx. avui
id: Maks. hari ini
nb: Maks i dag
ms: Maks. hari ini
da: Maks i dag
fi: Päivän max
vi: Cao nhất hôm nay
ru: Макс. сегодня
uk: Макс. сьогодні
el: Μέγ. σήμερα
'''),
    100022: _rows('''
en: Today's min
sr: Min temp. danas
es: Mín. hoy
it: Min oggi
de: Min heute
fr: Min du jour
pt: Mín. hoje
pl: Min. dziś
cs: Min dnes
tr: Bugün min.
hu: Mai min.
sv: Min idag
ro: Min azi
nl: Min vandaag
ca: Mín. avui
id: Min. hari ini
nb: Min i dag
ms: Min. hari ini
da: Min i dag
fi: Päivän min
vi: Thấp nhất hôm nay
ru: Мин. сегодня
uk: Мін. сьогодні
el: Ελάχ. σήμερα
'''),
    100023: _rows('''
en: Running, month
sr: Trčanje u mesecu
es: Carrera del mes
it: Corsa del mese
de: Laufen im Monat
fr: Course du mois
pt: Corrida no mês
pl: Bieg w miesiącu
cs: Běh za měsíc
tr: Aylık koşu
hu: Havi futás
sv: Löpning i månaden
ro: Alergare lunară
nl: Hardlopen, maand
ca: Cursa del mes
id: Lari bulan ini
nb: Løping i måneden
ms: Larian bulan ini
da: Løb i måneden
fi: Juoksu kuussa
vi: Chạy trong tháng
ru: Бег за месяц
uk: Біг за місяць
el: Τρέξιμο μήνα
'''),
    # graph
    'sleep': _rows('''
en: Sleep
sr: San
es: Sueño
it: Sonno
de: Schlaf
fr: Sommeil
pt: Sono
pl: Sen
cs: Spánek
tr: Uyku
hu: Alvás
sv: Sömn
ro: Somn
nl: Slaap
ca: Son
id: Tidur
nb: Søvn
ms: Tidur
da: Søvn
fi: Uni
vi: Giấc ngủ
ru: Сон
uk: Сон
el: Ύπνος
'''),
    # flag
    'noflag': _rows('''
en: No flag
sr: Bez zastave
es: Sin bandera
it: Nessuna bandiera
de: Keine Flagge
fr: Aucun drapeau
pt: Sem bandeira
pl: Bez flagi
cs: Bez vlajky
tr: Bayrak yok
hu: Nincs zászló
sv: Ingen flagga
ro: Fără steag
nl: Geen vlag
ca: Sense bandera
id: Tanpa bendera
nb: Uten flagg
ms: Tiada bendera
da: Intet flag
fi: Ei lippua
vi: Không có cờ
ru: Без флага
uk: Без прапора
el: Χωρίς σημαία
'''),
}
TITLES['hr'] = TITLES[100001]

for _key, _table in (('weekdays', WEEKDAYS), ('months', MONTHS)):
    for _lang, _words in _table.items():
        assert len(_words) == (7 if _key == 'weekdays' else 12), (_key, _lang, _words)


def title(key, lang):
    return TITLES[key][lang]
