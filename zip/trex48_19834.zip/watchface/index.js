import { L } from './layout'

// TrailPulse watch face, Zepp OS watch face API 1.0. Layout numbers come from tools/gen_assets.py.
//
// Every number in the layout is for a 480 x 480 round screen. The Zepp build shrinks the images for each
// screen (width Math.floor(w * screen / 480)), and the code below scales the coordinates the same way, so the
// one design fills every round screen; on a square screen it is as wide as the screen and centred vertically.

const M = L.main
const A = L.aod

const NORMAL = hmUI.show_level.ONLY_NORMAL
const AOD = hmUI.show_level.ONAL_AOD
const EDIT = hmUI.show_level.ONLY_EDIT

const GRAPH_RELOAD = 10 // minutes between redraws of our heart rate graph

// ------------------------------------------------------------ screen size and language

function deviceInfo() {
  try {
    return hmSetting.getDeviceInfo() || {}
  } catch (e) {
    return {}
  }
}
const DEV = deviceInfo()
const SW = DEV.width || 480
const SH = DEV.height || SW
const K = SW / 480
const OY = Math.max(0, Math.round((SH - 480 * K) / 2)) // square screens: the design is centred vertically
const CX = Math.round(SW / 2)

const s = (v) => Math.round(v * K) // a length
const X = (v) => Math.round(v * K) // x of a point
const Y = (v) => Math.round(v * K) + OY // y of a point
const iw = (w) => (K === 1 ? w : Math.max(1, Math.floor(w * K))) // width of an image after the build shrank it
const ih = (h) => Math.ceil(h * K) + (K === 1 ? 0 : 1) // room for the height of a shrunk image

// the watch's language, English where the face has none
function language() {
  try {
    return L.zepp[hmSetting.getLanguage()] || 'en'
  } catch (e) {
    return 'en'
  }
}
const LANG = language()
const LI = L.langs.indexOf(LANG)

// The language whose picture to use, from a string with one base-36 digit per language: languages with the
// same word share one image (tools/gen_assets.py)
function alias(digits, i) {
  return L.langs[parseInt(digits[i === undefined ? LI : i], 36)]
}

// a picture of a weekday or month name: set = M.week, A.month..., n counts from 1
function wordSrc(folder, set, n) {
  return folder + '/' + alias(set.a[LANG], n - 1) + '/' + n + '.png'
}

// Words of edit mode (titles of the choices, the flag list) for the watch's language, from assets
// lang/<lang>.bin: JSON in UTF-16LE. Only this language is read; English is in the layout in case it fails.
function readText(path) {
  try {
    const [st, err] = hmFS.stat_asset(path)
    if (err !== 0 || !st || !st.size) return null
    const fd = hmFS.open_asset(path, hmFS.O_RDONLY)
    const buf = new ArrayBuffer(st.size)
    hmFS.read(fd, buf, 0, st.size)
    hmFS.close(fd)
    const u = new Uint16Array(buf)
    let text = ''
    for (let i = 0; i < u.length; i += 2048) text += String.fromCharCode.apply(null, u.subarray(i, i + 2048))
    return JSON.parse(text)
  } catch (e) {
    return null
  }
}
const TEXT = (LANG !== 'en' && readText('lang/' + LANG + '.bin')) || L.en

function titles(text) {
  return { title_en: text, title_sc: text, title_tc: text }
}

// ------------------------------------------------------------ widget helpers

function dataType(keys) {
  for (let i = 0; i < keys.length; i++) {
    const v = hmUI.data_type[keys[i]]
    if (typeof v === 'number') return v
  }
  return undefined
}

function digitArray(dir) {
  const out = []
  for (let d = 0; d < 10; d++) out.push(dir + '/' + d + '.png')
  return out
}

function img(props) {
  return hmUI.createWidget(hmUI.widget.IMG, props)
}

// image whose src changes later: give it the widest frame of its set so a wider digit is not clipped
// (x, y already on the screen; widths and h in design units)
function swapImg(x, y, widths, h, src, level) {
  return img({ x, y, w: iw(Math.max.apply(null, widths)), h: ih(h), src, show_level: level })
}

// tap areas are remembered so they can be made again on top of the seconds (see placeWatchSeconds)
const clicks = []

// design units in, like the layout
function click(x, y, w, h, src, type) {
  if (typeof type !== 'number') return null
  const c = { props: { x: X(x), y: Y(y), w: s(w), h: s(h), src, type, show_level: NORMAL } }
  c.widget = hmUI.createWidget(hmUI.widget.IMG_CLICK, c.props)
  clicks.push(c)
  return c.widget
}

// value widget (TEXT_IMG) for one data type, with units and "--" when there is no data
// (x, y and w already on the screen)
function valueProps(style, opt, type, x, y, w) {
  const dir = style.dir
  const props = {
    x,
    y,
    w,
    h: ih(style.h),
    type,
    font_array: digitArray(dir),
    h_space: 0,
    align_h: hmUI.align.LEFT,
    negative_image: dir + '/minus.png',
    dot_image: dir + (opt.unit === 'hhmm' ? '/colon.png' : LANG === 'en' ? '/dot.png' : '/comma.png'),
    invalid_image: dir + '/none.png',
    show_level: NORMAL
  }
  const unit = { deg: 'deg', pct: 'pct', hr: 'h', km: 'km' }[opt.unit]
  if (unit) {
    const u = dir + '/' + unit + '.png'
    props.unit_en = u
    props.unit_sc = u
    props.unit_tc = u
    if (opt.unit === 'km') {
      const mi = dir + '/mi.png'
      props.imperial_unit_en = mi
      props.imperial_unit_sc = mi
      props.imperial_unit_tc = mi
    }
  }
  return props
}

// label size of an option: [long w, long h, short w, short h]
// the label picture of an option in a label style, long or short, in the watch's language
function label(o, ls, short) {
  const a = alias(short ? o.sa : o.la)
  const size = (short ? o.sw : o.lw)[a][ls]
  return { src: 'label/' + ls + '/' + a + '/' + o.id + (short ? 's' : '') + '.png', w: size[0], h: size[1], alias: a }
}

function isShort(slot, o) {
  return ((slot.short[o.id] || 0) >> LI) & 1
}

// edit-mode preview of an option in a slot: named by what it shows (preview_path in tools/gen_assets.py)
function previewSrc(slot, o) {
  const short = isShort(slot, o)
  const point = LANG === 'en' && o.sample.indexOf(',') >= 0 ? 'p' : ''
  return 'preview/' + slot.style + '_' + slot.pox + '/' + label(o, slot.ls, short).alias + '/' + o.id +
    (short ? 's' : '') + point + '.png'
}

function flagId(code) {
  if (code.length === 2) return 110000 + (code.charCodeAt(0) - 97) * 26 + (code.charCodeAt(1) - 97)
  return 111000 + L.flag.extra.indexOf(code)
}

function slotX(slot) {
  return slot.xl ? slot.xl[LANG] : slot.x
}

WatchFace({
  build() {
    this.time = hmSensor.createSensor(hmSensor.id.TIME)
    this.weather = hmSensor.createSensor(hmSensor.id.WEATHER)
    this.heart = hmSensor.createSensor(hmSensor.id.HEART)
    this.sensors = {}
    this.warns = []

    this.options = L.options
      .map((o) => ({ ...o, type: dataType(o.keys) }))
      .filter((o) => typeof o.type === 'number')

    hmUI.createWidget(hmUI.widget.FILL_RECT, { x: 0, y: 0, w: SW, h: SH, color: 0x000000, show_level: NORMAL | AOD })
    img({ x: X(0), y: Y(0), src: 'edit/bg.png', show_level: EDIT })

    const chosen = this.buildEditGroups()
    this.flagCode = this.buildFlagGroup()
    this.buildHeader()
    this.buildTime()
    L.slots.forEach((slot) => this.buildSlot(slot, chosen[slot.id]))
    this.buildGraph(chosen.graph)
    this.buildStepBar()
    this.buildAod()

    this.onMinute = () => this.refreshNormal(false)
    this.onMinuteAod = () => this.refreshAod()
    this.secTimer = null

    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: () => this.resume(),
      pause_call: () => this.pause()
    })
    this.refreshNormal(true)
    this.refreshAod()
  },

  onDestroy() {
    this.pause()
  },

  // ------------------------------------------------------------ lifecycle

  resume() {
    this.pause()
    const screen = hmSetting.getScreenType()
    if (screen == hmSetting.screen_type.AOD) {
      this.time.addEventListener(this.time.event.MINUTEEND, this.onMinuteAod)
      this.refreshAod()
    } else if (screen == hmSetting.screen_type.WATCHFACE) {
      this.time.addEventListener(this.time.event.MINUTEEND, this.onMinute)
      this.refreshNormal(true)
      if (!this.secWatch) this.secTimer = timer.createTimer(1000, 1000, () => this.updateSeconds())
    }
  },

  pause() {
    if (this.time && this.time.removeEventListener) {
      this.time.removeEventListener(this.time.event.MINUTEEND, this.onMinute)
      this.time.removeEventListener(this.time.event.MINUTEEND, this.onMinuteAod)
    }
    if (this.secTimer) {
      timer.stopTimer(this.secTimer)
      this.secTimer = null
    }
  },

  refreshNormal(full) {
    this.updateTime()
    this.updateSeconds()
    this.updateDate()
    this.updateWeather()
    this.updateWarnings()
    if (full || this.time.minute % GRAPH_RELOAD === 0) this.updateGraph()
  },

  // runs every minute on always-on; widgets are only touched when the date or the weather changed
  refreshAod() {
    const icon = 'aweather/' + this.weatherIndex() + '.png'
    this.aSets.forEach((set) => {
      this.updateAodDate(set)
      if (set.iconShown !== icon) {
        set.iconShown = icon
        set.icon.setProperty(hmUI.prop.SRC, icon)
      }
    })
    if (this.aSets.length > 1) this.dodgeHands()
  },

  // 'dodge' layout: when a hand covers the top block (temperature + date) and the bottom is free,
  // show the mirrored arrangement with temperature and date at the bottom
  dodgeHands() {
    const t = this.time
    const angles = [((t.hour % 12) + t.minute / 60) * 30, t.minute * 6]
    const near = (target) =>
      angles.some((a) => {
        const d = Math.abs(a - target) % 360
        return Math.min(d, 360 - d) < A.dodgeAngle
      })
    const pick = near(0) && !near(180) ? 1 : 0
    this.aSets.forEach((set, i) => set.widgets.forEach((w) => w.setProperty(hmUI.prop.VISIBLE, i === pick)))
  },

  // ------------------------------------------------------------ edit mode

  editGroup(editId, box, sel, unsel, def, optional, tipsX, tipsY, extra) {
    const [x, y, w, h] = box
    return hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
      edit_id: editId,
      x: X(x),
      y: Y(y),
      w: s(w),
      h: s(h),
      select_image: sel,
      un_select_image: unsel,
      default_type: def,
      optional_types: optional,
      count: optional.length,
      tips_BG: 'edit/tips.png',
      tips_x: s(tipsX),
      tips_y: s(tipsY),
      tips_width: s(L.tipsW),
      tips_margin: s(6),
      ...(extra || {})
    })
  },

  buildEditGroups() {
    const chosen = {}
    const byId = {}
    this.options.forEach((o) => (byId[o.id] = o))

    L.slots.forEach((slot) => {
      // only the options whose widest value fits this slot in the watch's language
      const fits = this.options.filter((o) => ((slot.fit[o.id] || 0) >> LI) & 1)
      const optional = fits.map((o) => ({
        type: o.id,
        preview: previewSrc(slot, o),
        ...titles(TEXT.t[o.id])
      }))
      const def = byId[slot.def] ? slot.def : optional[0].type
      const group = this.editGroup(slot.edit, slot.box, 'edit/' + slot.id + '_sel.png',
        'edit/' + slot.id + '_unsel.png', def, optional, slot.tipsX, slot.tipsY)
      const id = group.getProperty(hmUI.prop.CURRENT_TYPE)
      chosen[slot.id] = (fits.indexOf(byId[id]) >= 0 && byId[id]) || byId[def]
    })

    const g = L.graphSlot
    const graphOptional = L.graphOptions.map((o) => ({
      type: o.id,
      preview: 'preview/graph_' + o.id + '.png',
      ...titles(TEXT.g[o.kind])
    }))
    const graphGroup = this.editGroup(g.edit, g.box, 'edit/graph_sel.png', 'edit/graph_unsel.png',
      graphOptional[0].type, graphOptional, g.tipsX, g.tipsY)
    const gid = graphGroup.getProperty(hmUI.prop.CURRENT_TYPE)
    chosen.graph = L.graphOptions.find((o) => o.id === gid) || L.graphOptions[0]
    return chosen
  },

  // flag under the seconds: none by default, any of the flags from a list in edit mode (alphabetical in the
  // watch's language). Returns the code of the chosen flag, or null.
  buildFlagGroup() {
    const F = L.flag
    const codes = TEXT.fl.split('|')
    const names = TEXT.fn.split('|')
    const optional = [{ type: F.none, preview: 'flags/none.png', ...titles(TEXT.nf) }]
    codes.forEach((c, i) => optional.push({ type: flagId(c), preview: 'flags/' + c + '.png', ...titles(names[i]) }))
    const b = F.box
    const group = this.editGroup(F.edit, [b.x, b.y, b.w, b.h], 'edit/flag_sel.png', 'edit/flag_unsel.png', F.none,
      optional, F.tipsX, F.tipsY, {
        // a list over the whole screen, with names, where the firmware has one
        select_list: {
          title_font_size: s(32),
          title_align_h: hmUI.align.CENTER_H,
          list_item_vspace: s(8),
          list_tips_text_font_size: s(30),
          list_tips_text_align_h: hmUI.align.LEFT
        }
      })
    const id = group.getProperty(hmUI.prop.CURRENT_TYPE)
    for (let i = 0; i < codes.length; i++) if (flagId(codes[i]) === id) return codes[i]
    return null
  },

  // ------------------------------------------------------------ top: alarm, date, weather

  buildHeader() {
    const a = M.alarm
    hmUI.createWidget(hmUI.widget.IMG_STATUS, {
      x: X(a.x),
      y: Y(a.y),
      type: hmUI.system_status.CLOCK,
      src: 'icons/alarm.png',
      show_level: NORMAL
    })
    // next alarm time; nothing is drawn while no alarm is set
    const v = M.v20
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      x: X(a.tx),
      y: Y(a.ty),
      w: s(a.tw),
      h: ih(v.h),
      type: hmUI.data_type.ALARM_CLOCK,
      font_array: digitArray(v.dir),
      padding: true, // leading zero: 07:00, not 7:00
      h_space: 0,
      align_h: hmUI.align.LEFT,
      dot_image: v.dir + '/colon.png',
      invalid_image: 'icons/blank.png',
      show_level: NORMAL
    })
    click(a.x - 8, a.y - 5, 130, 40, 'click/alarm.png', hmUI.data_type.ALARM_CLOCK)

    const dy = Y(M.day.baseline - M.day.base)
    this.day1 = swapImg(0, dy, M.day.w, M.day.h, 'day/1.png', NORMAL)
    this.day2 = swapImg(0, dy, M.day.w, M.day.h, 'day/3.png', NORMAL)
    this.week = swapImg(X(M.week.x), Y(M.week.y), M.week.w[LANG], M.week.h, wordSrc('week', M.week, 1), NORMAL)
    this.month = swapImg(X(M.month.x), Y(M.month.y), M.month.w[LANG], M.month.h, wordSrc('month', M.month, 1), NORMAL)

    const w = M.weather
    this.weatherIcon = img({ x: X(w.x), y: Y(w.y), src: 'weather/' + w.none + '.png', show_level: NORMAL })
    const deg = { unit: 'deg' }
    hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...valueProps(M.v25, deg, hmUI.data_type.WEATHER_CURRENT, X(M.temp.x), Y(M.temp.y), s(M.temp.w)),
      align_h: M.temp.align === 'right' ? hmUI.align.RIGHT : hmUI.align.CENTER_H
    })
    const hl = M.hilo
    if (hl) {
      // today's max over min, small, right of the current temperature
      img({ x: X(hl.arrowX), y: Y(hl.upY), src: 'icons/up.png', show_level: NORMAL })
      img({ x: X(hl.arrowX), y: Y(hl.downY), src: 'icons/down.png', show_level: NORMAL })
      hmUI.createWidget(hmUI.widget.TEXT_IMG,
        valueProps(M.wx, deg, hmUI.data_type.WEATHER_HIGH, X(hl.x), Y(hl.hiY), s(hl.w)))
      hmUI.createWidget(hmUI.widget.TEXT_IMG,
        valueProps(M.wx, deg, hmUI.data_type.WEATHER_LOW, X(hl.x), Y(hl.loY), s(hl.w)))
    }
    click(w.x - 2, w.y - 2, 60, 74, 'click/weather.png', hmUI.data_type.WEATHER_CURRENT)

    const sp = M.sep
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: X(sp.x),
      y: Y(sp.y),
      w: s(sp.w),
      h: Math.max(1, s(sp.h)),
      color: sp.color,
      show_level: NORMAL
    })
  },

  updateDate() {
    const t = this.time
    const d1 = Math.floor(t.day / 10)
    const d2 = t.day % 10
    const w1 = iw(M.day.w[d1])
    const w2 = iw(M.day.w[d2])
    const right = X(M.day.right)
    this.day1.setProperty(hmUI.prop.SRC, 'day/' + d1 + '.png')
    this.day1.setProperty(hmUI.prop.X, right - w1 - w2)
    this.day2.setProperty(hmUI.prop.SRC, 'day/' + d2 + '.png')
    this.day2.setProperty(hmUI.prop.X, right - w2)
    this.week.setProperty(hmUI.prop.SRC, wordSrc('week', M.week, t.week))
    this.month.setProperty(hmUI.prop.SRC, wordSrc('month', M.month, t.month))
  },

  weatherIndex() {
    try {
      const v = this.weather.curAirIconIndex
      if (typeof v === 'number' && v >= 0 && v <= 28) return v
    } catch (e) {}
    return M.weather.none
  },

  updateWeather() {
    this.weatherIcon.setProperty(hmUI.prop.SRC, 'weather/' + this.weatherIndex() + '.png')
  },

  // ------------------------------------------------------------ time HH:MM + seconds (+ flag)

  buildTime() {
    const y = Y(M.time.y)
    const T = M.time
    this.hh1 = swapImg(0, y, T.w, T.h, 'time/1.png', NORMAL)
    this.hh2 = swapImg(0, y, T.w, T.h, 'time/0.png', NORMAL)
    this.colon = img({ x: 0, y, src: 'time/colon.png', show_level: NORMAL })
    this.mm1 = swapImg(0, y, T.w, T.h, 'time/0.png', NORMAL)
    this.mm2 = swapImg(0, y, T.w, T.h, 'time/0.png', NORMAL)
    // seconds: by default the watch draws them itself (IMG_TIME), so nothing of ours runs every second;
    // with mode 'js' our timer places natural-width digits every second
    this.secWatch = M.sec.mode === 'watch'
    this.secWidget = null
    this.secWidgetX = -1
    if (!this.secWatch) {
      this.ss1 = swapImg(0, Y(M.sec.y), M.sec.w, M.sec.h, M.sec.dir + '/0.png', NORMAL)
      this.ss2 = swapImg(0, Y(M.sec.y), M.sec.w, M.sec.h, M.sec.dir + '/0.png', NORMAL)
    }
    const F = L.flag
    this.flag = null
    if (this.flagCode) {
      this.flag = img({ x: 0, y: Y(F.y), src: 'flags/' + this.flagCode + '.png', show_level: NORMAL })
      this.flagW = iw(F.w + 2 * F.pad)
    }
    click(40, M.time.y, 400, 100, 'click/time.png', dataType(['COUNT_DOWN'])) // tap on the big time opens the timer
    this.secX = 0
    this.secMax = 0
    this.secShown = ''
    for (let a = 0; a < 6; a++) {
      for (let b = 0; b < 10; b++) this.secMax = Math.max(this.secMax, iw(M.sec.w[a]) + iw(M.sec.w[b]))
    }
  },

  // The watch's seconds widget cannot be moved after it is made, and the seconds follow the width of
  // the big time, so it is made again when its place changes (at most once a minute). The topmost widget
  // takes the tap and IMG_TIME has no size of its own, so a new one covered every tap area made before it
  // (1.3.5/1.3.6: only the time, made again after it, still opened its app). All tap areas are made again after it.
  placeWatchSeconds(x) {
    if (x === this.secWidgetX) return
    if (this.secWidget) hmUI.deleteWidget(this.secWidget)
    this.secWidget = hmUI.createWidget(hmUI.widget.IMG_TIME, {
      second_zero: 1,
      second_startX: x,
      second_startY: Y(M.sec.y),
      second_array: digitArray(M.sec.dir),
      second_space: 0,
      second_align: hmUI.align.LEFT,
      second_follow: 0,
      show_level: NORMAL
    })
    this.secWidgetX = x
    clicks.forEach((c) => {
      hmUI.deleteWidget(c.widget)
      c.widget = hmUI.createWidget(hmUI.widget.IMG_CLICK, c.props)
    })
  },

  updateTime() {
    const t = this.time
    let h = t.hour
    if (hmSetting.getTimeFormat() === 0) h = h % 12 || 12
    const ds = [Math.floor(h / 10), h % 10, Math.floor(t.minute / 10), t.minute % 10]
    const tw = M.time.w.map(iw)
    const colon = iw(M.time.colon)
    const gap = s(M.sec.gap)
    const total = tw[ds[0]] + tw[ds[1]] + colon + tw[ds[2]] + tw[ds[3]] + gap + this.secMax
    let x = Math.round(CX - total / 2)
    const parts = [this.hh1, this.hh2, null, this.mm1, this.mm2]
    const srcs = [ds[0], ds[1], 'colon', ds[2], ds[3]]
    for (let i = 0; i < 5; i++) {
      const w = parts[i] ? parts[i] : this.colon
      w.setProperty(hmUI.prop.SRC, 'time/' + srcs[i] + '.png')
      w.setProperty(hmUI.prop.X, x)
      x += i === 2 ? colon : tw[srcs[i]]
    }
    this.secX = x + gap
    if (this.flag) this.flag.setProperty(hmUI.prop.X, this.secX + Math.round((this.secMax - this.flagW) / 2))
    if (this.secWatch) this.placeWatchSeconds(this.secX)
  },

  // only with mode 'js'; touches the images only when a digit or the place changed
  updateSeconds() {
    if (this.secWatch) return
    const sec = this.time.second
    const a = Math.floor(sec / 10)
    const b = sec % 10
    const key = a + ',' + b + ',' + this.secX
    if (key !== this.secShown) {
      this.secShown = key
      this.ss1.setProperty(hmUI.prop.SRC, M.sec.dir + '/' + a + '.png')
      this.ss1.setProperty(hmUI.prop.X, this.secX)
      this.ss2.setProperty(hmUI.prop.SRC, M.sec.dir + '/' + b + '.png')
      this.ss2.setProperty(hmUI.prop.X, this.secX + iw(M.sec.w[a]))
    }
    if (sec === 0) this.updateTime()
  },

  // ------------------------------------------------------------ editable data slots

  buildSlot(slot, opt) {
    const style = M[slot.style]
    const lab = label(opt, slot.ls, isShort(slot, opt))
    const lw = lab.w
    const ly = opt.icon ? slot.baseline - lab.h + 2 : slot.baseline - M.lbase[slot.ls]
    const src = lab.src
    const x = X(slotX(slot))
    img({ x, y: Y(ly), src, show_level: NORMAL })
    const vx = x + iw(lw) + s(opt.icon ? 4 : 6)
    const [bx, by, bw, bh] = slot.box
    const vy = Y(slot.baseline - style.base)
    const vw = X(bx + bw) - vx
    const value = hmUI.createWidget(hmUI.widget.TEXT_IMG, valueProps(style, opt, opt.type, vx, vy, vw))
    const sensor = opt.warn && this.sensor(opt.warn.sensors)
    if (sensor) {
      // orange twin of the value, shown instead of the white one past the limit (low battery, high stress...)
      const orange = hmUI.createWidget(
        hmUI.widget.TEXT_IMG,
        valueProps({ ...style, dir: style.dir + 'o' }, opt, opt.type, vx, vy, vw)
      )
      orange.setProperty(hmUI.prop.VISIBLE, false)
      this.warns.push({ value, orange, sensor, warn: opt.warn, on: false })
    }
    click(bx, by, bw, bh, 'click/' + slot.id + '.png', opt.type)
  },

  // first sensor of the list the firmware has (HybridCharge has no documented sensor, so it may have none)
  sensor(names) {
    for (let i = 0; i < names.length; i++) {
      const name = names[i]
      if (name in this.sensors) return this.sensors[name]
      let sensor = null
      try {
        if (hmSensor.id[name] !== undefined) sensor = hmSensor.createSensor(hmSensor.id[name])
      } catch (e) {}
      this.sensors[name] = sensor
      if (sensor) return sensor
    }
    return null
  },

  updateWarnings() {
    this.warns.forEach((w) => {
      let v = null
      try {
        v = w.sensor.current
      } catch (e) {}
      const on =
        typeof v === 'number' && v > 0 && (w.warn.when === 'above' ? v > w.warn.limit : v < w.warn.limit)
      if (on === w.on) return
      w.on = on
      w.value.setProperty(hmUI.prop.VISIBLE, !on)
      w.orange.setProperty(hmUI.prop.VISIBLE, on)
    })
  },

  // ------------------------------------------------------------ heart rate (or sleep) graph

  // Heart rate: with mode 'js' our code draws today's curve on a fixed 35-185 bpm scale so the
  // numbers on the axis are right (a dark fill made of a zigzag line, then the orange line on top);
  // with mode 'watch' the watch draws it like stock faces do. Sleep is always drawn by the watch.
  // Polyline y counts from the top of the widget (seen on the watch).
  buildGraph(choice) {
    const g = M.graph
    this.G = { x: X(g.x), y: Y(g.y), w: s(g.w), h: s(g.h), dot: iw(g.dot) }
    const G = this.G
    img({ x: X(g.gridX), y: Y(g.gridY), src: 'graph/grid.png', show_level: NORMAL })
    const ours = choice.kind === 'hr' && g.mode === 'js'
    const type = choice.kind === 'sleep' ? hmUI.data_type.SLEEP : hmUI.data_type.HEART
    const base = { x: G.x, y: G.y, w: G.w, h: G.h, show_level: NORMAL }
    if (ours) {
      this.graphFill = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, { ...base, line_color: g.fill, line_width: 3 })
      this.graphLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, { ...base, line_color: g.color, line_width: 2 })
      this.graphDot = img({ x: G.x, y: G.y, w: G.dot, h: G.dot, src: 'graph/dot.png', show_level: NORMAL })
      // the number is drawn digit by digit (like the big time) so it keeps the font's natural spacing;
      // TEXT_IMG would put every digit in a cell as wide as the widest one
      this.graphMax = this.graphNumber('graph/max.png')
      if (g.min) this.graphMin = this.graphNumber('graph/min.png')
    } else {
      hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, { ...base, line_color: g.color, line_width: 2, type })
    }
    click(g.x, g.y - 4, g.w, g.h + 8, 'click/graph.png', type)
  },

  // gray label + white number of up to 3 digits ("MAX 184")
  graphNumber(label) {
    const g = M.graph
    return {
      label: img({ x: X(g.x), y: Y(g.maxLabelY), src: label, show_level: NORMAL }),
      labelW: iw(label === 'graph/min.png' ? g.minLabelW : g.maxLabelW),
      digits: [0, 1, 2].map(() => swapImg(X(g.x), Y(g.maxY), M.mx.w, M.mx.h, 'mx/0.png', NORMAL))
    }
  },

  // places a graph number with its left edge at x, or its right edge at x when right is set (x on the
  // screen); returns where its left edge ended up. Each digit image is its advance + 1 px.
  placeGraphNumber(n, value, x, right) {
    const g = M.graph
    const adv = (d) => Math.round((M.mx.w[d] - 1) * K)
    const digits = value > 0 ? String(Math.min(value, 999)).split('').map(Number) : []
    let w = n.labelW + s(g.maxGap)
    digits.forEach((d) => (w += adv(d)))
    const left = right ? x - w : x
    n.label.setProperty(hmUI.prop.X, left)
    let dx = left + n.labelW + s(g.maxGap)
    n.digits.forEach((wd, i) => {
      const d = digits[i]
      wd.setProperty(hmUI.prop.VISIBLE, d !== undefined)
      if (d === undefined) return
      wd.setProperty(hmUI.prop.SRC, 'mx/' + d + '.png')
      wd.setProperty(hmUI.prop.X, dx)
      dx += adv(d)
    })
    n.label.setProperty(hmUI.prop.VISIBLE, digits.length > 0)
    return left
  },

  updateGraph() {
    if (!this.graphLine) return
    const g = M.graph
    const G = this.G
    let today = []
    try {
      today = this.heart.today || []
    } catch (e) {}
    const yOf = (v) => {
      const c = Math.min(g.hi, Math.max(g.lo, v))
      return Math.round((1 - (c - g.lo) / (g.hi - g.lo)) * (G.h - 2)) + 1
    }
    // today[i] is normally minute i since 0:00, but after a restart of the watch the array starts at
    // the restart (seen on the watch: the curve began at 0:00 at 10 am). So the last reading is put at
    // the current minute and everything before it lines up from there; a gap of a minute or two is
    // normal and ignored.
    let shift = this.time.hour * 60 + this.time.minute + 1 - today.length
    if (Math.abs(shift) <= 2) shift = 0
    // one value per 2 px column (7.5 minutes on a 480 screen), average of the valid readings in it
    const cols = Math.floor(G.w / 2)
    const line = []
    const fill = []
    let max = 0
    let min = 0
    for (let i = 0; i < today.length; i++) {
      const v = today[i]
      if (!(v > 0 && v < 250)) continue
      if (v > max) max = v
      if (!min || v < min) min = v
    }
    for (let c = 0; c < cols; c++) {
      const from = Math.floor((c * 1440) / cols)
      const to = Math.floor(((c + 1) * 1440) / cols)
      let sum = 0
      let n = 0
      for (let m = from; m < to; m++) {
        const i = m - shift
        if (i < 0 || i >= today.length) continue
        const v = today[i]
        if (v > 0 && v < 250) {
          sum += v
          n++
        }
      }
      if (!n) continue
      const x = c * 2 + 1
      const y = yOf(sum / n)
      line.push({ x, y })
      // zigzag down and up through every column paints the area under the curve
      if (fill.length % 4 === 0) fill.push({ x, y }, { x, y: G.h })
      else fill.push({ x, y: G.h }, { x, y })
    }
    this.graphFill.clear()
    this.graphLine.clear()
    const has = line.length > 1
    if (has) {
      this.graphFill.addLine({ data: fill, count: fill.length })
      this.graphLine.addLine({ data: line, count: line.length })
      const last = line[line.length - 1]
      const r = Math.floor(G.dot / 2)
      this.graphDot.setProperty(hmUI.prop.X, G.x + last.x - r)
      this.graphDot.setProperty(hmUI.prop.Y, G.y + last.y - r)
    }
    const maxLeft = this.placeGraphNumber(this.graphMax, has ? max : 0, X(g.maxRight + 1), true)
    if (this.graphMin) {
      if (g.min === 'right') this.placeGraphNumber(this.graphMin, has ? min : 0, maxLeft - s(g.pairGap), true)
      else this.placeGraphNumber(this.graphMin, has ? min : 0, X(g.minLeft), false)
    }
    this.graphDot.setProperty(hmUI.prop.VISIBLE, has)
  },

  buildStepBar() {
    const b = M.bar
    const arr = []
    for (let i = 0; i < b.n; i++) arr.push('bar/' + i + '.png')
    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
      x: X(b.x),
      y: Y(b.y),
      image_array: arr,
      image_length: b.n,
      type: hmUI.data_type.STEP,
      show_level: NORMAL
    })
  },

  // ------------------------------------------------------------ always-on (analog)

  buildAod() {
    img({ x: X(0), y: Y(0), src: 'aod/ring.png', show_level: AOD })
    this.aSets = A.sets.map((set) => this.buildAodSet(set))

    // the pivot inside a hand image moves with the image when the build shrinks it
    const pivot = (hand, v) => Math.round((v * iw(hand.w)) / hand.w)
    const cover = iw(A.cover.w)
    hmUI.createWidget(hmUI.widget.TIME_POINTER, {
      hour_centerX: X(240),
      hour_centerY: Y(240),
      hour_posX: pivot(A.hour, A.hour.posX),
      hour_posY: pivot(A.hour, A.hour.posY),
      hour_path: A.hour.path,
      minute_centerX: X(240),
      minute_centerY: Y(240),
      minute_posX: pivot(A.minute, A.minute.posX),
      minute_posY: pivot(A.minute, A.minute.posY),
      minute_path: A.minute.path,
      minute_cover_path: A.cover.path,
      minute_cover_x: X(240) - Math.floor(cover / 2),
      minute_cover_y: Y(240) - Math.floor(cover / 2),
      show_level: AOD
    })
  },

  // date, weather and distance at the positions of one arrangement
  buildAodSet(a) {
    const set = {}
    set.day1 = swapImg(0, Y(a.dayY), A.day.w, A.day.h, 'aday/1.png', AOD)
    set.day2 = swapImg(0, Y(a.dayY), A.day.w, A.day.h, 'aday/3.png', AOD)
    set.week = swapImg(0, Y(a.weekY), A.week.w[LANG], A.week.h, wordSrc('aweek', A.week, 1), AOD)
    set.month = swapImg(0, Y(a.monthY), A.month.w[LANG], A.month.h, wordSrc('amonth', A.month, 1), AOD)

    const t = A.temp
    set.icon = img({ x: X(t.iconX), y: Y(a.iconY), src: 'aweather/' + M.weather.none + '.png', show_level: AOD })
    const deg = { unit: 'deg' }
    const temp = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...valueProps(A.v25, deg, hmUI.data_type.WEATHER_CURRENT, X(t.x), Y(a.tempY), s(t.w)),
      align_h: t.align === 'right' ? hmUI.align.RIGHT : hmUI.align.LEFT,
      show_level: AOD
    })
    const hilo = []
    if (t.arrowX) {
      // today's max over min, as on the main screen
      hilo.push(
        img({ x: X(t.arrowX), y: Y(a.upY), src: A.up, show_level: AOD }),
        img({ x: X(t.arrowX), y: Y(a.downY), src: A.down, show_level: AOD }),
        hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          ...valueProps(A.wx, deg, hmUI.data_type.WEATHER_HIGH, X(t.hiX), Y(a.hiY), s(t.hiW)),
          show_level: AOD
        }),
        hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          ...valueProps(A.wx, deg, hmUI.data_type.WEATHER_LOW, X(t.hiX), Y(a.loY), s(t.hiW)),
          show_level: AOD
        })
      )
    }

    // distance: the value centred, its caption centred above it
    const capW = iw(A.distCap[LANG])
    const label = img({
      x: CX - Math.floor(capW / 2),
      y: Y(a.distCapY),
      src: 'aod/cap/' + LANG + '.png',
      show_level: AOD
    })
    const dist = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
      ...valueProps(A.v25, { unit: 'km' }, hmUI.data_type.DISTANCE, X(240 - A.distW / 2), Y(a.distValueY), s(A.distW)),
      align_h: hmUI.align.CENTER_H,
      show_level: AOD
    })
    set.widgets = [set.day1, set.day2, set.week, set.month, set.icon, temp, label, dist].concat(hilo)
    return set
  },

  updateAodDate(set) {
    const t = this.time
    const key = t.day + ',' + t.week + ',' + t.month
    if (set.dateShown === key) return
    set.dateShown = key
    const d1 = Math.floor(t.day / 10)
    const d2 = t.day % 10
    const w1 = iw(A.day.w[d1])
    const w2 = iw(A.day.w[d2])
    const ww = Math.max(iw(A.week.w[LANG][t.week - 1]), iw(A.month.w[LANG][t.month - 1]))
    const x0 = Math.round(CX - (w1 + w2 + s(A.dateGap) + ww) / 2)
    set.day1.setProperty(hmUI.prop.SRC, 'aday/' + d1 + '.png')
    set.day1.setProperty(hmUI.prop.X, x0)
    set.day2.setProperty(hmUI.prop.SRC, 'aday/' + d2 + '.png')
    set.day2.setProperty(hmUI.prop.X, x0 + w1)
    const tx = x0 + w1 + w2 + s(A.dateGap)
    set.week.setProperty(hmUI.prop.SRC, wordSrc('aweek', A.week, t.week))
    set.week.setProperty(hmUI.prop.X, tx)
    set.month.setProperty(hmUI.prop.SRC, wordSrc('amonth', A.month, t.month))
    set.month.setProperty(hmUI.prop.X, tx)
  }
})
