try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const hmUI = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const settings = __$$RQR$$__('@zos/settings');
                const sensor = __$$RQR$$__('@zos/sensor');
                function _interopNamespaceCompat(e) {
                    if (e && typeof e === 'object' && 'default' in e)
                        return e;
                    const n = Object.create(null, { [Symbol.toStringTag]: { value: 'Module' } });
                    if (e) {
                        for (const k in e) {
                            if (k !== 'default') {
                                const d = Object.getOwnPropertyDescriptor(e, k);
                                Object.defineProperty(n, k, d.get ? d : {
                                    enumerable: true,
                                    get: () => e[k]
                                });
                            }
                        }
                    }
                    n.default = e;
                    return Object.freeze(n);
                }
                const hmUI__namespace = _interopNamespaceCompat(hmUI);
                const ROOT = 'images/';
                const pad2 = value => String(value).padStart(2, '0');
                const source = (group, key) => ROOT + group + '/' + key + '.png';
                const dayLanguage = () => settings.getLanguage() === 30 ? 'hu' : 'en';
                let clock = null;
                let power = null;
                let weather = null;
                let interval = null;
                let batteryListener = null;
                let timeViews = {};
                let lastValues = {
                    hour: -1,
                    minute: -1,
                    second: -1,
                    week: -1,
                    day: -1,
                    month: -1,
                    lang: '',
                    battery: -1,
                    weather: -1
                };
                function setImage(view, file) {
                    if (view)
                        view.setProperty(hmUI__namespace.prop.SRC, file);
                }
                function refreshClock() {
                    if (!clock)
                        return;
                    let values;
                    try {
                        values = {
                            hour: clock.getHours(),
                            minute: clock.getMinutes(),
                            second: clock.getSeconds(),
                            week: clock.getDay() % 7,
                            day: clock.getDate(),
                            month: clock.getMonth()
                        };
                    } catch (e) {
                        return;
                    }
                    const lang = dayLanguage();
                    if (values.hour !== lastValues.hour) {
                        setImage(timeViews.h10, source('r4/main', Math.floor(values.hour / 10)));
                        setImage(timeViews.h1, source('r4/main', values.hour % 10));
                        lastValues.hour = values.hour;
                    }
                    if (values.minute !== lastValues.minute) {
                        setImage(timeViews.m10, source('r4/main', Math.floor(values.minute / 10)));
                        setImage(timeViews.m1, source('r4/main', values.minute % 10));
                        lastValues.minute = values.minute;
                    }
                    if (values.second !== lastValues.second) {
                        setImage(timeViews.second, source('r4/seconds', pad2(values.second)));
                        lastValues.second = values.second;
                    }
                    if (values.week !== lastValues.week || lang !== lastValues.lang) {
                        setImage(timeViews.week, source('date/' + lang + '/weekday', values.week));
                        lastValues.week = values.week;
                    }
                    if (values.day !== lastValues.day) {
                        setImage(timeViews.day, source('date/day', pad2(values.day)));
                        lastValues.day = values.day;
                    }
                    if (values.month !== lastValues.month || lang !== lastValues.lang) {
                        setImage(timeViews.month, source('date/' + lang + '/month', pad2(values.month)));
                        lastValues.month = values.month;
                    }
                    lastValues.lang = lang;
                }
                function refreshBattery() {
                    if (!power)
                        return;
                    try {
                        const value = Math.max(0, Math.min(100, Math.round(power.getCurrent())));
                        if (value !== lastValues.battery) {
                            setImage(timeViews.battery, source('battery', String(value).padStart(3, '0')));
                            lastValues.battery = value;
                        }
                    } catch (e) {
                    }
                }
                function refreshWeatherIcon() {
                    if (!weather)
                        return;
                    try {
                        const forecast = weather.getForecast();
                        const list = forecast && forecast.forecastData && forecast.forecastData.data;
                        const index = list && list.length > 0 ? Number(list[0].index) : -1;
                        if (Number.isInteger(index) && index >= 0 && index <= 28 && index !== lastValues.weather) {
                            setImage(timeViews.weather, source('r4/weather', pad2(index)));
                            lastValues.weather = index;
                        }
                    } catch (e) {
                    }
                }
                __$$module$$__.module = WatchFace({
                    build() {
                        const aod = app.getScene() === app.SCENE_AOD;
                        if (aod) {
                            hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                x: 0,
                                y: 0,
                                w: 480,
                                h: 480,
                                color: 0,
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            const digits = Array.from({ length: 10 }, (_, i) => source('aod', i));
                            hmUI__namespace.createWidget(hmUI__namespace.widget.IMG_TIME, {
                                hour_startX: 161,
                                hour_startY: 217,
                                hour_array: digits,
                                hour_zero: 1,
                                hour_space: 1,
                                hour_align: hmUI__namespace.align.LEFT,
                                minute_startX: 250,
                                minute_startY: 217,
                                minute_array: digits,
                                minute_zero: 1,
                                minute_space: 1,
                                minute_align: hmUI__namespace.align.LEFT,
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            hmUI__namespace.createWidget(hmUI__namespace.widget.IMG, {
                                x: 230,
                                y: 216,
                                src: source('aod', 'colon'),
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            return;
                        }
                        hmUI__namespace.createWidget(hmUI__namespace.widget.IMG, {
                            x: 0,
                            y: 0,
                            src: ROOT + 'bg.png',
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        const staticImage = (folder, name, x, y) => hmUI__namespace.createWidget(hmUI__namespace.widget.IMG, {
                            x,
                            y,
                            src: source(folder, name),
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        staticImage('r4/icons', 'colon', 222, 183);
                        staticImage('r4/icons', 'steps', 216, 338);
                        staticImage('r4/icons', 'heart', 331, 344);
                        staticImage('icons', 'brand', 185, 428);
                        hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                            x: 230,
                            y: 450,
                            w: 20,
                            h: 1,
                            color: 14144975,
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        timeViews = {
                            h10: staticImage('r4/main', 'empty', 94, 177),
                            h1: staticImage('r4/main', 'empty', 155, 177),
                            m10: staticImage('r4/main', 'empty', 252, 177),
                            m1: staticImage('r4/main', 'empty', 313, 177),
                            second: staticImage('r4/seconds', 'empty', 351, 264),
                            week: staticImage('r4/blank', 'weekday', 56, 109),
                            day: staticImage('r4/blank', 'day', 107, 109),
                            month: staticImage('r4/blank', 'month', 141, 109),
                            battery: staticImage('battery', 'empty', 335, 103),
                            weather: staticImage('r4/weather', 'empty', 109, 342)
                        };
                        const tempGlyphs = Array.from({ length: 10 }, (_, i) => source('r4/digits/temp', i));
                        const stepGlyphs = Array.from({ length: 10 }, (_, i) => source('r4/digits/steps', i));
                        const heartGlyphs = Array.from({ length: 10 }, (_, i) => source('r4/digits/heart', i));
                        hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT_IMG, {
                            x: 93,
                            y: 373,
                            w: 70,
                            h: 28,
                            font_array: tempGlyphs,
                            type: hmUI__namespace.data_type.WEATHER_CURRENT,
                            negative_image: source('r4/digits', 'minus'),
                            unit_en: source('r4/digits', 'celsius'),
                            unit_sc: source('r4/digits', 'celsius'),
                            unit_tc: source('r4/digits', 'celsius'),
                            imperial_unit_en: source('r4/digits', 'fahrenheit'),
                            imperial_unit_sc: source('r4/digits', 'fahrenheit'),
                            imperial_unit_tc: source('r4/digits', 'fahrenheit'),
                            h_space: 0,
                            align_h: hmUI__namespace.align.CENTER_H,
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT_IMG, {
                            x: 190,
                            y: 373,
                            w: 100,
                            h: 28,
                            font_array: stepGlyphs,
                            type: hmUI__namespace.data_type.STEP,
                            h_space: 0,
                            align_h: hmUI__namespace.align.CENTER_H,
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT_IMG, {
                            x: 314,
                            y: 373,
                            w: 70,
                            h: 28,
                            font_array: heartGlyphs,
                            type: hmUI__namespace.data_type.HEART,
                            h_space: 0,
                            align_h: hmUI__namespace.align.CENTER_H,
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        try {
                            clock = new sensor.Time();
                        } catch (e) {
                            clock = null;
                        }
                        try {
                            power = new sensor.Battery();
                        } catch (e) {
                            power = null;
                        }
                        try {
                            weather = new sensor.Weather();
                        } catch (e) {
                            weather = null;
                        }
                        refreshClock();
                        refreshBattery();
                        refreshWeatherIcon();
                        if (power) {
                            batteryListener = () => refreshBattery();
                            power.onChange(batteryListener);
                        }
                        interval = setInterval(() => {
                            refreshClock();
                            if (clock && clock.getSeconds() === 0)
                                refreshBattery();
                            if (clock && clock.getMinutes() % 5 === 0 && clock.getSeconds() === 0)
                                refreshWeatherIcon();
                        }, 1000);
                    },
                    onDestroy() {
                        if (interval !== null)
                            clearInterval(interval);
                        if (power && batteryListener)
                            power.offChange(batteryListener);
                        interval = null;
                        batteryListener = null;
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}