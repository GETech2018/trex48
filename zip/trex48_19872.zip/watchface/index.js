try {
    ((() => {
        const {beforeModuleCreate = () => {
            }, afterModuleCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforeModuleCreate();
        const {beforePageCreate = () => {
            }, afterPageCreate = () => {
            }} = DeviceRuntimeCore.LifeCycle;
        beforePageCreate();
        const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;
        !function (context) {
            with (context) {
                const __$$RQR$$__ = __$$R$$__;
                const hmUI = __$$RQR$$__('@zos/ui');
                const app = __$$RQR$$__('@zos/app');
                const sensor = __$$RQR$$__('@zos/sensor');
                function _interopNamespaceCompat(e) {
                    if (e && typeof e === 'object' && 'default' in e)
                        return e;
                    const n = Object.create(null, { [Symbol.toStringTag]: { value: 'Module' } });
                    if (e) {
                        for (const k in e) {
                            if (k !== 'default') {
                                const d = Object.getOwnPropertyDescriptor(e, k);
                                Object.defineProperty(n, k, d.get ? d : {
                                    enumerable: true,
                                    get: () => e[k]
                                });
                            }
                        }
                    }
                    n.default = e;
                    return Object.freeze(n);
                }
                const hmUI__namespace = _interopNamespaceCompat(hmUI);
                const P = 'images/polar/';
                const D = 'images/';
                const z2 = n => String(n).padStart(2, '0');
                const z3 = n => String(n).padStart(3, '0');
                const file = (folder, name) => P + folder + '/' + name + '.png';
                let time = null, step = null, power = null, heart = null;
                let views = {};
                let refreshTimer = null;
                let powerListener = null, heartListener = null;
                let old = {
                    hours: -1,
                    minutes: -1,
                    days: -1,
                    month: -1,
                    weekday: -1,
                    battery: -1,
                    heart: -1
                };
                function replace(view, source) {
                    if (view)
                        view.setProperty(hmUI__namespace.prop.SRC, source);
                }
                function addImage(src, x, y) {
                    return hmUI__namespace.createWidget(hmUI__namespace.widget.IMG, {
                        x,
                        y,
                        src,
                        show_level: hmUI__namespace.show_level.ONLY_NORMAL
                    });
                }
                function updateTime() {
                    if (!time)
                        return;
                    try {
                        const hours = time.getHours();
                        const minutes = time.getMinutes();
                        const days = time.getDate();
                        const month = time.getMonth();
                        const weekday = time.getDay() % 7;
                        if (hours !== old.hours) {
                            replace(views.hours, file('hours', z2(hours)));
                            old.hours = hours;
                        }
                        if (minutes !== old.minutes) {
                            replace(views.minutes, file('minutes', z2(minutes)));
                            old.minutes = minutes;
                        }
                        if (weekday !== old.weekday) {
                            replace(views.weekday, file('weekday', weekday));
                            old.weekday = weekday;
                        }
                        if (days !== old.days) {
                            replace(views.days, file('day', z2(days)));
                            old.days = days;
                        }
                        if (month !== old.month) {
                            replace(views.month, file('month', z2(month)));
                            old.month = month;
                        }
                    } catch (e) {
                    }
                }
                function updateBattery() {
                    if (!power)
                        return;
                    try {
                        const n = Math.max(0, Math.min(100, Math.round(power.getCurrent())));
                        if (n !== old.battery) {
                            replace(views.battery, file('battery', z3(n)));
                            old.battery = n;
                        }
                    } catch (e) {
                    }
                }
                function updateHeart() {
                    if (!heart)
                        return;
                    try {
                        const n = Math.round(heart.getLast());
                        if (n > 0 && n <= 220 && n !== old.heart) {
                            replace(views.heart, file('pulse', z3(n)));
                            old.heart = n;
                        }
                    } catch (e) {
                    }
                }
                __$$module$$__.module = WatchFace({
                    build() {
                        if (app.getScene() === app.SCENE_AOD) {
                            hmUI__namespace.createWidget(hmUI__namespace.widget.FILL_RECT, {
                                x: 0,
                                y: 0,
                                w: 480,
                                h: 480,
                                color: 0,
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            const digits = Array.from({ length: 10 }, (_, i) => file('aod', i));
                            hmUI__namespace.createWidget(hmUI__namespace.widget.IMG_TIME, {
                                hour_startX: 174,
                                hour_startY: 218,
                                hour_array: digits,
                                hour_zero: 1,
                                hour_space: 1,
                                hour_align: hmUI__namespace.align.LEFT,
                                minute_startX: 260,
                                minute_startY: 218,
                                minute_array: digits,
                                minute_zero: 1,
                                minute_space: 1,
                                minute_align: hmUI__namespace.align.LEFT,
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            hmUI__namespace.createWidget(hmUI__namespace.widget.IMG, {
                                x: 238,
                                y: 229,
                                src: file('aod', 'colon'),
                                show_level: hmUI__namespace.show_level.ONAL_AOD
                            });
                            return;
                        }
                        addImage(D + 'bg.png', 0, 0);
                        addImage(file('colon', 'colon'), 220, 308);
                        views.hours = addImage(file('hours', '00'), 116, 308);
                        views.minutes = addImage(file('minutes', '00'), 250, 308);
                        views.weekday = addImage(file('weekday', 0), 144, 392);
                        views.days = addImage(file('day', '01'), 182, 392);
                        views.month = addImage(file('month', '01'), 211, 392);
                        views.battery = addImage(file('battery', '000'), 250, 390);
                        addImage(file('icons', 'shoe'), 70, 192);
                        addImage(file('icons', 'heart'), 364, 192);
                        const stepDigits = Array.from({ length: 10 }, (_, i) => file('steps', i));
                        hmUI__namespace.createWidget(hmUI__namespace.widget.TEXT_IMG, {
                            x: 52,
                            y: 242,
                            w: 83,
                            h: 23,
                            font_array: stepDigits,
                            type: hmUI__namespace.data_type.STEP,
                            h_space: -1,
                            align_h: hmUI__namespace.align.CENTER_H,
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        views.heart = addImage(file('pulse', '000'), 350, 231);
                        hmUI__namespace.createWidget(hmUI__namespace.widget.TIME_POINTER, {
                            hour_centerX: 240,
                            hour_centerY: 237,
                            hour_posX: 19,
                            hour_posY: 171,
                            hour_path: file('hands', 'hour'),
                            minute_centerX: 240,
                            minute_centerY: 237,
                            minute_posX: 22,
                            minute_posY: 207,
                            minute_path: file('hands', 'minute'),
                            second_centerX: 240,
                            second_centerY: 237,
                            second_posX: 16,
                            second_posY: 192,
                            second_path: file('hands', 'second'),
                            show_level: hmUI__namespace.show_level.ONLY_NORMAL
                        });
                        try {
                            time = new sensor.Time();
                        } catch (e) {
                            time = null;
                        }
                        try {
                            step = new sensor.Step();
                        } catch (e) {
                            step = null;
                        }
                        try {
                            power = new sensor.Battery();
                        } catch (e) {
                            power = null;
                        }
                        try {
                            heart = new sensor.HeartRate();
                        } catch (e) {
                            heart = null;
                        }
                        old = {
                            hours: -1,
                            minutes: -1,
                            days: -1,
                            month: -1,
                            weekday: -1,
                            battery: -1,
                            heart: -1
                        };
                        updateTime();
                        updateBattery();
                        updateHeart();
                        if (power) {
                            powerListener = () => updateBattery();
                            power.onChange(powerListener);
                        }
                        if (heart) {
                            heartListener = () => updateHeart();
                            heart.onLastChange(heartListener);
                        }
                        refreshTimer = setInterval(() => {
                            updateTime();
                            updateBattery();
                            updateHeart();
                        }, 1000);
                    },
                    onDestroy() {
                        if (refreshTimer !== null)
                            clearInterval(refreshTimer);
                        if (power && powerListener)
                            power.offChange(powerListener);
                        if (heart && heartListener)
                            heart.offLastChange(heartListener);
                        refreshTimer = null;
                        powerListener = null;
                        heartListener = null;
                        time = null;
                        step = null;
                        power = null;
                        heart = null;
                    }
                });
                ;
            }
        }.bind(__$$G$$__)(__$$G$$__);
        afterPageCreate();
        afterModuleCreate();
        ;
    })());
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}