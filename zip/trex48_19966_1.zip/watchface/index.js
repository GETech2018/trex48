﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_floor_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_pointer_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_linear_scale_pointer_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond_en_bleu.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });
            const teintes = {
              100201: { fond: 'fond_en_bleu.png', c: 0xFF10CDFA, meteo: ['meteo_bleu_01.png', 'meteo_bleu_02.png', 'meteo_bleu_03.png', 'meteo_bleu_04.png', 'meteo_bleu_05.png', 'meteo_bleu_06.png', 'meteo_bleu_07.png', 'meteo_bleu_08.png', 'meteo_bleu_09.png', 'meteo_bleu_10.png', 'meteo_bleu_11.png', 'meteo_bleu_12.png', 'meteo_bleu_13.png', 'meteo_bleu_14.png', 'meteo_bleu_15.png', 'meteo_bleu_16.png', 'meteo_bleu_17.png', 'meteo_bleu_18.png', 'meteo_bleu_19.png', 'meteo_bleu_20.png', 'meteo_bleu_21.png', 'meteo_bleu_22.png', 'meteo_bleu_23.png', 'meteo_bleu_24.png', 'meteo_bleu_25.png', 'meteo_bleu_26.png', 'meteo_bleu_27.png', 'meteo_bleu_28.png', 'meteo_bleu_29.png'], vfc: ['vfc_bleu_00.png', 'vfc_bleu_01.png', 'vfc_bleu_02.png', 'vfc_bleu_03.png', 'vfc_bleu_04.png', 'vfc_bleu_05.png', 'vfc_bleu_06.png', 'vfc_bleu_07.png', 'vfc_bleu_08.png', 'vfc_bleu_09.png', 'vfc_bleu_10.png', 'vfc_bleu_11.png', 'vfc_bleu_12.png', 'vfc_bleu_13.png', 'vfc_bleu_14.png', 'vfc_bleu_15.png', 'vfc_bleu_16.png', 'vfc_bleu_17.png', 'vfc_bleu_18.png', 'vfc_bleu_19.png', 'vfc_bleu_20.png', 'vfc_bleu_21.png', 'vfc_bleu_22.png', 'vfc_bleu_23.png', 'vfc_bleu_24.png', 'vfc_bleu_25.png', 'vfc_bleu_26.png', 'vfc_bleu_27.png', 'vfc_bleu_28.png', 'vfc_bleu_29.png', 'vfc_bleu_30.png'] },
              100202: { fond: 'fond_en_rouge.png', c: 0xFFFF2E3A, meteo: ['meteo_rouge_01.png', 'meteo_rouge_02.png', 'meteo_rouge_03.png', 'meteo_rouge_04.png', 'meteo_rouge_05.png', 'meteo_rouge_06.png', 'meteo_rouge_07.png', 'meteo_rouge_08.png', 'meteo_rouge_09.png', 'meteo_rouge_10.png', 'meteo_rouge_11.png', 'meteo_rouge_12.png', 'meteo_rouge_13.png', 'meteo_rouge_14.png', 'meteo_rouge_15.png', 'meteo_rouge_16.png', 'meteo_rouge_17.png', 'meteo_rouge_18.png', 'meteo_rouge_19.png', 'meteo_rouge_20.png', 'meteo_rouge_21.png', 'meteo_rouge_22.png', 'meteo_rouge_23.png', 'meteo_rouge_24.png', 'meteo_rouge_25.png', 'meteo_rouge_26.png', 'meteo_rouge_27.png', 'meteo_rouge_28.png', 'meteo_rouge_29.png'], vfc: ['vfc_rouge_00.png', 'vfc_rouge_01.png', 'vfc_rouge_02.png', 'vfc_rouge_03.png', 'vfc_rouge_04.png', 'vfc_rouge_05.png', 'vfc_rouge_06.png', 'vfc_rouge_07.png', 'vfc_rouge_08.png', 'vfc_rouge_09.png', 'vfc_rouge_10.png', 'vfc_rouge_11.png', 'vfc_rouge_12.png', 'vfc_rouge_13.png', 'vfc_rouge_14.png', 'vfc_rouge_15.png', 'vfc_rouge_16.png', 'vfc_rouge_17.png', 'vfc_rouge_18.png', 'vfc_rouge_19.png', 'vfc_rouge_20.png', 'vfc_rouge_21.png', 'vfc_rouge_22.png', 'vfc_rouge_23.png', 'vfc_rouge_24.png', 'vfc_rouge_25.png', 'vfc_rouge_26.png', 'vfc_rouge_27.png', 'vfc_rouge_28.png', 'vfc_rouge_29.png', 'vfc_rouge_30.png'] },
            };
            const editCouleur = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10043,
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100201,
              optional_types: [
                { type: 100201, preview: 'prev_bleu.png', title_sc: '蓝色', title_tc: '藍色', title_en: 'Blue' },
                { type: 100202, preview: 'prev_rouge.png', title_sc: '红色', title_tc: '紅色', title_en: 'Red' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 165,
              tips_y: 418,
              tips_width: 150,
              tips_margin: 10,
            });
            const teinte = teintes[editCouleur.getProperty(hmUI.prop.CURRENT_TYPE)] || teintes[100201];
            normal_background_bg_img.setProperty(hmUI.prop.MORE, { x: 0, y: 0, w: 480, h: 480, src: teinte.fond });


            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 154,
              y: 39,
              week_en: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_tc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_sc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 37,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 35,
              month_sc_array: ["mois_en_01.png","mois_en_02.png","mois_en_03.png","mois_en_04.png","mois_en_05.png","mois_en_06.png","mois_en_07.png","mois_en_08.png","mois_en_09.png","mois_en_10.png","mois_en_11.png","mois_en_12.png"],
              month_tc_array: ["mois_en_01.png","mois_en_02.png","mois_en_03.png","mois_en_04.png","mois_en_05.png","mois_en_06.png","mois_en_07.png","mois_en_08.png","mois_en_09.png","mois_en_10.png","mois_en_11.png","mois_en_12.png"],
              month_en_array: ["mois_en_01.png","mois_en_02.png","mois_en_03.png","mois_en_04.png","mois_en_05.png","mois_en_06.png","mois_en_07.png","mois_en_08.png","mois_en_09.png","mois_en_10.png","mois_en_11.png","mois_en_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 84,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -3,
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 77,
              image_array: teinte.meteo,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 84,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -2,
              negative_image: 'v_moins.png',
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 84,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'v_null.png',
              dot_image: 'v_point.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              w: 62,
              y: 148,
              font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'g_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              w: 62,
              y: 264,
              font_array: ["g_0.png","g_1.png","g_2.png","g_3.png","g_4.png","g_5.png","g_6.png","g_7.png","g_8.png","g_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'g_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 209,
              // start_y: 235,
              // color: teinte.c,
              // pointer: 'curseur.png',
              // lenght: 144,
              // line_width: 6,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 225,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 209,
              // start_y: 275,
              // color: teinte.c,
              // pointer: 'curseur.png',
              // lenght: 144,
              // line_width: 6,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 265,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_calorie_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 209,
              // start_y: 315,
              // color: teinte.c,
              // pointer: 'curseur.png',
              // lenght: 144,
              // line_width: 6,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 305,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'v_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 232,
              y: 424,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'b_pct.png',
              unit_tc: 'b_pct.png',
              unit_en: 'b_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 123,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 292,
              minute_startY: 123,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 411,
              second_startY: 179,
              second_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // FC au repos des 7 derniers jours : plus basse moyenne sur 30 min de la journee, gardee jour par jour
            if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
              const FICHIER = 'mark43_repos.json';
              const barres = [];
              for (let k = 0; k < 7; k++) {
                barres.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                  x: Math.round(128 + k * 32.5), y: 404 - 14, w: 30, h: 14, radius: 6, color: 0x6A6882,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                }));
              }
              const moyenne = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                x: 328, y: 348, font_array: ['a_0.png', 'a_1.png', 'a_2.png', 'a_3.png', 'a_4.png', 'a_5.png', 'a_6.png', 'a_7.png', 'a_8.png', 'a_9.png'], h_space: -3, align_h: hmUI.align.LEFT, text: '',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              let coeur = null;
              let horloge = null;
              try {
                coeur = hmSensor.createSensor(hmSensor.id.HEART);
                horloge = hmSensor.createSensor(hmSensor.id.TIME);
              } catch (e) {}
              const lire = () => {
                try {
                  const [st, err] = hmFS.stat(FICHIER);
                  if (err != 0) return {};
                  const buf = new ArrayBuffer(st.size);
                  const fd = hmFS.open(FICHIER, hmFS.O_RDONLY);
                  hmFS.read(fd, buf, 0, st.size);
                  hmFS.close(fd);
                  return JSON.parse(String.fromCharCode.apply(null, new Uint8Array(buf)));
                } catch (e) {
                  return {};
                }
              };
              const garder = (o) => {
                try {
                  const s = JSON.stringify(o);
                  const buf = new ArrayBuffer(s.length);
                  const v = new Uint8Array(buf);
                  for (let i = 0; i < s.length; i++) v[i] = s.charCodeAt(i);
                  const fd = hmFS.open(FICHIER, hmFS.O_WRONLY | hmFS.O_CREAT | hmFS.O_TRUNC);
                  hmFS.write(fd, buf, 0, s.length);
                  hmFS.close(fd);
                } catch (e) {}
              };
              const reposDuJour = () => {
                const t = coeur ? coeur.today : null;
                if (!t || !t.length) return 0;
                let somme = 0;
                let n = 0;
                let mini = 0;
                for (let i = 0; i < t.length; i++) {
                  if (t[i] > 0) { somme += t[i]; n++; }
                  if (i >= 30 && t[i - 30] > 0) { somme -= t[i - 30]; n--; }
                  if (i >= 29 && n >= 20 && (!mini || somme / n < mini)) mini = somme / n;
                }
                return Math.round(mini);
              };
              const cle = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
              const jour = (k) => {
                const d = horloge ? new Date(horloge.year, horloge.month - 1, horloge.day) : new Date();
                return cle(new Date(d.getFullYear(), d.getMonth(), d.getDate() - k));
              };
              const maj = () => {
                let memo = lire();
                const r = reposDuJour();
                if (r && memo[jour(0)] !== r) {
                  memo[jour(0)] = r;
                  const garde = {};
                  for (let k = 0; k < 7; k++) if (memo[jour(k)]) garde[jour(k)] = memo[jour(k)];
                  memo = garde;
                  garder(memo);
                }
                const v = [];
                for (let k = 6; k >= 0; k--) v.push(memo[jour(k)] || 0);
                const connues = v.filter((x) => x > 0);
                const bas = Math.min(...connues);
                const haut = Math.max(...connues);
                for (let k = 0; k < 7; k++) {
                  const t = haut > bas ? (v[k] - bas) / (haut - bas) : 0.5;
                  const h = v[k] ? Math.round(14 + t * (34 - 14)) : 14;
                  barres[k].setProperty(hmUI.prop.MORE, {
                    x: Math.round(128 + k * 32.5), y: 404 - h, w: 30, h: h, radius: 6,
                    color: !v[k] ? 0x6A6882 : k == 6 ? 0xFAF8FC : teinte.c,
                  });
                }
                const somme = connues.reduce((a, b) => a + b, 0);
                moyenne.setProperty(hmUI.prop.TEXT, connues.length ? String(Math.round(somme / connues.length)) : '');
              };
              let minuterie = null;
              const reprendre = () => {
                maj();
                if (minuterie === null) minuterie = timer.createTimer(600000, 600000, maj, {});
              };
              const arreter = () => {
                if (minuterie !== null) timer.stopTimer(minuterie);
                minuterie = null;
              };
              reprendre();
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: reprendre, pause_call: arreter });
            }


            // anneau des minutes de combustion des graisses, plein a l'objectif
            if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
              const anneauGraisses = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                center_x: 96, center_y: 290, radius: 50, start_angle: 0, end_angle: 360, line_width: 9,
                corner_flag: 3, color: teinte.c, level: 0, show_level: hmUI.show_level.ONLY_NORMAL,
              });
              let graisses = null;
              try {
                graisses = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
              } catch (e) {}
              const majGraisses = () => {
                const part = graisses && graisses.target ? Math.min(1, graisses.current / graisses.target) : 0;
                anneauGraisses.setProperty(hmUI.prop.MORE, {
                  center_x: 96, center_y: 290, radius: 50, start_angle: 0, end_angle: 360, line_width: 9,
                  corner_flag: 3, color: teinte.c, level: Math.round(part * 100),
                });
              };
              majGraisses();
              try {
                graisses.addEventListener(hmSensor.event.CHANGE, majGraisses);
              } catch (e) {}
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: majGraisses });
              // jauge de la VFC : une image par ms, niveau borne entre 20 et 120 ms
              const jaugeVfc = [];
              for (let v = 1; v <= 200; v++) {
                jaugeVfc.push(teinte.vfc[Math.max(0, Math.min(30, Math.round((v - 20) / (120 - 20) * 30)))]);
              }
              hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                x: 41, y: 119, image_array: jaugeVfc, image_length: 200, type: hmUI.data_type.HRV,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            }

            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 218,
              src: 'aod_fixe.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 128,
              week_en: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              week_tc: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              week_sc: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 224,
              day_startY: 126,
              day_sc_array: ["ad_0.png","ad_1.png","ad_2.png","ad_3.png","ad_4.png","ad_5.png","ad_6.png","ad_7.png","ad_8.png","ad_9.png"],
              day_tc_array: ["ad_0.png","ad_1.png","ad_2.png","ad_3.png","ad_4.png","ad_5.png","ad_6.png","ad_7.png","ad_8.png","ad_9.png"],
              day_en_array: ["ad_0.png","ad_1.png","ad_2.png","ad_3.png","ad_4.png","ad_5.png","ad_6.png","ad_7.png","ad_8.png","ad_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 123,
              month_sc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_tc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_en_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 363,
              font_array: ["ab_0.png","ab_1.png","ab_2.png","ab_3.png","ab_4.png","ab_5.png","ab_6.png","ab_7.png","ab_8.png","ab_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'ab_pct.png',
              unit_tc: 'ab_pct.png',
              unit_en: 'ab_pct.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 201,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 249,
              minute_startY: 201,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 262,
              w: 290,
              h: 32,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 299,
              w: 267,
              h: 43,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 219,
              w: 264,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 184,
              y: 420,
              w: 123,
              h: 51,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 79,
              w: 89,
              h: 34,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 116,
              w: 120,
              h: 96,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 116,
              w: 131,
              h: 99,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 236,
              w: 124,
              h: 109,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 153,
              y: 23,
              w: 170,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 116,
              w: 116,
              h: 110,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 209;
                  let start_y_normal_heart_rate = 235;
                  let lenght_ls_normal_heart_rate = 144;
                  let line_width_ls_normal_heart_rate = 6;
                  let color_ls_normal_heart_rate = teinte.c;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    radius: 3,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_heart_rate = 4;
                  let pointer_offset_y_ls_normal_heart_rate = 9;
                  normal_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate + lenght_ls_normal_heart_rate - pointer_offset_x_ls_normal_heart_rate,
                    y: start_y_normal_heart_rate_draw + line_width_ls_normal_heart_rate / 2 - pointer_offset_y_ls_normal_heart_rate,
                    src: 'curseur.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 209;
                  let start_y_normal_step = 275;
                  let lenght_ls_normal_step = 144;
                  let line_width_ls_normal_step = 6;
                  let color_ls_normal_step = teinte.c;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 3,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 4;
                  let pointer_offset_y_ls_normal_step = 9;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'curseur.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 209;
                  let start_y_normal_calorie = 315;
                  let lenght_ls_normal_calorie = 144;
                  let line_width_ls_normal_calorie = 6;
                  let color_ls_normal_calorie = teinte.c;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    radius: 3,
                    color: color_ls_normal_calorie,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_calorie = 4;
                  let pointer_offset_y_ls_normal_calorie = 9;
                  normal_calorie_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie + lenght_ls_normal_calorie - pointer_offset_x_ls_normal_calorie,
                    y: start_y_normal_calorie_draw + line_width_ls_normal_calorie / 2 - pointer_offset_y_ls_normal_calorie,
                    src: 'curseur.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}