﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 274;
        let normal_timerTextUpdate = undefined;
        let normal_digital_clock_img_time_hour = ''
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 95;
        let normal_digital_clock_img_time_minute = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_TextRotate = new Array(2);
        let normal_day_TextRotate_ASCIIARRAY = new Array(10);
        let normal_day_TextRotate_img_width = 25;
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 274;
        let idle_timerTextUpdate = undefined;
        let idle_digital_clock_img_time_hour = ''
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 95;
        let idle_digital_clock_img_time_minute = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_day_TextRotate = new Array(2);
        let idle_day_TextRotate_ASCIIARRAY = new Array(10);
        let idle_day_TextRotate_img_width = 25;
        let idle_battery_text_text_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond_en_lime.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });
            // palette de la zone plein ecran ; en AOD la zone ne repond pas : dernier choix garde
            const editCouleur = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10045,
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100451,
              optional_types: [
                { type: 100451, preview: 'prev_lime.png', title_sc: '青柠', title_tc: '青檸', title_en: 'Lime' },
                { type: 100452, preview: 'prev_cyan.png', title_sc: '青色', title_tc: '青色', title_en: 'Cyan' },
                { type: 100453, preview: 'prev_rose.png', title_sc: '粉色', title_tc: '粉色', title_en: 'Pink' },
                { type: 100454, preview: 'prev_orange.png', title_sc: '橙色', title_tc: '橙色', title_en: 'Orange' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: 165,
              tips_y: 418,
              tips_width: 150,
              tips_margin: 10,
            });
            let couleurType = editCouleur.getProperty(hmUI.prop.CURRENT_TYPE);
            try {
              if (couleurType) hmFS.SysProSetInt('mark45_couleur', couleurType);
              else couleurType = hmFS.SysProGetInt('mark45_couleur');
            } catch (e) {}
            const teinte = { 100451: 'lime', 100452: 'cyan', 100453: 'rose', 100454: 'orange' }[couleurType] || 'lime';
            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0, y: 0, w: 480, h: 480, src: 'fond_en_' + teinte + '.png',
            });


            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 381,
              am_y: 178,
              am_sc_path: 'ampm_am.png',
              am_en_path: 'ampm_am.png',
              pm_x: 381,
              pm_y: 178,
              pm_sc_path: 'ampm_pm.png',
              pm_en_path: 'ampm_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 41,
              // y: 68,
              // font_array: ["hd_0.png","hd_1.png","hd_2.png","hd_3.png","hd_4.png","hd_5.png","hd_6.png","hd_7.png","hd_8.png","hd_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 480,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'hd_0.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'hd_1.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'hd_2.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'hd_3.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'hd_4.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'hd_5.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'hd_6.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'hd_7.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'hd_8.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'hd_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 41,
                center_y: 68,
                pos_x: 41,
                pos_y: 68,
                angle: 0,
                src: 'hd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -284,
              hour_startY: 103,
              hour_array: ["hu_" + teinte + "_0.png","hu_" + teinte + "_1.png","hu_" + teinte + "_2.png","hu_" + teinte + "_3.png","hu_" + teinte + "_4.png","hu_" + teinte + "_5.png","hu_" + teinte + "_6.png","hu_" + teinte + "_7.png","hu_" + teinte + "_8.png","hu_" + teinte + "_9.png"],
              hour_zero: 1,
              hour_space: 174,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 290,
              // y: 46,
              // font_array: ["md_" + teinte + "_0.png","md_" + teinte + "_1.png","md_" + teinte + "_2.png","md_" + teinte + "_3.png","md_" + teinte + "_4.png","md_" + teinte + "_5.png","md_" + teinte + "_6.png","md_" + teinte + "_7.png","md_" + teinte + "_8.png","md_" + teinte + "_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 480,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'md_' + teinte + '_0.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'md_' + teinte + '_1.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'md_' + teinte + '_2.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'md_' + teinte + '_3.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'md_' + teinte + '_4.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'md_' + teinte + '_5.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'md_' + teinte + '_6.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'md_' + teinte + '_7.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'md_' + teinte + '_8.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'md_' + teinte + '_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 290,
                center_y: 46,
                pos_x: 290,
                pos_y: 46,
                angle: 0,
                src: 'md_' + teinte + '_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -105,
              minute_startY: 74,
              minute_array: ["mu_" + teinte + "_0.png","mu_" + teinte + "_1.png","mu_" + teinte + "_2.png","mu_" + teinte + "_3.png","mu_" + teinte + "_4.png","mu_" + teinte + "_5.png","mu_" + teinte + "_6.png","mu_" + teinte + "_7.png","mu_" + teinte + "_8.png","mu_" + teinte + "_9.png"],
              minute_zero: 1,
              minute_space: 337,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 34,
              src: 'pilule_' + teinte + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 65,
              y: 86,
              week_en: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_tc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_sc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 145,
              // y: 140,
              // font_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -7,
              // angle: 43,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextRotate_ASCIIARRAY[0] = 'd_0.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[1] = 'd_1.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[2] = 'd_2.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[3] = 'd_3.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[4] = 'd_4.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[5] = 'd_5.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[6] = 'd_6.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[7] = 'd_7.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[8] = 'd_8.png';  // set of images with numbers
            normal_day_TextRotate_ASCIIARRAY[9] = 'd_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              normal_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 145,
                center_y: 140,
                pos_x: 145,
                pos_y: 140,
                angle: 43,
                src: 'd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              w: 48,
              y: 390,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 233,
              y: 424,
              font_array: ["p_0.png","p_1.png","p_2.png","p_3.png","p_4.png","p_5.png","p_6.png","p_7.png","p_8.png","p_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 62,
              y: 193,
              src: 'alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 381,
              am_y: 178,
              am_sc_path: 'aod_ampm_am.png',
              am_en_path: 'aod_ampm_am.png',
              pm_x: 381,
              pm_y: 178,
              pm_sc_path: 'aod_ampm_pm.png',
              pm_en_path: 'aod_ampm_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 41,
              // y: 68,
              // font_array: ["aod_hd_0.png","aod_hd_1.png","aod_hd_2.png","aod_hd_3.png","aod_hd_4.png","aod_hd_5.png","aod_hd_6.png","aod_hd_7.png","aod_hd_8.png","aod_hd_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 480,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'aod_hd_0.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'aod_hd_1.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'aod_hd_2.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'aod_hd_3.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'aod_hd_4.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'aod_hd_5.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'aod_hd_6.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'aod_hd_7.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'aod_hd_8.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'aod_hd_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 41,
                center_y: 68,
                pos_x: 41,
                pos_y: 68,
                angle: 0,
                src: 'aod_hd_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -284,
              hour_startY: 103,
              hour_array: ["aod_hu_" + teinte + "_0.png","aod_hu_" + teinte + "_1.png","aod_hu_" + teinte + "_2.png","aod_hu_" + teinte + "_3.png","aod_hu_" + teinte + "_4.png","aod_hu_" + teinte + "_5.png","aod_hu_" + teinte + "_6.png","aod_hu_" + teinte + "_7.png","aod_hu_" + teinte + "_8.png","aod_hu_" + teinte + "_9.png"],
              hour_zero: 1,
              hour_space: 174,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 290,
              // y: 46,
              // font_array: ["aod_md_" + teinte + "_0.png","aod_md_" + teinte + "_1.png","aod_md_" + teinte + "_2.png","aod_md_" + teinte + "_3.png","aod_md_" + teinte + "_4.png","aod_md_" + teinte + "_5.png","aod_md_" + teinte + "_6.png","aod_md_" + teinte + "_7.png","aod_md_" + teinte + "_8.png","aod_md_" + teinte + "_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 480,
              // angle: 0,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'aod_md_' + teinte + '_0.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'aod_md_' + teinte + '_1.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'aod_md_' + teinte + '_2.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'aod_md_' + teinte + '_3.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'aod_md_' + teinte + '_4.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'aod_md_' + teinte + '_5.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'aod_md_' + teinte + '_6.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'aod_md_' + teinte + '_7.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'aod_md_' + teinte + '_8.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'aod_md_' + teinte + '_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 290,
                center_y: 46,
                pos_x: 290,
                pos_y: 46,
                angle: 0,
                src: 'aod_md_' + teinte + '_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -105,
              minute_startY: 74,
              minute_array: ["aod_mu_" + teinte + "_0.png","aod_mu_" + teinte + "_1.png","aod_mu_" + teinte + "_2.png","aod_mu_" + teinte + "_3.png","aod_mu_" + teinte + "_4.png","aod_mu_" + teinte + "_5.png","aod_mu_" + teinte + "_6.png","aod_mu_" + teinte + "_7.png","aod_mu_" + teinte + "_8.png","aod_mu_" + teinte + "_9.png"],
              minute_zero: 1,
              minute_space: 337,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_calque_' + teinte + '.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 65,
              y: 86,
              week_en: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_tc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              week_sc: ["sem_en_01.png","sem_en_02.png","sem_en_03.png","sem_en_04.png","sem_en_05.png","sem_en_06.png","sem_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 145,
              // y: 140,
              // font_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -7,
              // angle: 43,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextRotate_ASCIIARRAY[0] = 'd_0.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[1] = 'd_1.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[2] = 'd_2.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[3] = 'd_3.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[4] = 'd_4.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[5] = 'd_5.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[6] = 'd_6.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[7] = 'd_7.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[8] = 'd_8.png';  // set of images with numbers
            idle_day_TextRotate_ASCIIARRAY[9] = 'd_9.png';  // set of images with numbers

            //#region TextRotate
            for (let i = 0; i < 2; i++) {
              idle_day_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 145,
                center_y: 140,
                pos_x: 145,
                pos_y: 140,
                angle: 43,
                src: 'd_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              w: 48,
              y: 390,
              font_array: ["ab_0.png","ab_1.png","ab_2.png","ab_3.png","ab_4.png","ab_5.png","ab_6.png","ab_7.png","ab_8.png","ab_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 164,
              y: 413,
              w: 180,
              h: 63,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 360,
              w: 77,
              h: 86,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 54,
              w: 136,
              h: 117,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 185,
              w: 196,
              h: 157,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 96,
              w: 88,
              h: 88,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate hour_TIME');
              let valueHour = timeSensor.format_hour;
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 41 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + 480;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeSensor.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 290 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + 480;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_rotate_string = parseInt(valueDay).toString();
              normal_day_rotate_string = normal_day_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_rotate_string.length > 0 && normal_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 145 + img_offset);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.SRC, normal_day_TextRotate_ASCIIARRAY[charCode]);
                      normal_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_day_TextRotate_img_width + -7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 41 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + 480;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 290 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + 480;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate day_TIME');
              let idle_day_rotate_string = parseInt(valueDay).toString();
              idle_day_rotate_string = idle_day_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_rotate_string.length > 0 && idle_day_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_day_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_day_TextRotate[index].setProperty(hmUI.prop.POS_X, 145 + img_offset);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.SRC, idle_day_TextRotate_ASCIIARRAY[charCode]);
                      idle_day_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_day_TextRotate_img_width + -7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}