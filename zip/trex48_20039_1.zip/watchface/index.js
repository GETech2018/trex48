﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_bio_charge_text_text_img = ''
        let normal_stress_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_hrv_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

            // mark46 : marches des pas et anneau des calories bornes, date centree, courbe FC 2 h
            const mk46Normal = hmSetting.getScreenType() != hmSetting.screen_type.AOD;
            const mk46Capteurs = {};
            const mk46Maj = [];
            const mk46Capteur = (id) => {
              if (!(id in mk46Capteurs)) {
                try {
                  mk46Capteurs[id] = hmSensor.createSensor(hmSensor.id[id]);
                } catch (e) {
                  mk46Capteurs[id] = null;
                }
              }
              return mk46Capteurs[id];
            };
            const mk46Image = (x, y, src) => hmUI.createWidget(hmUI.widget.IMG, {
              x: x, y: y, src: src, show_level: mk46Normal ? hmUI.show_level.ONLY_NORMAL : hmUI.show_level.ONLY_AOD,
            });
            const mk46Chiffres = (n, y, prefixe) => {
              const l = [];
              for (let i = 0; i < n; i++) l.push(mk46Image(0, y, prefixe + '_0.png'));
              return l;
            };
            const mk46Ecrire = (l, texte, x, y, prefixe, cas, esp) => {
              // texte en cases fixes depuis x ; les cases en trop disparaissent
              for (let i = 0; i < l.length; i++) {
                const c = texte[i];
                l[i].setProperty(hmUI.prop.VISIBLE, c !== undefined);
                if (c !== undefined) l[i].setProperty(hmUI.prop.MORE, { x: x + i * (cas + esp), y: y, src: prefixe + '_' + c + '.png' });
              }
            };
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond_en.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (mk46Normal) {
              // 7 marches de l'objectif de pas ; au-dela de l'objectif la jauge native n'affiche plus rien
              const mk46Barres = mk46Image(43, 118, 'barres_0.png');
              mk46Maj.push(() => {
                const c = mk46Capteur('STEP');
                let k = 0;
                try {
                  if (c && c.target > 0) k = Math.max(0, Math.min(7, Math.floor(7 * c.current / c.target)));
                } catch (e) {}
                mk46Barres.setProperty(hmUI.prop.SRC, 'barres_' + k + '.png');
              });
            }

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 60,
              w: 76,
              y: 84,
              font_array: ["a_0.png","a_1.png","a_2.png","a_3.png","a_4.png","a_5.png","a_6.png","a_7.png","a_8.png","a_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'a_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 82,
              image_array: ["hc_100.png","hc_101.png","hc_102.png","hc_103.png","hc_104.png","hc_105.png","hc_106.png","hc_107.png","hc_108.png","hc_109.png","hc_110.png","hc_111.png","hc_112.png","hc_113.png","hc_114.png","hc_115.png","hc_116.png","hc_117.png","hc_118.png","hc_119.png","hc_120.png","hc_121.png","hc_122.png","hc_123.png","hc_124.png","hc_125.png","hc_126.png","hc_127.png","hc_128.png","hc_129.png","hc_130.png","hc_131.png","hc_132.png","hc_133.png","hc_134.png","hc_135.png","hc_136.png","hc_137.png","hc_138.png","hc_139.png","hc_140.png","hc_141.png","hc_142.png","hc_143.png","hc_144.png","hc_145.png","hc_146.png","hc_147.png","hc_148.png","hc_149.png","hc_150.png","hc_151.png","hc_152.png","hc_153.png","hc_154.png","hc_155.png","hc_156.png","hc_157.png","hc_158.png","hc_159.png","hc_160.png","hc_161.png","hc_162.png","hc_163.png","hc_164.png","hc_165.png","hc_166.png","hc_167.png","hc_168.png","hc_169.png","hc_170.png","hc_171.png","hc_172.png","hc_173.png","hc_174.png","hc_175.png","hc_176.png","hc_177.png","hc_178.png","hc_179.png","hc_180.png","hc_181.png","hc_182.png","hc_183.png","hc_184.png","hc_185.png","hc_186.png","hc_187.png","hc_188.png","hc_189.png","hc_190.png","hc_191.png","hc_192.png","hc_193.png","hc_194.png","hc_195.png","hc_196.png","hc_197.png","hc_198.png","hc_199.png"],
              image_length: 100,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              w: 46,
              y: 107,
              font_array: ["a_0.png","a_1.png","a_2.png","a_3.png","a_4.png","a_5.png","a_6.png","a_7.png","a_8.png","a_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'a_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 340,
              y: 82,
              image_array: ["st_100.png","st_101.png","st_102.png","st_103.png","st_104.png","st_105.png","st_106.png","st_107.png","st_108.png","st_109.png","st_110.png","st_111.png","st_112.png","st_113.png","st_114.png","st_115.png","st_116.png","st_117.png","st_118.png","st_119.png","st_120.png","st_121.png","st_122.png","st_123.png","st_124.png","st_125.png","st_126.png","st_127.png","st_128.png","st_129.png","st_130.png","st_131.png","st_132.png","st_133.png","st_134.png","st_135.png","st_136.png","st_137.png","st_138.png","st_139.png","st_140.png","st_141.png","st_142.png","st_143.png","st_144.png","st_145.png","st_146.png","st_147.png","st_148.png","st_149.png","st_150.png","st_151.png","st_152.png","st_153.png","st_154.png","st_155.png","st_156.png","st_157.png","st_158.png","st_159.png","st_160.png","st_161.png","st_162.png","st_163.png","st_164.png","st_165.png","st_166.png","st_167.png","st_168.png","st_169.png","st_170.png","st_171.png","st_172.png","st_173.png","st_174.png","st_175.png","st_176.png","st_177.png","st_178.png","st_179.png","st_180.png","st_181.png","st_182.png","st_183.png","st_184.png","st_185.png","st_186.png","st_187.png","st_188.png","st_189.png","st_190.png","st_191.png","st_192.png","st_193.png","st_194.png","st_195.png","st_196.png","st_197.png","st_198.png","st_199.png"],
              image_length: 100,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              w: 46,
              y: 107,
              font_array: ["a_0.png","a_1.png","a_2.png","a_3.png","a_4.png","a_5.png","a_6.png","a_7.png","a_8.png","a_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'a_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              w: 52,
              y: 206,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'b_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 280,
              font_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'c_null.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              w: 35,
              y: 385,
              font_array: ["b_0.png","b_1.png","b_2.png","b_3.png","b_4.png","b_5.png","b_6.png","b_7.png","b_8.png","b_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'b_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (mk46Normal) {
              // calories du jour, anneau plein a l'objectif
              const mk46Kcal = mk46Image(296, 280, 'kcal_00.png');
              mk46Maj.push(() => {
                const c = mk46Capteur('CALORIE');
                let k = 0;
                try {
                  if (c && c.target > 0) k = Math.round(Math.max(0, Math.min(1, c.current / c.target)) * 48);
                } catch (e) {}
                mk46Kcal.setProperty(hmUI.prop.SRC, 'kcal_' + (k < 10 ? '0' : '') + k + '.png');
              });
            }

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              w: 85,
              y: 315,
              font_array: ["k_0.png","k_1.png","k_2.png","k_3.png","k_4.png","k_5.png","k_6.png","k_7.png","k_8.png","k_9.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'k_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 248,
              y: 7,
              image_array: ["meteo_01.png","meteo_02.png","meteo_03.png","meteo_04.png","meteo_05.png","meteo_06.png","meteo_07.png","meteo_08.png","meteo_09.png","meteo_10.png","meteo_11.png","meteo_12.png","meteo_13.png","meteo_14.png","meteo_15.png","meteo_16.png","meteo_17.png","meteo_18.png","meteo_19.png","meteo_20.png","meteo_21.png","meteo_22.png","meteo_23.png","meteo_24.png","meteo_25.png","meteo_26.png","meteo_27.png","meteo_28.png","meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              w: 73,
              y: 17,
              font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 't_degc.png',
              unit_tc: 't_degc.png',
              unit_en: 't_degc.png',
              imperial_unit_sc: 't_degf.png',
              imperial_unit_tc: 't_degf.png',
              imperial_unit_en: 't_degf.png',
              negative_image: 't_moins.png',
              invalid_image: 't_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 178,
                y: 17,
                font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
                padding: false,
                h_space: -1,
                unit_sc: 't_degf.png',
                unit_tc: 't_degf.png',
                unit_en: 't_degf.png',
                imperial_unit_sc: 't_degc.png',
                imperial_unit_tc: 't_degc.png',
                imperial_unit_en: 't_degc.png',
                negative_image: 't_moins.png',
                invalid_image: 't_null.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 432,
              image_array: ["pile_0.png","pile_1.png","pile_2.png","pile_3.png","pile_4.png","pile_5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              w: 68,
              y: 428,
              font_array: ["a_0.png","a_1.png","a_2.png","a_3.png","a_4.png","a_5.png","a_6.png","a_7.png","a_8.png","a_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'a_pct.png',
              unit_tc: 'a_pct.png',
              unit_en: 'a_pct.png',
              imperial_unit_sc: 'a_pct.png',
              imperial_unit_tc: 'a_pct.png',
              imperial_unit_en: 'a_pct.png',
              invalid_image: 'a_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (mk46Normal) {
              // jour, quantieme et mois centres ensemble : la largeur du mois change la ligne entiere
              const mk46Sem = mk46Image(0, 46, 'sem_en_01.png');
              const mk46Jour = mk46Chiffres(2, 43, 'd');
              const mk46Mois = mk46Image(0, 46, 'mois_en_01.png');
              const mk46LargSem = [48.5, 42.75, 52.0, 44.0, 29.25, 38.25, 46.0];
              const mk46LargMois = [44.0, 42.25, 43.75, 43.0, 47.75, 45.25, 36.25, 46.75, 44.75, 38.0, 45.75, 43.25];
              const mk46EncreJour = {"0": 16.75, "1": 11.0, "2": 16.5, "3": 16.25, "4": 18.25, "5": 16.75, "6": 17.25, "7": 16.0, "8": 16.75, "9": 17.25};
              mk46Maj.push(() => {
                const t = mk46Capteur('TIME');
                if (!t) return;
                const s = Math.max(1, Math.min(7, t.week));
                const m = Math.max(1, Math.min(12, t.month));
                const j = (t.day < 10 ? '0' : '') + t.day;
                const ws = mk46LargSem[s - 1];
                const wm = mk46LargMois[m - 1];
                const g0 = (21 - mk46EncreJour[j[0]]) / 2;
                const g1 = (21 - mk46EncreJour[j[1]]) / 2;
                const wd = 2 * 21 + -1 - g0 - g1;
                const x = 240.0 - (ws + 8.75 + wd + 8.75 + wm) / 2;
                mk46Sem.setProperty(hmUI.prop.MORE, { x: Math.round(x - (56 - 1 - ws)), y: 46, src: 'sem_en_0' + s + '.png' });
                mk46Ecrire(mk46Jour, j, Math.round(x + ws + 8.75 - g0), 43, 'd', 21, -1);
                mk46Mois.setProperty(hmUI.prop.MORE, {
                  x: Math.round(x + ws + 8.75 + wd + 8.75 - 1), y: 46, src: 'mois_en_' + (m < 10 ? '0' : '') + m + '.png',
                });
              });
            }



            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 217,
              am_y: 258,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 217,
              pm_y: 258,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 182,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 182,
              minute_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 374,
              second_startY: 202,
              second_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            if (mk46Normal) {
              // FC des 2 dernieres heures : 3 rangees de 20 bpm (plus si la plage deborde), haut au multiple
              // du pas ; reperes du haut et de la 2e ligne, maximum de la periode
              const mk46Courbe = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
                x: 43, y: 306, w: 157, h: 42, line_color: 0xFF5CA0, line_width: 2, show_level: hmUI.show_level.ONLY_NORMAL,
              });
              const mk46Haut = mk46Chiffres(3, 299, 'f');
              const mk46Bas = mk46Chiffres(3, 327, 'f');
              const mk46Max = mk46Chiffres(3, 374, 'e');
              const mk46MaxVide = mk46Image(104, 374, 'e_null.png');
              const mk46Centre = (l, v, y) => {
                const t = String(v);
                const w = t.length * 12 + (t.length - 1) * -1;
                mk46Ecrire(l, t, Math.round(218.25 - w / 2), y, 'f', 12, -1);
              };
              mk46Maj.push(() => {
                const c = mk46Capteur('HEART');
                let t = null;
                try {
                  t = c ? c.today : null;
                } catch (e) {}
                const pts = [];
                if (t && t.length) {
                  for (let i = Math.max(0, t.length - 120); i < t.length; i++) {
                    if (t[i] > 0) pts.push([i - (t.length - 120), t[i]]);
                  }
                }
                let bas = 300;
                let haut = 0;
                for (const p of pts) {
                  bas = Math.min(bas, p[1]);
                  haut = Math.max(haut, p[1]);
                }
                let pas = 20;
                let sommet = 120;
                if (pts.length) {
                  for (;;) {
                    sommet = Math.ceil((haut + 2) / pas) * pas;
                    if (sommet - 3 * pas <= bas - 2) break;
                    pas += 10;
                  }
                }
                mk46Centre(mk46Haut, sommet, 299);
                mk46Centre(mk46Bas, sommet - 2 * pas, 327);
                mk46Courbe.clear();
                if (pts.length > 1) {
                  const data = pts.map((p) => ({
                    x: Math.round(p[0] * 157 / 119),
                    y: Math.round(42 - (p[1] - (sommet - 3 * pas)) / (3 * pas) * 42),
                  }));
                  mk46Courbe.addLine({ data: data, count: data.length });
                }
                const mt = pts.length ? String(Math.round(haut)) : '';
                const w = mt.length * 17 + Math.max(0, mt.length - 1) * -1;
                mk46Ecrire(mk46Max, mt, 136 - w, 374, 'e', 17, -1);
                mk46MaxVide.setProperty(hmUI.prop.VISIBLE, !pts.length);
              });
            }

            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 225,
              src: 'aod_fixe.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 162,
              y: 116,
              week_en: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              week_tc: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              week_sc: ["aod_sem_en_01.png","aod_sem_en_02.png","aod_sem_en_03.png","aod_sem_en_04.png","aod_sem_en_05.png","aod_sem_en_06.png","aod_sem_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 223,
              day_startY: 113,
              day_sc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_tc_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_en_array: ["aod_d_0.png","aod_d_1.png","aod_d_2.png","aod_d_3.png","aod_d_4.png","aod_d_5.png","aod_d_6.png","aod_d_7.png","aod_d_8.png","aod_d_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 270,
              month_startY: 116,
              month_sc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_tc_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_en_array: ["aod_mois_en_01.png","aod_mois_en_02.png","aod_mois_en_03.png","aod_mois_en_04.png","aod_mois_en_05.png","aod_mois_en_06.png","aod_mois_en_07.png","aod_mois_en_08.png","aod_mois_en_09.png","aod_mois_en_10.png","aod_mois_en_11.png","aod_mois_en_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 432,
              image_array: ["aod_pile_0.png","aod_pile_1.png","aod_pile_2.png","aod_pile_3.png","aod_pile_4.png","aod_pile_5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              w: 68,
              y: 428,
              font_array: ["aod_a_0.png","aod_a_1.png","aod_a_2.png","aod_a_3.png","aod_a_4.png","aod_a_5.png","aod_a_6.png","aod_a_7.png","aod_a_8.png","aod_a_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'aod_a_pct.png',
              unit_tc: 'aod_a_pct.png',
              unit_en: 'aod_a_pct.png',
              imperial_unit_sc: 'aod_a_pct.png',
              imperial_unit_tc: 'aod_a_pct.png',
              imperial_unit_en: 'aod_a_pct.png',
              invalid_image: 'aod_a_null.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 217,
              am_y: 298,
              am_sc_path: 'aod_am.png',
              am_en_path: 'aod_am.png',
              pm_x: 217,
              pm_y: 298,
              pm_sc_path: 'aod_pm.png',
              pm_en_path: 'aod_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 212,
              hour_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 212,
              minute_array: ["aod_h_0.png","aod_h_1.png","aod_h_2.png","aod_h_3.png","aod_h_4.png","aod_h_5.png","aod_h_6.png","aod_h_7.png","aod_h_8.png","aod_h_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            // mark46 : mise a jour a chaque minute et au reveil ; ecran eteint : minuteur d'une seconde
            // comme l'editeur, le travail n'est refait qu'au changement de minute
            const mk46Tout = () => {
              for (const f of mk46Maj) {
                try {
                  f();
                } catch (e) {}
              }
            };
            const mk46Temps = mk46Capteur('TIME');
            mk46Tout();
            if (mk46Normal) {
              try {
                if (mk46Temps) mk46Temps.addEventListener(mk46Temps.event.MINUTEEND, mk46Tout);
              } catch (e) {}
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: mk46Tout });
            } else if (mk46Maj.length) {
              let mk46Minute = -1;
              let mk46Minuteur = null;
              const mk46Tic = () => {
                const m = mk46Temps ? mk46Temps.hour * 60 + mk46Temps.minute : -1;
                if (m !== mk46Minute) {
                  mk46Minute = m;
                  mk46Tout();
                }
              };
              const mk46Lancer = () => {
                mk46Tic();
                if (!mk46Minuteur) mk46Minuteur = timer.createTimer(0, 1000, mk46Tic);
              };
              mk46Lancer();
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: mk46Lancer,
                pause_call: () => {
                  if (mk46Minuteur) timer.stopTimer(mk46Minuteur);
                  mk46Minuteur = null;
                },
              });
            }

            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 78,
              w: 206,
              h: 88,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 276,
              w: 120,
              h: 120,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 272,
              w: 200,
              h: 128,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 414,
              w: 124,
              h: 52,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 4,
              w: 140,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 342,
              y: 84,
              w: 88,
              h: 80,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 176,
              w: 128,
              h: 82,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 176,
              w: 128,
              h: 82,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 120,
              y: 42,
              w: 240,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 84,
              w: 90,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 196,
              w: 78,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1047865, url: 'page/round/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}