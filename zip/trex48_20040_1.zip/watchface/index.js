﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // couleur choisie dans la zone modifiable posee sur l'heure : prefixe des images de la palette ;
            // zone creee apres le fond, sinon il recouvre son apercu en mode edition
            hmUI.createWidget(hmUI.widget.IMG, {
              x: 0, y: 0, w: 480, h: 480, src: 'edit_fond.png', show_level: hmUI.show_level.ONLY_EDIT,
            });
            const couleurZone = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10047,
              x: 34,
              y: 58,
              w: 412,
              h: 150,
              select_image: 'coul_on.png',
              un_select_image: 'coul_off.png',
              default_type: 100101,
              optional_types: [
                { type: 100101, preview: 'coul_rouge.png', title_sc: '红色', title_tc: '紅色', title_en: 'Red' },
                { type: 100102, preview: 'coul_bleu.png', title_sc: '蓝色', title_tc: '藍色', title_en: 'Blue' },
                { type: 100103, preview: 'coul_lime.png', title_sc: '青柠', title_tc: '青檸', title_en: 'Lime' },
                { type: 100104, preview: 'coul_lavande.png', title_sc: '薰衣草', title_tc: '薰衣草', title_en: 'Lavender' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'coul_tips.png',
              tips_x: 106,
              tips_y: 156,
              tips_width: 200,
              tips_margin: 10,
            });
            let couleurType = couleurZone.getProperty(hmUI.prop.CURRENT_TYPE);
            // si la zone ne repond pas (AOD), le dernier choix lu par l'ecran normal sert
            try {
              if (couleurType) hmFS.SysProSetInt('mark47_couleur', couleurType);
              else couleurType = hmFS.SysProGetInt('mark47_couleur');
            } catch (e) {}
            const prefixe = { 100101: '', 100102: 'bleu_', 100103: 'lime_', 100104: 'lavande_' }[couleurType] || '';
            const T = (nom) => prefixe + nom;

            // part ecoulee de la minute en blanc sur la piste grise du fond, mise a jour chaque seconde
            if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
              const arcSecondes = {
                center_x: 240, center_y: 269, radius: 44, start_angle: 0, end_angle: 360, line_width: 4,
                corner_flag: 3, color: 0xFFFFFF, show_level: hmUI.show_level.ONLY_NORMAL,
              };
              const arcSec = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, Object.assign({ level: 0 }, arcSecondes));
              let horloge = null;
              try {
                horloge = hmSensor.createSensor(hmSensor.id.TIME);
              } catch (e) {}
              const majSec = () => {
                const s = horloge ? horloge.second || 0 : 0;
                arcSec.setProperty(hmUI.prop.MORE, Object.assign({ level: Math.round(s * 100 / 60) }, arcSecondes));
              };
              let minuterie = null;
              const reprendre = () => {
                majSec();
                if (minuterie === null) minuterie = timer.createTimer(0, 1000, majSec, {});
              };
              const arreter = () => {
                if (minuterie !== null) timer.stopTimer(minuterie);
                minuterie = null;
              };
              reprendre();
              hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, { resume_call: reprendre, pause_call: arreter });
            }

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 51,
              y: 265,
              src: T('anneaux.png'),
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 230,
              y: 19,
              src: 'st_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 17,
              src: 'st_bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 18,
              src: 'st_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 378,
              y: 225,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281, w: 85,
              y: 218,
              font_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'd_pct.png',
              unit_tc: 'd_pct.png',
              unit_en: 'd_pct.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 218,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 135,
              day_startY: 218,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 72,
              hour_array: [T('h_0.png'),T('h_1.png'),T('h_2.png'),T('h_3.png'),T('h_4.png'),T('h_5.png'),T('h_6.png'),T('h_7.png'),T('h_8.png'),T('h_9.png')],
              hour_zero: 1,
              hour_space: -12,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 74,
              minute_array: [T('m_0.png'),T('m_1.png'),T('m_2.png'),T('m_3.png'),T('m_4.png'),T('m_5.png'),T('m_6.png'),T('m_7.png'),T('m_8.png'),T('m_9.png')],
              minute_zero: 1,
              minute_space: -8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 213,
              second_startY: 248,
              second_array: ["s_0.png","s_1.png","s_2.png","s_3.png","s_4.png","s_5.png","s_6.png","s_7.png","s_8.png","s_9.png"],
              second_zero: 1,
              second_space: -3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 291,
              src: 'aod_pile.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 378,
              y: 297,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281, w: 85,
              y: 290,
              font_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'd_pct.png',
              unit_tc: 'd_pct.png',
              unit_en: 'd_pct.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: 290,
              week_en: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_tc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              week_sc: ["day_en_01.png","day_en_02.png","day_en_03.png","day_en_04.png","day_en_05.png","day_en_06.png","day_en_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 135,
              day_startY: 290,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 155,
              hour_array: [T('aod_h_0.png'),T('aod_h_1.png'),T('aod_h_2.png'),T('aod_h_3.png'),T('aod_h_4.png'),T('aod_h_5.png'),T('aod_h_6.png'),T('aod_h_7.png'),T('aod_h_8.png'),T('aod_h_9.png')],
              hour_zero: 1,
              hour_space: -13,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 239,
              minute_startY: 157,
              minute_array: [T('aod_m_0.png'),T('aod_m_1.png'),T('aod_m_2.png'),T('aod_m_3.png'),T('aod_m_4.png'),T('aod_m_5.png'),T('aod_m_6.png'),T('aod_m_7.png'),T('aod_m_8.png'),T('aod_m_9.png')],
              minute_zero: 1,
              minute_space: -9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 51,
              y: 265,
              w: 126,
              h: 126,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100001,
              optional_types: [
                { type: 100001, preview: 'prev_recovery.png', title_sc: '恢复时间', title_tc: '恢復時間', title_en: 'Recovery time' },
                { type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: hmUI.edit_type.CAL, preview: 'prev_calories.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: 100003, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: 100004, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100005, preview: 'prev_altitude.png', title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100006, preview: 'prev_humidity.png', title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100007, preview: 'prev_uvi.png', title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
              ],
              count: 13,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -12,
              tips_y: 8,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 68, w: 91,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 94,
                  y: 286,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 77, w: 73,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 98,
                  y: 290,
                  src: 'ic_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 86, w: 55,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 96,
                  y: 292,
                  src: 'ic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 86, w: 55,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 96,
                  y: 288,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 77, w: 73,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 101,
                  y: 290,
                  src: 'ic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 75, w: 77,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 93,
                  y: 288,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 78, w: 72, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_en_hr.png', unit_tc: 'v_en_hr.png', unit_en: 'v_en_hr.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.RECOVERY_TIME, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 92, y: 288, src: 'ic_recovery.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 95, w: 37, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 94, y: 288, src: 'ic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 86, w: 55, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 96, y: 291, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 77, w: 73, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 94, y: 292, src: 'ic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 77, w: 73, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 92, y: 295, src: 'ic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 75, w: 77, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 100, y: 290, src: 'ic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100007:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 95, w: 37, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 98, y: 288, src: 'ic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 177,
              y: 325,
              w: 126,
              h: 126,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: hmUI.edit_type.CAL, preview: 'prev_calories.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: 100003, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: 100004, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100005, preview: 'prev_altitude.png', title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100006, preview: 'prev_humidity.png', title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100007, preview: 'prev_uvi.png', title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: 100001, preview: 'prev_recovery.png', title_sc: '恢复时间', title_tc: '恢復時間', title_en: 'Recovery time' },
                { type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
              ],
              count: 13,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -12,
              tips_y: 8,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 194, w: 91,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 220,
                  y: 346,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 204, w: 73,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 224,
                  y: 350,
                  src: 'ic_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212, w: 55,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 352,
                  src: 'ic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212, w: 55,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 222,
                  y: 348,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 204, w: 73,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 350,
                  src: 'ic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 202, w: 77,
                  y: 393,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 219,
                  y: 348,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 204, w: 72, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_en_hr.png', unit_tc: 'v_en_hr.png', unit_en: 'v_en_hr.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.RECOVERY_TIME, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 218, y: 348, src: 'ic_recovery.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 222, w: 37, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 220, y: 348, src: 'ic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 212, w: 55, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 222, y: 351, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 204, w: 73, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 220, y: 352, src: 'ic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 204, w: 73, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 218, y: 355, src: 'ic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 202, w: 77, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 226, y: 350, src: 'ic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100007:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 222, w: 37, y: 393, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 224, y: 348, src: 'ic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 303,
              y: 265,
              w: 126,
              h: 126,
              select_image: 'zone_on.png',
              un_select_image: 'zone_off.png',
              default_type: 100002,
              optional_types: [
                { type: 100002, preview: 'prev_vo2max.png', title_sc: '最大摄氧量', title_tc: '最大攝氧量', title_en: 'VO2 max' },
                { type: hmUI.edit_type.STEP, preview: 'prev_step.png' },
                { type: hmUI.edit_type.PAI, preview: 'prev_pai.png' },
                { type: hmUI.edit_type.CAL, preview: 'prev_calories.png' },
                { type: hmUI.edit_type.HEART, preview: 'prev_heart.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'prev_distance.png' },
                { type: 100003, preview: 'prev_bio_charge.png', title_sc: 'HybridCharge', title_tc: 'HybridCharge', title_en: 'HybridCharge' },
                { type: hmUI.edit_type.SPO2, preview: 'prev_spo2.png' },
                { type: 100004, preview: 'prev_training_load.png', title_sc: '训练负荷', title_tc: '訓練負荷', title_en: 'Training load' },
                { type: 100005, preview: 'prev_altitude.png', title_sc: '海拔', title_tc: '海拔', title_en: 'Altitude' },
                { type: 100006, preview: 'prev_humidity.png', title_sc: '湿度', title_tc: '濕度', title_en: 'Humidity' },
                { type: 100007, preview: 'prev_uvi.png', title_sc: '紫外线', title_tc: '紫外線', title_en: 'UV index' },
                { type: 100001, preview: 'prev_recovery.png', title_sc: '恢复时间', title_tc: '恢復時間', title_en: 'Recovery time' },
              ],
              count: 13,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tips_bg.png',
              tips_x: -12,
              tips_y: 8,
              tips_width: 150,
              tips_margin: 10,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321, w: 91,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 346,
                  y: 286,
                  src: 'ic_step.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 330, w: 73,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 350,
                  y: 290,
                  src: 'ic_calories.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339, w: 55,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  invalid_image: 'v_null.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 348,
                  y: 292,
                  src: 'ic_heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339, w: 55,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 348,
                  y: 288,
                  src: 'ic_pai.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 330, w: 73,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'v_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 353,
                  y: 290,
                  src: 'ic_distance.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 328, w: 77,
                  y: 334,
                  font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'v_pct.png',
                  unit_tc: 'v_pct.png',
                  unit_en: 'v_pct.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 345,
                  y: 288,
                  src: 'ic_spo2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            case 100001:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 330, w: 72, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_en_hr.png', unit_tc: 'v_en_hr.png', unit_en: 'v_en_hr.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.RECOVERY_TIME, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 344, y: 288, src: 'ic_recovery.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100002:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 348, w: 37, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.VO2MAX, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 346, y: 288, src: 'ic_vo2max.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100003:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 339, w: 55, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.BIO_CHARGE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 348, y: 291, src: 'ic_bio_charge.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100004:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 330, w: 73, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.TRAINING_LOAD, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 346, y: 292, src: 'ic_training_load.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100005:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 330, w: 73, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, negative_image: 'v_moins.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.ALTITUDE, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 344, y: 295, src: 'ic_altitude.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100006:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 328, w: 77, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, unit_sc: 'v_pct.png', unit_tc: 'v_pct.png', unit_en: 'v_pct.png', invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.HUMIDITY, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 352, y: 290, src: 'ic_humidity.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
case 100007:
hmUI.createWidget(hmUI.widget.TEXT_IMG, { x: 348, w: 37, y: 334, font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"], padding: false, h_space: -1, invalid_image: 'v_null.png', align_h: hmUI.align.CENTER_H, type: hmUI.data_type.UVI, show_level: hmUI.show_level.ONLY_NORMAL });
hmUI.createWidget(hmUI.widget.IMG, { x: 350, y: 288, src: 'ic_uvi.png', show_level: hmUI.show_level.ONLY_NORMAL });
break;
}; // end switch
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 205,
              w: 140,
              h: 72,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 62,
              w: 202,
              h: 140,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 62,
              w: 202,
              h: 140,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 205,
              w: 146,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}