﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 14;
        let normal_step_TextCircle_img_height = 21;
        let normal_step_TextCircle_unit = null;
        let normal_step_TextCircle_unit_width = 56;
        let normal_battery_image_progress_img_level = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 21;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 145;
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 14;
        let normal_calorie_TextCircle_img_height = 21;
        let normal_calorie_TextCircle_unit = null;
        let normal_calorie_TextCircle_unit_width = 70;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_bio_charge_image_progress_img_progress = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let idle_battery_TextCircle = new Array(3);
        let idle_battery_TextCircle_ASCIIARRAY = new Array(10);
        let idle_battery_TextCircle_img_width = 14;
        let idle_battery_TextCircle_img_height = 21;
        let idle_battery_TextCircle_unit = null;
        let idle_battery_TextCircle_unit_width = 149;
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start

            // jauges bornees a 100 % : une image par niveau, mise a jour a chaque mesure, minute et reveil
            const jauges = [];
            const capteurs = {};
            function capteur(id) {
              if (!capteurs[id]) capteurs[id] = hmSensor.createSensor(hmSensor.id[id]);
              return capteurs[id];
            }
            function progression(id) {
              // un capteur absent ne doit pas interrompre la creation du cadran : jauge vide
              try {
                const c = capteur(id);
                if (id === 'BATTERY') return (c.current || 0) / 100;
                if (id === 'HEART') return c.last ? (c.last - 40) / 150 : 0;
                return c.target ? (c.current || 0) / c.target : 0;
              } catch (e) {
                return 0;
              }
            }
            function majJauge(j) {
              const k = Math.round(Math.max(0, Math.min(1, progression(j.id))) * j.n);
              j.w.setProperty(hmUI.prop.MORE, { x: j.x, y: j.y, src: j.prefixe + (k < 10 ? '0' : '') + k + '.png' });
            }
            function jauge(id, x, y, prefixe, n, niveau) {
              const j = { id: id, x: x, y: y, prefixe: prefixe, n: n };
              j.w = hmUI.createWidget(hmUI.widget.IMG, { x: x, y: y, src: prefixe + '00.png', show_level: niveau });
              jauges.push(j);
              majJauge(j);
            }
            function majJauges() {
              jauges.forEach(majJauge);
            }
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            jauge('STEP', 33, 32, 'pas_', 40, hmUI.show_level.ONLY_NORMAL);

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // radius: 167,
              // angle: -48,
              // char_space_angle: 0,
              // unit: 'u_pas_fr.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 - 188,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_step_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_step_TextCircle_unit_width / 2,
              pos_y: 240 - 188,
              src: 'u_pas_fr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            jauge('BATTERY', 284, 32, 'pile_', 40, hmUI.show_level.ONLY_NORMAL);

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // radius: 167,
              // angle: 37,
              // char_space_angle: 0,
              // unit: 'u_pile_fr.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 188,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 188,
              src: 'u_pile_fr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            jauge('CALORIE', 266, 306, 'kcal_', 40, hmUI.show_level.ONLY_NORMAL);

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["t_0.png","t_1.png","t_2.png","t_3.png","t_4.png","t_5.png","t_6.png","t_7.png","t_8.png","t_9.png"],
              // radius: 185,
              // angle: 145,
              // char_space_angle: 0,
              // unit: 'u_kcal_fr.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 't_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 't_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 't_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 't_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 't_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 't_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 't_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 't_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 't_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 't_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 + 164,
                src: 't_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_calorie_TextCircle_unit_width / 2,
              pos_y: 240 + 164,
              src: 'u_kcal_fr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            jauge('HEART', 66, 272, 'fc_', 40, hmUI.show_level.ONLY_NORMAL);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102, w: 75,
              y: 321,
              font_array: ["v_0.png","v_1.png","v_2.png","v_3.png","v_4.png","v_5.png","v_6.png","v_7.png","v_8.png","v_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'v_null.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [233,244,255,265,273,280,285,287,285,280,274,266,256,245,234,223,213,203,195,188,184,182,181,182,184,188,194,202,212,222],
              y: [181,182,186,191,198,207,217,228,239,250,260,269,277,282,286,286,283,277,270,261,251,240,229,218,208,199,191,186,182,181],
              image_array: ["hc_01.png","hc_02.png","hc_03.png","hc_04.png","hc_05.png","hc_06.png","hc_07.png","hc_08.png","hc_09.png","hc_10.png","hc_11.png","hc_12.png","hc_13.png","hc_14.png","hc_15.png","hc_16.png","hc_17.png","hc_18.png","hc_19.png","hc_20.png","hc_21.png","hc_22.png","hc_23.png","hc_24.png","hc_25.png","hc_26.png","hc_27.png","hc_28.png","hc_29.png","hc_30.png"],
              image_length: 30,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 282,
              y: 287,
              week_en: ["sem_fr_1.png","sem_fr_2.png","sem_fr_3.png","sem_fr_4.png","sem_fr_5.png","sem_fr_6.png","sem_fr_7.png"],
              week_tc: ["sem_fr_1.png","sem_fr_2.png","sem_fr_3.png","sem_fr_4.png","sem_fr_5.png","sem_fr_6.png","sem_fr_7.png"],
              week_sc: ["sem_fr_1.png","sem_fr_2.png","sem_fr_3.png","sem_fr_4.png","sem_fr_5.png","sem_fr_6.png","sem_fr_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 412,
              day_startY: 228,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // frise : jour et icone meteo des cinq cases ; secteur : temperature, icone et heure du prochain
            // lever ou coucher, a l'envers le long du cercle ; mis a jour chaque minute et au reveil
            const friseTemps = hmSensor.createSensor(hmSensor.id.TIME);
            const friseMeteo = hmSensor.createSensor(hmSensor.id.WEATHER);
            const FRISE_ANGLES = [-72, -36, 0, 36, 72];
            const FRISE_JOURS_W = [48, 53, 51, 45, 48, 53, 45];
            const FRISE_ICONES = [[132, 192], [165, 146], [219, 128], [273, 146], [306, 192]];
            const SOLEIL_W = {"sl_0": 12, "sl_1": 12, "sl_2": 12, "sl_3": 12, "sl_4": 12, "sl_5": 12, "sl_6": 12, "sl_7": 12, "sl_8": 12, "sl_9": 12, "sl_deux_points": 6, "sl_moins": 8, "lever": 30, "coucher": 30, "tp_moins": 10, "tp_deg": 11, "tp_0": 16, "tp_1": 16, "tp_2": 16, "tp_3": 16, "tp_4": 16, "tp_5": 16, "tp_6": 16, "tp_7": 16, "tp_8": 16, "tp_9": 16};
            const DEG = 180 / Math.PI;
            function friseImg(src, pos_x, pos_y, angle) {
              return hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, center_x: 240, center_y: 240,
                pos_x: pos_x, pos_y: pos_y, angle: angle, src: src, show_level: hmUI.show_level.ONLY_NORMAL });
            }
            const frise = FRISE_ANGLES.map(function (a, i) {
              return {
                jour: friseImg('fj_fr_1.png', 240 - FRISE_JOURS_W[0] / 2, 88, a),
                icone: hmUI.createWidget(hmUI.widget.IMG, { x: FRISE_ICONES[i][0], y: FRISE_ICONES[i][1],
                  src: 'meteo_00.png', show_level: hmUI.show_level.ONLY_NORMAL }),
              };
            });
            // une reserve par hauteur d'image : seule la position le long du cercle change
            function reserve(n, src, pos_y) {
              const r = [];
              for (let i = 0; i < n; i++) {
                r.push(friseImg(src, 0, pos_y, 0));
                r[i].setProperty(hmUI.prop.VISIBLE, false);
              }
              return r;
            }
            const soleilTemp = reserve(4, 'tp_0.png', 364);
            const soleilIcone = reserve(1, 'coucher.png', 361);
            const soleilHeure = reserve(5, 'sl_0.png', 366);
            function deux(n) {
              return (n < 10 ? '0' : '') + n;
            }
            function poser(w, src, a) {
              const l = SOLEIL_W[src];
              const milieu = a - l / 2 / 136.0 * DEG;
              w.setProperty(hmUI.prop.SRC, src + '.png');
              w.setProperty(hmUI.prop.POS_X, 240 - l / 2);
              w.setProperty(hmUI.prop.ANGLE, milieu - 180);
              w.setProperty(hmUI.prop.VISIBLE, true);
            }
            function friseMaj() {
              let semaine = 1;
              let prev = null;
              let marees = null;
              let actuelle;
              try {
                semaine = friseTemps.week || 1;
                const m = friseMeteo.getForecastWeather();
                prev = m && m.forecastData;
                marees = m && m.tideData;
                actuelle = friseMeteo.current;
              } catch (e) {}
              frise.forEach(function (c, i) {
                const j = (semaine - 1 + i) % 7;
                c.jour.setProperty(hmUI.prop.SRC, 'fj_fr_' + (j + 1) + '.png');
                c.jour.setProperty(hmUI.prop.POS_X, 240 - FRISE_JOURS_W[j] / 2);
                const k = prev && prev.count > i && prev.data[i] ? prev.data[i].index : -1;
                if (k >= 0 && k <= 28) c.icone.setProperty(hmUI.prop.SRC, 'meteo_' + deux(k) + '.png');
                c.icone.setProperty(hmUI.prop.VISIBLE, k >= 0 && k <= 28);
              });
              const temp = [];
              if (actuelle !== undefined && actuelle !== null && isFinite(actuelle)) {
                for (const ch of String(Math.round(actuelle))) temp.push(ch === '-' ? 'tp_moins' : 'tp_' + ch);
                temp.push('tp_deg');
              }
              let heure = '--:--';
              let lever = false;
              if (marees && marees.count && marees.data[0]) {
                const d = marees.data[0];
                const maintenant = friseTemps.hour * 60 + friseTemps.minute;
                let s = d.sunrise;
                lever = true;
                if (maintenant >= d.sunrise.hour * 60 + d.sunrise.minute) {
                  if (maintenant < d.sunset.hour * 60 + d.sunset.minute) {
                    s = d.sunset;
                    lever = false;
                  } else if (marees.count > 1 && marees.data[1]) {
                    s = marees.data[1].sunrise;
                  }
                }
                heure = deux(s.hour) + ':' + deux(s.minute);
              }
              const chiffres = [];
              for (const ch of heure) chiffres.push(ch === ':' ? 'sl_deux_points' : ch === '-' ? 'sl_moins' : 'sl_' + ch);
              const icone = lever ? 'lever' : 'coucher';
              let total = SOLEIL_W[icone] + 4.0 + (temp.length ? 8.0 : 0);
              temp.concat(chiffres).forEach(function (n) { total += SOLEIL_W[n]; });
              let a = 136.1 + total / 2 / 136.0 * DEG;
              soleilTemp.forEach(function (w, i) {
                if (i < temp.length) {
                  poser(w, temp[i], a);
                  a -= (SOLEIL_W[temp[i]] + (i === temp.length - 1 ? 8.0 : 0)) / 136.0 * DEG;
                } else {
                  w.setProperty(hmUI.prop.VISIBLE, false);
                }
              });
              poser(soleilIcone[0], icone, a);
              a -= (SOLEIL_W[icone] + 4.0) / 136.0 * DEG;
              soleilHeure.forEach(function (w, i) {
                poser(w, chiffres[i], a);
                a -= SOLEIL_W[chiffres[i]] / 136.0 * DEG;
              });
            }
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aig_h.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 13,
              hour_posY: 132,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aig_m.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 12,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'aig_s.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 12,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_fond.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["tg_0.png","tg_1.png","tg_2.png","tg_3.png","tg_4.png","tg_5.png","tg_6.png","tg_7.png","tg_8.png","tg_9.png"],
              // radius: 203,
              // angle: 36,
              // char_space_angle: 0,
              // unit: 'aod_u_pile_fr.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextCircle_ASCIIARRAY[0] = 'tg_0.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[1] = 'tg_1.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[2] = 'tg_2.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[3] = 'tg_3.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[4] = 'tg_4.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[5] = 'tg_5.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[6] = 'tg_6.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[7] = 'tg_7.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[8] = 'tg_8.png';  // set of images with numbers
            idle_battery_TextCircle_ASCIIARRAY[9] = 'tg_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_battery_TextCircle_img_width / 2,
                pos_y: 240 - 224,
                src: 'tg_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - idle_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 224,
              src: 'aod_u_pile_fr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 412,
              day_startY: 228,
              day_sc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_tc_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_en_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aig_h.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 13,
              hour_posY: 132,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_aig_m.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 12,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            try {
              const reveilTemps = hmSensor.createSensor(hmSensor.id.TIME);
              reveilTemps.addEventListener(reveilTemps.event.MINUTEEND, function () {
                majJauges();
                friseMaj();
              });
              for (const id of ['STEP', 'CALORIE', 'HEART', 'BATTERY']) {
                capteur(id).addEventListener(hmSensor.event.CHANGE, majJauges);
              }
            } catch (e) {}
            friseMaj();
            hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: function () {
                majJauges();
                friseMaj();
              },
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 36,
              w: 97,
              h: 144,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 330,
              w: 129,
              h: 114,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 269,
              w: 159,
              h: 154,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 41,
              w: 104,
              h: 123,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 232,
              w: 146,
              h: 96,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 139,
              w: 146,
              h: 94,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 394,
              y: 205,
              w: 71,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -48;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  let normal_step_TextCircle_unit_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 167));
                  normal_step_TextCircle_unit_angle = toDegree(Math.atan2(normal_step_TextCircle_unit_width/2, 167));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + (normal_step_TextCircle_img_angle + normal_step_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_step_TextCircle_unit_angle;
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 37;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 167));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 167));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 325;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  let normal_calorie_TextCircle_unit_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 185));
                  normal_calorie_TextCircle_unit_angle = toDegree(Math.atan2(normal_calorie_TextCircle_unit_width/2, 185));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_angleOffset + (normal_calorie_TextCircle_img_angle + normal_calorie_TextCircle_unit_angle + 0) / 2;
                  normal_calorie_TextCircle_angleOffset = -normal_calorie_TextCircle_angleOffset;
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_calorie_TextCircle_unit_angle;
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let idle_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 36;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_circle_string.length > 0 && idle_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_battery_TextCircle_img_angle = 0;
                  let idle_battery_TextCircle_dot_img_angle = 0;
                  let idle_battery_TextCircle_unit_angle = 0;
                  idle_battery_TextCircle_img_angle = toDegree(Math.atan2(idle_battery_TextCircle_img_width/2, 203));
                  idle_battery_TextCircle_unit_angle = toDegree(Math.atan2(idle_battery_TextCircle_unit_width/2, 203));
                  // alignment = CENTER_H
                  let idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_img_angle * (idle_battery_circle_string.length - 1);
                  idle_battery_TextCircle_angleOffset = idle_battery_TextCircle_angleOffset + (idle_battery_TextCircle_img_angle + idle_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= idle_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_battery_TextCircle_img_width / 2);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.SRC, idle_battery_TextCircle_ASCIIARRAY[charCode]);
                      idle_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += idle_battery_TextCircle_unit_angle;
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}